var mode = "offline";
var linkforleg = "/legacy.suttacentral.net/sc/pi/";
var linkforlegext = ".html";