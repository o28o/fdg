# Draggable, Resizable Modal iFrames w/ GSAP, jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/cseriestechhero/pen/OJNaMwX](https://codepen.io/cseriestechhero/pen/OJNaMwX).

