# Lightweight interface for English SuttaCentral translation by Bhante Sujato

This code makes use of the SuttaCentral API.

For the old branch that pulled the sutta data off of the GitHub repository, go [here](https://github.com/thesunshade/mini-sc/tree/Old-version-using-github-files-as-source)
