pli-tv-bu-vb-as6:1.1@tassapāpiyasikā → tassapāpiyyasikā (bj, pts1ed); tassa pāpiyasikā (sya1ed, sya2ed) @pli-tv-bu-vb-as1-7
pli-tv-bu-vb-ay1:2.1.18@kuṭṭena vā → kuḍḍena vā (bj, sya-all, pts1ed) @pli-tv-bu-vb-ay1
pli-tv-bu-vb-np1:0.4@Cīvaravagga → kathinavagga (pli-tv-pvr1.1:82 [Katthapaññattivāra/4. Kathinavagga]; pli-tv-pvr1.2:20 [Katāpattivāra/4. Kathinavagga]) @pli-tv-bu-vb-np1
pli-tv-bu-vb-np1:2.17.1@kathine → kaṭhine (bj, sya-all, pts1ed) @pli-tv-bu-vb-np1
pli-tv-bu-vb-np1:3.1.6@dasāhaparamatā → dasāhaparamatāya (si) @pli-tv-bu-vb-np1
pli-tv-bu-vb-np1:3.2.10@dātabbaṁ → hotīti idaṁ padaṁ sabbapotthakesu atthi, sikkhāpade pana natthi @pli-tv-bu-vb-np1
pli-tv-bu-vb-np1:5.3@(…) → (…) sya-all potthakesu @pli-tv-bu-vb-np1
pli-tv-bu-vb-np2:2.39.1@bhikkhusammutiyā → … sammatiyā (sya-all) @pli-tv-bu-vb-np2
pli-tv-bu-vb-np2:3.1.10@aruṇuggamanā → aruṇuggamanena (bj, sya-all) @pli-tv-bu-vb-np2
pli-tv-bu-vb-np2:3.1.14@rattivippavutthaṁ → rattiṁ vippavutthaṁ (bj, pts1ed) @pli-tv-bu-vb-np2
pli-tv-bu-vb-np2:3.2.3@Udosito → uddosito (bj, sya-all, pts1ed) @pli-tv-bu-vb-np2
pli-tv-bu-vb-np2:3.5.1@udosito → uddosito (bj, sya-all, pts1ed) @pli-tv-bu-vb-np2
pli-tv-bu-vb-np3:0.4@Cīvaravagga → akālacīvarasikkhāpada (kaṅkhāvitāraṇī) @pli-tv-bu-vb-np3
pli-tv-bu-vb-np3:1.3.15@māsaparamaṁ tena → māsaparamantena (sya-all, pts1ed) @pli-tv-bu-vb-np3
pli-tv-bu-vb-np3:1.3.16@uttari → uttariṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-np3
pli-tv-bu-vb-np5:1.1.11@paṇṇapuṭaṁ → paṇṇena puṭaṁ (sya-all) @pli-tv-bu-vb-np5
pli-tv-bu-vb-np5:1.1.15@paccuṭṭhāsi → paccupaṭṭhāsi (?) @pli-tv-bu-vb-np5
pli-tv-bu-vb-np5:1.2.11@sajjeyya → vissajjeyya (sya-all) @pli-tv-bu-vb-np5
pli-tv-bu-vb-np5:1.2.12@antaravāsake sajjasī”ti → antaravāsakaṁ na sajjasīti (si, mr); mayhaṁ antaravāsakaṁ vissajjehīti (sya-all); antaravāsakaṁ na sajjesīti (pts1ed) @pli-tv-bu-vb-np5
pli-tv-bu-vb-np5:2.10.1@pārivattakā → pārivaṭṭakā (sya-all) @pli-tv-bu-vb-np5
pli-tv-bu-vb-np6:1.1.2@paṭṭo → paṭṭho (sya-all, pts1ed, mr) @pli-tv-bu-vb-np6
pli-tv-bu-vb-np6:1.2.5@Nayimesaṁ sukarā dhammanimantanāpi kātuṁ → nayime sukarā dhammanimantanāya kātuṁ (sya-all) @pli-tv-bu-vb-np6
pli-tv-bu-vb-np7:1.20@paggāhikasālaṁ → paṭaggāhikasālaṁ (?) @pli-tv-bu-vb-np7
pli-tv-bu-vb-np7:1.31.1@uttari → uttariṁ (bj, sya-all, pts1ed); tena → … paramantena (sya-all, pts1ed) @pli-tv-bu-vb-np7
pli-tv-bu-vb-np8:1.1.12@meyya → mayya (bj, sya-all, pts1ed) @pli-tv-bu-vb-np8
pli-tv-bu-vb-np8:1.1.24@gahapatikaṁ → gahapatiṁ (bj) @pli-tv-bu-vb-np8
pli-tv-bu-vb-np8:1.1.32.1@cīvaracetāpannaṁ → cīvaracetāpanaṁ (sya-all, pts1ed) @pli-tv-bu-vb-np8
pli-tv-bu-vb-np8:2.1.34@sādhatthiko → sādhutthiko (sya-all) @pli-tv-bu-vb-np8
pli-tv-bu-vb-np9:1.3@ayyaṁ → ahaṁ ayyaṁ (bj, pts1ed) @pli-tv-bu-vb-np9
pli-tv-bu-vb-np9:1.36.1@paccekacīvaracetāpannāni upakkhaṭāni → … cetāpannā upakkhaṭā (bj); … cetāpanā upakkhaṭā (sya-all, pts1ed) @pli-tv-bu-vb-np9
pli-tv-bu-vb-np10:1.3.13@dvattikkhattuṁ → dvittikkhattuṁ (sya-all, pts1ed) @pli-tv-bu-vb-np10
pli-tv-bu-vb-np10:1.3.16@chakkhattuparamaṁ → chakkhattuṁ paramaṁ (bj) @pli-tv-bu-vb-np10
pli-tv-bu-vb-np10:1.3.17@kusalaṁ → kusalaṁ no ce abhinipphādeyya (sya1ed, sya2ed) @pli-tv-bu-vb-np10
pli-tv-bu-vb-np10:1.3.18@uttari → uttariṁ (sya-all, pts1ed) @pli-tv-bu-vb-np10
pli-tv-bu-vb-np11:1.8@pāṇe → pāṇake (bj) @pli-tv-bu-vb-np11
pli-tv-bu-vb-np15:1.1.22@tamahaṁ → tāhaṁ (bj, pts1ed, mr) @pli-tv-bu-vb-np15
pli-tv-bu-vb-np15:1.1.26@tamahaṁ → tāhaṁ (bj, pts1ed, mr) @pli-tv-bu-vb-np15
pli-tv-bu-vb-np15:1.3.2@dassanaṁ pihentā → dassanāya pihayantā (sya-all); dassanaṁ pihantā (pts1ed) @pli-tv-bu-vb-np15
pli-tv-bu-vb-np16:1.23.1@addhānamaggappaṭipannassa → … maggapaṭipannassa (sya-all, pts1ed) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:1.24@haritabbāni → hāretabbāni (si, sya-all, pts1ed, mr) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:1.25@uttari → uttariṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:2.13@nissaggiyaṁ pācittiyaṁ → nissaggiyāni honti (sya-all) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:2.14@nissaggiyaṁ pācittiyaṁ → nissaggiyāni honti (sya-all) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:2.24.1@atirekasaññī atikkāmeti → tiyojanaṁ atikkāmeti (sya-all) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:2.25@vematiko atikkāmeti → tiyojanaṁ atikkāmeti (sya-all) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np16:2.26@ūnakasaññī atikkāmeti → tiyojanaṁ atikkāmeti (sya-all) @pli-tv-bu-vb-np16
pli-tv-bu-vb-np18:1.3@paṭiviso → paṭiviṁso (bj) @pli-tv-bu-vb-np18
pli-tv-bu-vb-np18:1.22@paṭiggahesī”ti → paṭiggaṇhāsīti (sya-all) @pli-tv-bu-vb-np18
pli-tv-bu-vb-np18:2.10@nissaggiyaṁ pācittiyaṁ → nissaggiyaṁ hoti (sya-all) @pli-tv-bu-vb-np18
pli-tv-bu-vb-np18:2.64@Rūpiyasikkhāpadaṁ → jātarūpasikkhāpada (kaṅkhāvitaraṇī) @pli-tv-bu-vb-np18
pli-tv-bu-vb-np19:2.16@nissaggiyaṁ pācittiyaṁ → nissaggiyaṁ hoti (sya-all) @pli-tv-bu-vb-np19
pli-tv-bu-vb-np20:1.17@saṅghāṭi → saṅghāṭiṁ (sya-all, pts1ed, mr) @pli-tv-bu-vb-np20
pli-tv-bu-vb-np21:3.56@adhiṭṭheti → adhiṭṭhāti (bj) @pli-tv-bu-vb-np21
pli-tv-bu-vb-np22:1.3.18@so → so ca (sya-all) @pli-tv-bu-vb-np22
pli-tv-bu-vb-np22:1.3.19@ayaṁ te → ayante (sya-all) @pli-tv-bu-vb-np22
pli-tv-bu-vb-np23:1.1.23@gaṇetvā → vigaṇetvā (bj, pts1ed, mr) @pli-tv-bu-vb-np23
pli-tv-bu-vb-np23:1.1.26@pādāsi → adāsi (sya-all) @pli-tv-bu-vb-np23
pli-tv-bu-vb-np23:1.3.13@uttarimanussadhammaṁ → uttarimanussadhammā (bj) @pli-tv-bu-vb-np23
pli-tv-bu-vb-np23:2.3@mahiṁsasappi → mahisasappi (bj, sya-all); mahisaṁ vā sappi (pts1ed) @pli-tv-bu-vb-np23
pli-tv-bu-vb-np24:1.4@paṭikacceva → paṭigacceva (bj, pts1ed) @pli-tv-bu-vb-np24
pli-tv-bu-vb-np24:1.18.1@addhamāso → aḍdhamāso (sya-all) @pli-tv-bu-vb-np24
pli-tv-bu-vb-np24:1.19@orenaddhamāso → orenaḍdhamāso (sya-all) @pli-tv-bu-vb-np24
pli-tv-bu-vb-np25:2.14@nissaggiyaṁ pācittiyaṁ → nissaggiyaṁ hoti (sya-all) @pli-tv-bu-vb-np25
pli-tv-bu-vb-np26:1.2@bahuṁ suttaṁ → bahusuttaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-np26
pli-tv-bu-vb-np26:2.11@payoge payoge dukkaṭaṁ → payoge dukkaṭaṁ (sya-all, pts1ed) @pli-tv-bu-vb-np26
pli-tv-bu-vb-np26:2.31@aṁsabaddhake → aṁsavaṭṭake (bj); aṁsabandhake (sya-all, pts1ed) @pli-tv-bu-vb-np26
pli-tv-bu-vb-np27:1.18@ayyo → ayya (sya-all) @pli-tv-bu-vb-np27
pli-tv-bu-vb-np27:1.32@upanando mayā pubbe appavārito tantavāye → gahapatikassa tantavāye (pts1ed, mr) @pli-tv-bu-vb-np27
pli-tv-bu-vb-np27:1.46@viyyati → vīyati (sya-all) @pli-tv-bu-vb-np27
pli-tv-bu-vb-np28:1.2.5@Addasa → addasā (bj, sya-all, pts1ed) @pli-tv-bu-vb-np28
pli-tv-bu-vb-np28:1.2.19.1@kattikatemāsikapuṇṇamaṁ → kattikatemāsipuṇṇamaṁ (sya-all); yāva cīvarakālasamayaṁ → yāvacīvara … (sya-all) @pli-tv-bu-vb-np28
pli-tv-bu-vb-np28:1.2.20@uttari → uttariṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-np28
pli-tv-bu-vb-np28:2.13@nissaggiyaṁ pācittiyaṁ → nissaggiyaṁ hoti (sya-all) @pli-tv-bu-vb-np28
pli-tv-bu-vb-np28:2.38@antosamaye → antosamayaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-np28
pli-tv-bu-vb-np29:2.31@vippavutthaṁ → vippavuṭṭhaṁ (csp1ed, csp2ed) @pli-tv-bu-vb-np29
pli-tv-bu-vb-np30:1.9@bhattā → bhaddā (bj, mr) @pli-tv-bu-vb-np30
pli-tv-bu-vb-pc1:2.7.3@ravā bhaṇati → ravāya bhaṇati (sya-all) @pli-tv-bu-vb-pc1
pli-tv-bu-vb-pc1:2.7.10@Musāvādasikkhāpadaṁ niṭṭhitaṁ paṭhamaṁ → paṭhamasikkhāpadaṁ niṭṭhitaṁ (sya-all) @pli-tv-bu-vb-pc1
pli-tv-bu-vb-pc2:1.1.2@bhaṇḍantā → bhaṇḍentā (bj, pts1ed) @pli-tv-bu-vb-pc2
pli-tv-bu-vb-pc2:1.2.1@takkasilāyaṁ → takkasīlāyaṁ (mr) @pli-tv-bu-vb-pc2
pli-tv-bu-vb-pc2:1.2.2@balībaddo → balivaddo (bj); balibaddo (sya-all, pts1ed) @pli-tv-bu-vb-pc2
pli-tv-bu-vb-pc2:1.2.8@gaccha, kūṭa → añcha kūṭa (bj, sya-all) @pli-tv-bu-vb-pc2
pli-tv-bu-vb-pc2:2.2.1@caṇḍālosi, venosi, nesādosi, rathakārosi, pukkusosī”ti bhaṇati → vadetīti uddeso. bhaṇatīti vitthāro (vajirabuddhi) @pli-tv-bu-vb-pc2
pli-tv-bu-vb-pc4:2.1.18@padaso → padaso dhammo (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc4
pli-tv-bu-vb-pc5:2.16.1@sahaseyyaṁ → saha seyyaṁ (sya-all); uttaridirattatirattaṁ → uttaridviratta … (sya-all, pts1ed) @pli-tv-bu-vb-pc5
pli-tv-bu-vb-pc5:3.3.6@sabbaacchanne → (bj) @pli-tv-bu-vb-pc5
pli-tv-bu-vb-pc5:3.3.14@Sahaseyyasikkhāpadaṁ → paṭhamasahaseyyasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc5
pli-tv-bu-vb-pc6:1.2@janapade → janapadesu (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc6
pli-tv-bu-vb-pc6:1.21@paṭicchatu → sampaṭicchatu (sya-all) @pli-tv-bu-vb-pc6
pli-tv-bu-vb-pc6:2.1.6@yakkhī → yakkhinī (mr) @pli-tv-bu-vb-pc6
pli-tv-bu-vb-pc6:2.3.2@sabbaaparicchanne … sabbaacchanne → anāpatti sabbaacchanne sabbaaparicchanne (bj) @pli-tv-bu-vb-pc6
pli-tv-bu-vb-pc7:3.11.1@uttarichappañcavācāhi → uttariṁ chappañcavācāhi (sya-all) @pli-tv-bu-vb-pc7
pli-tv-bu-vb-pc8:1.1.20@sāyanti pivanti → attanā pivanti (bj, sya-all, pts1ed, mr) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc8:2.1.22@arahattassa → arahattaphalassa (sya-all, pts1ed) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc8:2.2.45@arahattaṁ → arahattaphalaṁ (sya-all) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc8:2.3.34@arahattañca → arahattaphalañca (sya-all) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc8:2.3.56@arahattañca → arahattaphalañca (sya-all) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc8:2.4.26@arahattaṁ → arahattaphalaṁ (sya-all) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc8:2.5.30@arahattaṁ → arahattaphalaṁ (sya-all) @pli-tv-bu-vb-pc8
pli-tv-bu-vb-pc9:1.20.1@bhikkhusammutiyā → bhikkhusammatiyā (sya-all) @pli-tv-bu-vb-pc9
pli-tv-bu-vb-pc10:0.4@Musāvādavagga → paṭhavikhaṇanasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc10
pli-tv-bu-vb-pc10:1.2@āḷavakā → āḷavikā (sya-all, pts1ed) @pli-tv-bu-vb-pc10
pli-tv-bu-vb-pc10:1.16.1@pathaviṁ → paṭhaviṁ (bj, sya-all) @pli-tv-bu-vb-pc10
pli-tv-bu-vb-pc10:2.3.8@Pathavīkhaṇanasikkhāpadaṁ → paṭhavikhaṇanasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc10
pli-tv-bu-vb-pc11:2.1.2@bījabījameva → bījabījañceva (pts1ed) @pli-tv-bu-vb-pc11
pli-tv-bu-vb-pc13:0.4@Bhūtagāmavagga → ujjhāpanasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc13
pli-tv-bu-vb-pc13:1.3@mettiyabhūmajakā → mettiyabhummajakā (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc13
pli-tv-bu-vb-pc13:2.2@bhikkhū sossantī’”ti → vihesissantīti (itipi) @pli-tv-bu-vb-pc13
pli-tv-bu-vb-pc13:2.12.1@khiyyanake → khīyanake (sya-all, pts1ed) @pli-tv-bu-vb-pc13
pli-tv-bu-vb-pc13:3.3.5@Ujjhāpanakasikkhāpadaṁ → ujjhāpanasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc13
pli-tv-bu-vb-pc14:1.2.4@aṭṭha māse avassikasaṅkete → vasituṁ avassikasaṅkete (itipi) @pli-tv-bu-vb-pc14
pli-tv-bu-vb-pc14:2.1.15@pabbajamayaṁ → babbajamayaṁ (bj, pts1ed) @pli-tv-bu-vb-pc14
pli-tv-bu-vb-pc14:2.1.21@santhārakassa → santhatassa (bj) @pli-tv-bu-vb-pc14
pli-tv-bu-vb-pc16:1.2@vuṭṭhāpenti → ettha te iti kammapadaṁ ūnaṁ viya @pli-tv-bu-vb-pc16
pli-tv-bu-vb-pc16:1.16.1@pubbupagataṁ → pubbūpagataṁ (bj, sya-all); anupakhajja → anūpakhajja (sya-all) @pli-tv-bu-vb-pc16
pli-tv-bu-vb-pc17:1.12@paṭikacceva → paṭigacceva (bj, pts1ed) @pli-tv-bu-vb-pc17
pli-tv-bu-vb-pc17:2.1.16@pācittiyassa → dukkaṭassa (pts1ed) @pli-tv-bu-vb-pc17
pli-tv-bu-vb-pc18:1.1@viharati → eko heṭṭhā (?) @pli-tv-bu-vb-pc18
pli-tv-bu-vb-pc18:1.4@nippatitvā → nipatitvā (bj); patitvā (sya-all); nippaṭitvā (pts1ed) @pli-tv-bu-vb-pc18
pli-tv-bu-vb-pc19:1.18.1@aggaḷaṭṭhapanāya → aggalaṭṭhapanāya (bj, cck, sya2ed); appaharite → apaharite (sya1ed); uttari → uttariṁ (bj, sya-all) @pli-tv-bu-vb-pc19
pli-tv-bu-vb-pc19:2.1.8@piṭṭhasaṅghāṭassa → pīṭhasaṅghāṭassa (itipi); piṭṭhisaṅghāṭassa (sya-all) @pli-tv-bu-vb-pc19
pli-tv-bu-vb-pc20:2.1.5@nāma → jānaṁ nāma (sya-all) @pli-tv-bu-vb-pc20
pli-tv-bu-vb-pc20:2.1.10@āpatti pācittiyassa → āpatti dukkaṭassa (katthaci) @pli-tv-bu-vb-pc20
pli-tv-bu-vb-pc20:2.3.8@Bhūtagāmavaggo → senāsanavaggo (si) @pli-tv-bu-vb-pc20
pli-tv-bu-vb-pc21:2.33@panetaṁ → pana taṁ (?) @pli-tv-bu-vb-pc21
pli-tv-bu-vb-pc21:3.1.18@niyyādetabbo → niyyātetabbo (itipi) @pli-tv-bu-vb-pc21
pli-tv-bu-vb-pc21:3.1.24@paccāsīsitabbā → paccāsiṁsitabbā (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc21
pli-tv-bu-vb-pc22:1.16@tañceva → taññeva (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc22
pli-tv-bu-vb-pc22:1.33.1@sūriye → suriye (sya-all, pts1ed); Sammatopi ce → sammato ce pi (pts1ed) @pli-tv-bu-vb-pc22
pli-tv-bu-vb-pc23:0.4@Ovādavagga → bhikkhunūpassayasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc23
pli-tv-bu-vb-pc23:1.5@Yampi → yaṁ hi (pts1ed, mr) @pli-tv-bu-vb-pc23
pli-tv-bu-vb-pc23:1.7@chabbaggiyā bhikkhū bhikkhunupassayaṁ upasaṅkamitvā bhikkhuniyo ovadissantī”ti → chabbaggiyā bhikkhuniyo ovādaṁ na gacchissantīti (bj); chabbaggiyā bhikkhū bhikkhunūpassayaṁ upasaṅkamitvā bhikkhuniyo ovadantīti (sya-all) @pli-tv-bu-vb-pc23
pli-tv-bu-vb-pc23:2.4@kacci → kacci te (bj, sya-all) @pli-tv-bu-vb-pc23
pli-tv-bu-vb-pc23:2.19.1@bhikkhunupassayaṁ → bhikkhunūpassayaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc23
pli-tv-bu-vb-pc23:3.3.13@Bhikkhunupassayasikkhāpadaṁ → bhikkhunūpassayasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc23
pli-tv-bu-vb-pc24:1.16.1@āmisahetu therā bhikkhū → āmisahetu bhikkhū (sya-all) @pli-tv-bu-vb-pc24
pli-tv-bu-vb-pc25:1.8@cīvarapaṭivīso → … paṭiviṁso (bj); … paṭiviso (sya-all, pts1ed) @pli-tv-bu-vb-pc25
pli-tv-bu-vb-pc25:2.1@pārivattakaṁ → pārivaṭṭakaṁ (bj, sya-all) @pli-tv-bu-vb-pc25
pli-tv-bu-vb-pc25:3.1.10@vikappanupagaṁ pacchimaṁ → vikappanupagapacchimaṁ (pts1ed) @pli-tv-bu-vb-pc25
pli-tv-bu-vb-pc26:1.2@āyasmā udāyī paṭṭo → udāyi paṭṭo (bj); udāyi paṭṭho (sya-all, pts1ed) @pli-tv-bu-vb-pc26
pli-tv-bu-vb-pc27:3.1.19@tasmiṁ magge → yasmiṁ magge (?) @pli-tv-bu-vb-pc27
pli-tv-bu-vb-pc28:0.4@Ovādavagga → nāvābhirūhanasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc28
pli-tv-bu-vb-pc28:1.2@ekaṁ nāvaṁ → ekanāvaṁ (sya-all) @pli-tv-bu-vb-pc28
pli-tv-bu-vb-pc28:1.4@nāvāya → ekanāvāya (sya-all) @pli-tv-bu-vb-pc28
pli-tv-bu-vb-pc28:1.14.1@ekaṁ nāvaṁ → ekanāvaṁ (sya-all) @pli-tv-bu-vb-pc28
pli-tv-bu-vb-pc28:2.2@taritabbā → uttaritabbā (sya-all) @pli-tv-bu-vb-pc28
pli-tv-bu-vb-pc28:2.16.1@uddhaṅgāminiṁ → uddhagāminiṁ (bj, sya-all); tiriyaṁ taraṇāya → tiriyantaraṇāya (sya-all, pts1ed); ekaṁ nāvaṁ → ekanāvaṁ (sya-all); abhiruheyya → abhirūheyya (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc28
pli-tv-bu-vb-pc29:1.11@kaṭamodakatissako → kaṭamorakatissako (bj, pts1ed); katamorakatissako (sya-all) @pli-tv-bu-vb-pc29
pli-tv-bu-vb-pc29:2.13.1@gihisamārambhā → gihīsamārambhā (bj); bhikkhuniparipācitaṁ → bhikkhunī … (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc29
pli-tv-bu-vb-pc30:2.3.9@Ovādavaggo → bhikkhunovādavaggo (bj) @pli-tv-bu-vb-pc30
pli-tv-bu-vb-pc31:2.14.1@uttari → uttariṁ (bj, sya-all) @pli-tv-bu-vb-pc31
pli-tv-bu-vb-pc32:3.5@Bhagavato → bhikkhū bhagavato (csp1ed) @pli-tv-bu-vb-pc32
pli-tv-bu-vb-pc32:8.16@nāvābhiruhanasamayo → nāvābhirūhana … (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc32
pli-tv-bu-vb-pc32:9.1.6@phalitā → phālitā (bj, sya-all, pts1ed, mr) @pli-tv-bu-vb-pc32
pli-tv-bu-vb-pc33:1.3@kammakārassa → kammakarassa (bj) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc33:1.7@abbhātirekaṁ → atirekaṁ (sya-all); abbhatirekaṁ (pts1ed) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc33:1.11@Hotu → hotu me (mr) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc33:2.4@ussūre → ussūrena (mr) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc33:3.1@paṭiyādetvā → paṭiyādāpetvā (si, pts1ed) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc33:4.4@Gaṇhāhi → patigaṇhāhi (bj) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc33:4.8@bhikkhave, vikappetvā → bhattapaccāsaṁ vikappetvā (sya-all) @pli-tv-bu-vb-pc33
pli-tv-bu-vb-pc34:1.1.6@pūvaṁ → pūpaṁ (ṇvādimoggallāne) @pli-tv-bu-vb-pc34
pli-tv-bu-vb-pc34:1.2.10@Nāyyo → nāyya (bj, sya-all) @pli-tv-bu-vb-pc34
pli-tv-bu-vb-pc34:1.2.21.1@uttari → uttariṁ (bj, sya-all); paṭiggaṇheyya → paṭigaṇheyya (pts1ed) @pli-tv-bu-vb-pc34
pli-tv-bu-vb-pc35:0.4@Bhojanavagga → paṭhamapavāraṇasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc35
pli-tv-bu-vb-pc35:1.4@paṭivissake → paṭivisake (yojanā) @pli-tv-bu-vb-pc35
pli-tv-bu-vb-pc35:1.7@ayyo → ayya (sya-all) @pli-tv-bu-vb-pc35
pli-tv-bu-vb-pc35:2.15.1@khādanīyaṁ → khādaniyaṁ (pts1ed); bhojanīyaṁ → bhojaniyaṁ (pts1ed) @pli-tv-bu-vb-pc35
pli-tv-bu-vb-pc35:3.3.9@Pavāraṇāsikkhāpadaṁ → paṭhamapavāraṇasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc35
pli-tv-bu-vb-pc36:0.4@Bhojanavagga → dutiyapavāraṇasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc36
pli-tv-bu-vb-pc36:1.10@Upanaddho → upanandho (si, pts1ed, mr) @pli-tv-bu-vb-pc36
pli-tv-bu-vb-pc36:1.16@tvampi → tvaṁ hi (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc36
pli-tv-bu-vb-pc36:2.3.9@Dutiyapavāraṇāsikkhāpadaṁ → dutiyapavāraṇasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc36
pli-tv-bu-vb-pc38:1.2@belaṭṭhasīso → bellaṭṭhisīso (bj); belaṭṭhisīso (si); veḷaṭṭhasīso (sya-all) @pli-tv-bu-vb-pc38
pli-tv-bu-vb-pc39:2.10.1@seyyathidaṁ → seyyathīdaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc39
pli-tv-bu-vb-pc39:3.1.13@udako → udakacaro (sya-all, pts1ed, mr) @pli-tv-bu-vb-pc39
pli-tv-bu-vb-pc39:3.1.30@viññāpeti, payoge → payoge payoge (pts1ed, mr) @pli-tv-bu-vb-pc39
pli-tv-bu-vb-pc40:1.3@paribhuñjati → bhuñjati (sya-all, pts1ed) @pli-tv-bu-vb-pc40
pli-tv-bu-vb-pc40:2.1@udakadantapone → udakadantapoṇe (sya-all, pts1ed, mr) @pli-tv-bu-vb-pc40
pli-tv-bu-vb-pc40:2.5.1@udakadantaponā → … poṇā (sya-all, pts1ed) @pli-tv-bu-vb-pc40
pli-tv-bu-vb-pc42:1.16.1@bhikkhuṁ—‘ehāvuso → bhikkhuṁ evaṁ vadeyya ehāvuso (sya-all) @pli-tv-bu-vb-pc42
pli-tv-bu-vb-pc43:1.2@sayanighare → sayanīghare (sya-all) @pli-tv-bu-vb-pc43
pli-tv-bu-vb-pc43:2.1.10@piṭṭhasaṅghāṭassa → piṭṭhisaṅghāṭassa (sya1ed, sya2ed); piṭṭhasaṅghātassa (pts1ed); pīṭhasaṅghāṭassa (itipi) @pli-tv-bu-vb-pc43
pli-tv-bu-vb-pc44:0.4@Acelakavagga → paṭhamarahonisajjasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc44
pli-tv-bu-vb-pc44:2.1.16@kuṭṭena → kuḍḍena (bj, sya-all, pts1ed); kotthaḷiyā → kotthaliyā (bj); koṭṭhaḷiyā (sya-all); kotthaḷikāya (mr) @pli-tv-bu-vb-pc44
pli-tv-bu-vb-pc44:2.3.8@Rahopaṭicchannasikkhāpadaṁ → paṭhamarahonisajjasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc44
pli-tv-bu-vb-pc45:0.4@Acelakavagga → dutiyarahonisajjasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc45
pli-tv-bu-vb-pc45:2.2.4@tiracchānagatamanussaviggahitthiyā → tiracchānagatāya vā manussaviggahitthiyā vā (mr) @pli-tv-bu-vb-pc45
pli-tv-bu-vb-pc45:2.3.8@Rahonisajjasikkhāpadaṁ → dutiyarahonisajjasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc45
pli-tv-bu-vb-pc46:6.1.16@kusaggenapi → aruṇuggamanepi (bj) @pli-tv-bu-vb-pc46
pli-tv-bu-vb-pc47:1.1.4@catumāsaṁ → cātumāsaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc47
pli-tv-bu-vb-pc47:1.4.10@Kālaṁ āharissathā”ti → kālaṁ harissathāti (bj, pts1ed); kāle harissathāti (sya-all) @pli-tv-bu-vb-pc47
pli-tv-bu-vb-pc47:1.4.27.1@catumāsappaccayapavāraṇā → cātumāsapaccaya … (sya-all, pts1ed); uttari → uttariṁ (bj, sya-all) @pli-tv-bu-vb-pc47
pli-tv-bu-vb-pc47:2.2.1@Na bhesajjena karaṇīyena → na bhesajjena karaṇīye (bj, sya-all); na bhesajjakaraṇīyena (pts1ed) @pli-tv-bu-vb-pc47
pli-tv-bu-vb-pc48:1.7@Mahārājānaṁ mayaṁ daṭṭhukāmā → mahārāja mahārājānaṁ mayaṁ daṭṭhukāmā (pts1ed, mr) @pli-tv-bu-vb-pc48
pli-tv-bu-vb-pc48:1.8@yuddhābhinandinaṁ → yuddhābhinandiṁ (bj); yuddhābhinandinā (pts1ed, mr) @pli-tv-bu-vb-pc48
pli-tv-bu-vb-pc48:2.13.1@tathārūpappaccayā → … rūpapaccayā (sya-all, pts1ed) @pli-tv-bu-vb-pc48
pli-tv-bu-vb-pc49:1.15.1@dirattatirattaṁ → dviratta … (sya-all, pts1ed) @pli-tv-bu-vb-pc49
pli-tv-bu-vb-pc50:1.19.1@uyyodhikaṁ → uyyodhakaṁ (sya2ed) @pli-tv-bu-vb-pc50
pli-tv-bu-vb-pc50:2.3.15@senāviddho ime dasāti → uyyuttaṁ senuyyodhikanti (bj) @pli-tv-bu-vb-pc50
pli-tv-bu-vb-pc51:1.4@āsiviso → āsīviso (sya-all) @pli-tv-bu-vb-pc51
pli-tv-bu-vb-pc51:1.14@ambatitthassa → ambatitthakassa (bj, pts1ed); ambatitthaṁ (sya-all) @pli-tv-bu-vb-pc51
pli-tv-bu-vb-pc51:1.15@padhūpāyi → padhūpāsi (sya-all, pts1ed, mr); Disvāna dummano → dukkhī dummano (bj, sya-all) @pli-tv-bu-vb-pc51
pli-tv-bu-vb-pc51:1.38@pahoti nāgena → deḍḍhubhenāpi (bj); deḍḍubhenapi (sya-all) @pli-tv-bu-vb-pc51
pli-tv-bu-vb-pc52:2.1.1@nāma → aṅgulipatodako nāma aṅguliyāpi tudanti (sya-all) @pli-tv-bu-vb-pc52
pli-tv-bu-vb-pc52:2.1.2@hasādhippāyo → hassādhippāyo (bj, sya-all); hāsādhippāyo (pts1ed) @pli-tv-bu-vb-pc52
pli-tv-bu-vb-pc53:0.4@Surāpānavagga → hassadhammasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc53
pli-tv-bu-vb-pc53:1.22.1@hasadhamme → hassadhamme (bj, sya-all); hāsadhamme (pts1ed) @pli-tv-bu-vb-pc53
pli-tv-bu-vb-pc55:0.4@Surāpānavagga → bhiṁsāpanakasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc55
pli-tv-bu-vb-pc56:0.4@Surāpānavagga → jotisikkhāpadaṁ (bj) @pli-tv-bu-vb-pc56
pli-tv-bu-vb-pc56:1.1.1@susumāragire → suṁsumāragire (bj, cck, sya1ed, pts1ed); saṁsumāragire (mr) @pli-tv-bu-vb-pc56
pli-tv-bu-vb-pc57:1.1@samayena → atha kho (bj, sya-all) @pli-tv-bu-vb-pc57
pli-tv-bu-vb-pc57:2.7@gimhānanti → gimhānaṁ (itipi) @pli-tv-bu-vb-pc57
pli-tv-bu-vb-pc57:3.10@gimhānanti → gimhānaṁ (itipi) @pli-tv-bu-vb-pc57
pli-tv-bu-vb-pc57:6.7.1@nahāyeyya → nhāyeyya (sya-all, pts1ed); orenaddhamāsaṁ → orenaḍḍhamāsaṁ (sya-all) @pli-tv-bu-vb-pc57
pli-tv-bu-vb-pc58:2.1.12@kāḷasāmakaṁ → kāḷakaṁ (bj, sya-all) @pli-tv-bu-vb-pc58
pli-tv-bu-vb-pc60:0.4@Surāpānavagga → cīvarāpanidhānasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc60
pli-tv-bu-vb-pc60:1.18.1@hasāpekkhopi → hassāpekkhopi (bj, sya-all); hāsāpekkho pi (pts1ed) @pli-tv-bu-vb-pc60
pli-tv-bu-vb-pc60:2.3.10@hāso ca → toyañca (pts1ed) @pli-tv-bu-vb-pc60
pli-tv-bu-vb-pc61:0.4@Sappāṇakavagga → sañciccapāṇasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc61
pli-tv-bu-vb-pc64:1.8@vediyāmahaṁ → vedayāmahaṁ (sya-all) @pli-tv-bu-vb-pc64
pli-tv-bu-vb-pc64:1.11@āpajjitvā → āpajji (?) @pli-tv-bu-vb-pc64
pli-tv-bu-vb-pc65:2.1.9@sammannati → sammanati (mr) @pli-tv-bu-vb-pc65
pli-tv-bu-vb-pc66:1.7@kammiyā → kammikā (bj, sya-all, pts1ed) @pli-tv-bu-vb-pc66
pli-tv-bu-vb-pc67:1.9@apāyyo → apayyā (bj, sya-all) @pli-tv-bu-vb-pc67
pli-tv-bu-vb-pc68:1.53@dhammā antarāyikā vuttā → dhammā vuttā (sya-all) @pli-tv-bu-vb-pc68
pli-tv-bu-vb-pc68:1.54@Evañca → evañca pana (pts1ed, mr) @pli-tv-bu-vb-pc68
pli-tv-bu-vb-pc69:1.2@ariṭṭhena bhikkhunā → bhikkhunā gaddhabādhipubbena (?) @pli-tv-bu-vb-pc69
pli-tv-bu-vb-pc69:1.4@ariṭṭhena bhikkhunā → bhikkhunā gaddhabādhipubbane (?) @pli-tv-bu-vb-pc69
pli-tv-bu-vb-pc70:1.2@kaṇṭakassa → kaṇḍakassa (sya-all, pts1ed, mr) @pli-tv-bu-vb-pc70
pli-tv-bu-vb-pc70:1.51@Evañca → evañca pana (bj, pts1ed, mr) @pli-tv-bu-vb-pc70
pli-tv-bu-vb-pc71:2.1.9@ti → imāni padāni sya-all potthakesu na; vadeti → vadeyyāti (bj, mr) @pli-tv-bu-vb-pc71
pli-tv-bu-vb-pc72:1.3@Bhikkhūnaṁ etadahosi → bhikkhū (si, sya-all, pts-vp-pli1, mr) @pli-tv-bu-vb-pc72
pli-tv-bu-vb-pc73:1.17@bhiyyo → bhiyyoti (sya-all); uttari cassa → uttariṁ cassa (bj); uttariñcassa (sya-all) @pli-tv-bu-vb-pc73
pli-tv-bu-vb-pc73:1.18@manasi karosī’ti → manasikarosīti (sya-all, pts1ed); aṭṭhiṁ katvā → aṭṭhikatvā (bj, sya-all, pts1ed, mr) @pli-tv-bu-vb-pc73
pli-tv-bu-vb-pc77:1.19.1@upadaheyya → uppādeyya (itipi) @pli-tv-bu-vb-pc77
pli-tv-bu-vb-pc78:1.9@upassutiṁ → upassuti (?) @pli-tv-bu-vb-pc78
pli-tv-bu-vb-pc78:1.11@upassutiṁ → upassuti (?) @pli-tv-bu-vb-pc78
pli-tv-bu-vb-pc78:1.18.1@upassutiṁ → upassuti (?) @pli-tv-bu-vb-pc78
pli-tv-bu-vb-pc78:2.1.9@Upassutiṁ → upassuti (?) @pli-tv-bu-vb-pc78
pli-tv-bu-vb-pc78:2.3.2@vūpasamissāmi → vūpasamessāmi (si) @pli-tv-bu-vb-pc78
pli-tv-bu-vb-pc79:1.15@khīyanadhammaṁ → khīyadhammaṁ (pts1ed); khiyyadhammaṁ (itipi) @pli-tv-bu-vb-pc79
pli-tv-bu-vb-pc82:1.9@bhattā → bhaddāni (bj); bhaddā (mr) @pli-tv-bu-vb-pc82
pli-tv-bu-vb-pc83:0.4@Ratanavagga → rājavagga (pli-tv-pvr1.1:209 [Katthapaññattivāra/5. Rājavagga]; pli-tv-pvr1.2:143 [Katāpattivāra/5. Rājavagga]) @pli-tv-bu-vb-pc83
pli-tv-bu-vb-pc83:1.1.15@rathikāya → rathiyāya (sya-all, pts1ed) @pli-tv-bu-vb-pc83
pli-tv-bu-vb-pc83:1.1.18@Yamahaṁ → yampāhaṁ (bj) @pli-tv-bu-vb-pc83
pli-tv-bu-vb-pc83:1.3.51@rajanīyāni → rajaniyāni (sya-all); rajjanīyāni (csp1ed) @pli-tv-bu-vb-pc83
pli-tv-bu-vb-pc84:4.1.6@lohitaṅko → lohitako (?) @pli-tv-bu-vb-pc84
pli-tv-bu-vb-pc85:0.4@Ratanavagga → vikāle gāmappavesanasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc85
pli-tv-bu-vb-pc85:1.2@seyyathidaṁ → imā tiracchānakathāyo 6D.17/16D.201/1; 10M.223/1; 14S5.1080/1; 17A10.69/1; 25Cn.2.135/1; 10M.223/1 @pli-tv-bu-vb-pc85
pli-tv-bu-vb-pc85:1.3@itthikathaṁ → itthikathaṁ purisakathaṁ (bj, mr); itthīkathaṁ (sya-all) @pli-tv-bu-vb-pc85
pli-tv-bu-vb-pc86:1.20.1@visāṇamayaṁ → visānamayaṁ (bj) @pli-tv-bu-vb-pc86
pli-tv-bu-vb-pc86:2.2.1@pariyosāpeti → pariyosāvāpeti (mr) @pli-tv-bu-vb-pc86
pli-tv-bu-vb-pc86:2.3.2@gaṇṭhikāya → gaṇḍikāya (sya-all) @pli-tv-bu-vb-pc86
pli-tv-bu-vb-pc86:2.3.4@vidhe → vīṭhe (bj); vīthe (sya-all) @pli-tv-bu-vb-pc86
pli-tv-bu-vb-pc87:0.4@Ratanavagga → mañcasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc87
pli-tv-bu-vb-pc90:0.4@Ratanavagga → kaṇḍupaṭicchādisikkhāpadaṁ (bj) @pli-tv-bu-vb-pc90
pli-tv-bu-vb-pc91:0.4@Ratanavagga → vassikasāṭikasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc91
pli-tv-bu-vb-pc92:0.4@Ratanavagga → nandattherasikkhāpadaṁ (bj) @pli-tv-bu-vb-pc92
pli-tv-bu-vb-pc92:1.2@bhagavatā → bhagavato (bj, pts1ed, mr) @pli-tv-bu-vb-pc92
pli-tv-bu-vb-pc92:1.7@upagate jānitvā → upagate sañjānitvā (bj); upagataṁ sañjānitvā (sya-all) @pli-tv-bu-vb-pc92
pli-tv-bu-vb-pc92:2.2.8@Ratanavaggo → rājavaggo (bj) @pli-tv-bu-vb-pc92
pli-tv-bu-vb-pd2:1.15.1@tatra ce sā → tatra ce (sya-all); Ekassa cepi → ekassapi ce (bj, sya-all); na paṭibhāseyya → nappaṭibhāseyya (bj, sya-all) @pli-tv-bu-vb-pd2
pli-tv-bu-vb-pd2:2.1.14@Ekassa cepi → ekassapi ce (bj, sya-all); anapasādito → anapasādite (bj, sya-all, pts1ed) @pli-tv-bu-vb-pd2
pli-tv-bu-vb-pd3:3.15.1@sekkhasammatāni → sekha … (bj, pts1ed) @pli-tv-bu-vb-pd3
pli-tv-bu-vb-pd4:1.9@sabhaṇḍe → saha bhaṇḍena (pts1ed, mr) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pd4:1.16.1@senāsanesu → senāsanesu viharanto (bj, sya-all) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pd4:2.6@carituṁ → pavisituṁ (pts1ed, mr) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pd4:2.12.1@senāsanesu pubbe → senāsanesu viharanto pubbe (bj, sya-all) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pd4:3.1.14@etaṁ → etampi (bj) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pd4:3.1.33@carituṁ → gantuṁ (pts1ed, mr) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pd4:3.1.35@carituṁ → gantuṁ (pts1ed, mr) @pli-tv-bu-vb-pd4
pli-tv-bu-vb-pj1:1.1.5@bhagavā → bhagavāti (sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:1.2.1@sāraṇīyaṁ → sārāṇīyaṁ (bj, sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:1.3.3@anabhāvaṅkatā → anabhāvakatā (bj); anabhāvaṁ katā (sya-all); anabhāvaṁ gatā (pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:1.5.1@asammuṭṭhā → appamuṭṭhā (sya-all); vīriyaṁ → viriyaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:1.7.2@atikkantamānusakena → atikkantamānussakena (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:2.1.2@assavāṇijā → assavaṇijā (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:2.1.3@patthapatthapulakaṁ → patthapatthapūlakaṁ (sya-all); patthapatthamūlakaṁ (pts1ed, mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:2.1.11@paññapessāmāti → paññāpessāmāti (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:2.2.1@mahāmoggallāno → mahāmoggalāno (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:3.1.4@sāyanhasamayaṁ → sāyaṇhasamayaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:3.2.10@Akilāsuno → kilāsuno (sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:3.2.11@bhiṁsanake → bhīsanake (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:3.2.13@manasākattha → manasākarittha (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:3.4.3@paññapeyya → paññāpeyya (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:3.4.6@uddisati → na uddisati (bj) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:4.6@vassaṁvuṭṭhā → vassaṁ vutthā (bj, sya-all, pts1ed, mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:4.16@onītapattapāṇiṁ → oṇītapattapāṇiṁ (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.1.1@kalandagāmo nāma atthi → kalandagāmo nāma hoti (bj); kalandagāmo hoti (sya-all); kalandakagāmo nāma hoti (pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.2.2@ammatātā → amma tāta (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.4.13@anuññāto → anuññātomhi (bj, sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.5.5@maṁ → ñātakāpi maṁ (sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.6.1@chaḍḍetukāmā → chaṭṭetukāmā (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.6.9@kuṭṭamūlaṁ → kuḍḍamūlaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.6.14@Agamimha → agamamhā (sya-all, pts1ed, mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.6.22@opuñjāpetvā → opuñchāpetvā (bj, sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.7.14@opātehi → osādehi (bj, sya-all); otārehi (pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.7.19@manāpā ca → tvampi yāca (bj) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.8.13@pahūtadhanadhaññaṁ → pahūtadhanadhaññaṁ (…pe… carāmīti) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.9.25@cātumahārājikā → cātummahārājikā (bj, sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.11.6@ananucchavikaṁ → ananucchaviyaṁ (bj, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.11.19@āsivisassa → āsīvisassa (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.11.29@asantuṭṭhitāya → asantuṭṭhatāya (sya-all); vīriyārambhassa → viriyārambhassa (bj, cck, pts1ed); vīriyārabbhassa (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:5.11.31@paññapessāmi → paññāpessāmi (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:7.1.8@cepi → idānipi ce (sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:7.1.13@bhikkhave → yo pana bhikkhave bhikkhu (bj, pts1ed); yo kho bhikkhave bhikkhu (sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:7.1.14@ca kho, bhikkhave → yo ca kho bhikkhave bhikkhu (bj, sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:7.1.16.1@apaccakkhāya → appaccakkhāya (sya1ed, sya2ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:8.4.10@milakkhassa → milakkhakassa (sya-all); milakkhukassa (pts1ed); milakkhussa (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:9.1.9.1@paṭisevantassa → patisevantassa (bj) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:9.3.2@pavesanaṁ sādiyati → pavisanaṁ sādayati (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.6.3@tāniyeva → tāni (bj, sya-all, pts1ed); saṅgamituṁ → saṅkamituṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.6.8@tāniyeva → tāni (bj, sya-all, pts1ed); saṅgamituṁ → saṅkamituṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.11.1@rathikāya → rathiyāya (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.11.3@muhuttaṁ → itthī taṁ passitvā etadavoca muhuttaṁ (sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.13.20@kālaṅkatā → kālakatā (bj, sya-all) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.15.2@vediyāmi → vedayāmi (mr) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.20.10@pavattesi → pavaṭṭesi (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.22.1@supinante → supinantena (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.23.1@mudhappasannā → muddhappasannā (bj); muduppasannā (sya-all); buddhappasannā (pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.23.7@ūruntarikāya → ūrantarikāya (bj); urantarikāya (pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj1:10.26.4@ubbhajitvā → ubbhujitvā (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj1
pli-tv-bu-vb-pj2:1.1.16@lohitikā → lohitakā (sya-all) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:1.1.17@kiṅkaṇikasaddo → kiṅkiṇikasaddo (bj, sya-all); kiṅkiṇikāsaddo (pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:1.3.10@dārukuṭikaṁ → dārukuḍḍikaṁ kuṭikaṁ (bj) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:1.3.16@samacārino → sammacārino (mr) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:1.4.8@saccaṁ kira devena → saccaṁ kira deva devena (bj, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:1.4.12@bandhaṁ → baddhaṁ (bj, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:1.6.24@Pādena vā, bhagavā, pādārahena vā”ti → pādārahena vā atirekapādena vāti (sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:3.8@indakhīle → indakhile (mr) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:3.39@pavutto → pamutto (pts1ed); pavuttho (itipi); haritatthāya → haritattāya (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:4.1.1@vanappati → vanaspati (bj); dantapoṇaṁ → dantaponaṁ (bj, mr) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:4.2.5@byūhati → vyūhati (bj, pts1ed); viyūhati (sya-all) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:4.21.4@rājaggaṁ → rājagghaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:5.4.21@sādhū”ti → suṭṭhūti (bj, pts1ed, mr) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.2@sasaññissa → sakasaññissa (bj, sya-all, pts1ed); sasaññassa (si) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.9@khittacittassa → si, sya-all, pts1ed potthakesu natthi @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.10@ vedanāṭṭassa → si, sya-all, pts1ed potthakesu natthi @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.21@jantaggena → jantāgharena (sya-all); jantagghena (pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.24@kuramaṁsañca → kūramaṁsañca (sya-all); kuru-maṁsañ ca (pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.26@Chaparikkhārathavikā → saparikkhārathavikaṁ (bj); saparikkhārathavikā (sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.46@Dārudakā → dārudakaṁ (bj); dārūdakā (sya1ed, sya2ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:6.4.47@avahāsi seyyaṁ → avahāsiseyyuṁ (bj); avahāsi theyyaṁ (pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.13.4@sūnagharaṁ → sūnāgharaṁ (bj) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.18.4@Nikkhami → nikkhameyya (bj, sya-all, pts1ed); nikkhami → nikkhameyya (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.28.3@pavaṭṭetvā → pavattetvā (pts1ed, mr) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.30.1@osārenti → osādenti (bj) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.36.2@paṭiggahāpetvā → paṭiggāhāpetvā (bj) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.38.7@Paribhogatthāya → paribhogatthā (bj) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.42.6@bibbohanaṁ → bimbohanaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.46.3@saddho hoti pasanno tassa ācikkheyyāsī”ti → ācikkheyyāsīti so kālamakāsi (sya-all) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.47.10@iddhimassa → iddhimato (bj); iddhimantassa (sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.48.7@Taṁ uttiṇṇaṁ gopālikā → aññatarā gopālikā (bj, sya-all) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj2:7.49.9@abhiramatīti → abhiramīti (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj2
pli-tv-bu-vb-pj3:1.1.6@paṭissuṇitvā → paṭissutvā (bj); paṭisuṇitvā (pts1ed) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:1.1.8@te → atirekapāṭhena bhavitabbaṁ. evamuparipi īdisesu @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:1.1.16@lohitakaṁ → lohitagataṁ (pts1ed, mr) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:1.3.2@uhataṁ → ūhataṁ (bj, sya-all, pts1ed, mr) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:1.4.2@vadanti → vadenti (bj, sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:2.50@mataṁ te → matante (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:3.12@bheṇḍiṁ vā → bhendiṁ vā (mr); laguḷaṁ vā → lagulaṁ (si); sūlaṁ vā laguḷaṁ vā (sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:3.42@dvidhā bhinnā → dvedhā bhinnā (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:4.9.2@upasaṁharati → upasaṁharati pemanīyaṁ hadayaṅgamaṁ (sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:4.9.16@pāṭikulyaṁ → paṭikūlaṁ (?) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:4.9.23@pāṭikulyaṁ → paṭikūlaṁ (?) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:4.11.3@ajānantassa … ummattakassa → ummattakassa khittacittassa vedanaṭṭassa (bj, sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:4.11.11@Vuḍḍhapabbajitābhisanno → buddhapabbajitā satta (bj); vuḍḍhapabbajitā santo (sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:5.7.1@āḷavakā → ālavakā (bj); āḷavikā (sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:5.22.2@uttanto → uttasanto (bj, sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:5.22.4@anāpatti, bhikkhave, pārājikassā”ti → āpatti pācittiyassāti (sya-all) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj3:5.31.1@ālimpesuṁ → āḷimpesuṁ (mr) @pli-tv-bu-vb-pj3
pli-tv-bu-vb-pj4:1.1.22@bhāsissāma → bhāsāma (bj) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:1.1.41@yesaṁ no → vata no (csp1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:1.2.22@govikantanena → govikattanena (bj, pts1ed, mr); govikatthanena (si) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:1.3.17@bibbohanaṁ → bimbohanaṁ (bj, sya-all, pts1ed); parasu → pharasu (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:1.3.35@bhagavā → bhagavā te (csp1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:2.9@ānanda → honti te ānanda (bj); honti yevānanda (cck); hontiyevānanda (sya1ed, sya2ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:2.12.1@attupanāyikaṁ → attūpanāyikaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:2.13@samanuggāhīyamāno → samanuggāhiyamāno (bj, sya-all); asamanuggāhīyamāno → asamanuggāhiyamāno (bj, sya-all) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:3.8@vimokkho → vimokkhaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:4.1.16@arahattassa → arahattaphalassa (sya-all, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:4.8.115@Ekamūlakaṁ niṭṭhitaṁ → ekamūlakaṁ saṅkhittaṁ niṭṭhitaṁ (sya-all); ekamūlakaṁ (pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:5.1.42@Vatthuvisārakassa → vattuvissārakassa (bj) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:5.4.8@Tīhākārehi dutiyañca jhānaṁ tatiyañca jhānaṁ … na paṭivijānantassa āpatti thullaccayassa (5.4.18) → etthantare pātho sya-all potthakesu natthi @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:6.1.8@pubbevassa hoti musā bhaṇissanti → etthantare pātho csp1ed, csp2ed potthakesu natthi @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:6.1.9@bhaṇantassa hoti musā bhaṇāmīti → etthantare pātho csp1ed, csp2ed potthakesu natthi @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:6.1.10@bhaṇitassa hoti musā mayā bhaṇitanti. → etthantare pātho csp1ed, csp2ed potthakesu natthi @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:7.9@Adhimāne → adhimānena (bj, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:8.11.4@na arahanto → anarahanto (bj, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.1.9@etassa pañhassa → paṇhassa byākaraṇāya (sya-all) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.2.7@vituḍenti → vitudanti (bj); vitudenti vitacchenti virājenti (sya-all); vitudenti (pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.3.2@vitacchenti vibhajjenti → vitacchenti virājenti (bj); vitudenti vitacchenti virājenti (sya-all); vitacchenti vibhajenti (pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.3.48@doṇiyo → doṇiyā (si, sya-all, pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.3.49@ato → ito (sya-all); aho (pts1ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.4.6@kuthitā → kuṭṭhitā (sya1ed, sya2ed) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-pj4:9.5.1@ahosi → hoti (bj, sya-all) @pli-tv-bu-vb-pj4
pli-tv-bu-vb-sk3:1.3.1@Suppaṭicchanno → supaṭicchanno (bj, sya-all, pts1ed) @pli-tv-bu-vb-sk3
pli-tv-bu-vb-sk26:1.2@pallatthikāya → pallattikāya (mr) @pli-tv-bu-vb-sk26
pli-tv-bu-vb-sk28:1.2@atikkantepi → atikkamantepi (bj) @pli-tv-bu-vb-sk28
pli-tv-bu-vb-sk30:1.3.1@Samatittikaṁ → samatitthikaṁ (pts1ed, mr) @pli-tv-bu-vb-sk30
pli-tv-bu-vb-sk30:1.4@Samatittiko → samatitthiko (pts1ed, mr) @pli-tv-bu-vb-sk30
pli-tv-bu-vb-sk31:0.4@Sakkaccavagga → piṇḍapātavagga (pli-tv-pvr1.1:272 [Katthapaññattivāra/7. Piṇḍapātavagga]; pli-tv-pvr1.2:192 [Katāpattivāra/7. Piṇḍapātavagga]) @pli-tv-bu-vb-sk31
pli-tv-bu-vb-sk33:1.2@omasitvā → omadditvā (pts1ed, mr) @pli-tv-bu-vb-sk33
pli-tv-bu-vb-sk33:1.5@omasitvā → omadditvā (pts1ed, mr) @pli-tv-bu-vb-sk33
pli-tv-bu-vb-sk35:1.3.1@thūpakato → thūpato (bj, sya-all, pts1ed) @pli-tv-bu-vb-sk35
pli-tv-bu-vb-sk47:1.3.1@hatthaniddhunakaṁ → hatthaniddhūnakaṁ (sya-all) @pli-tv-bu-vb-sk47
pli-tv-bu-vb-sk55:1.1@susumāragire → suṁsumāragire (bj, sya-all, pts1ed); saṁsumāragire (mr) @pli-tv-bu-vb-sk55
pli-tv-bu-vb-sk55:1.2@kokanade → kokanude (mr) @pli-tv-bu-vb-sk55
pli-tv-bu-vb-sk61:0.4@Pādukavagga → pādukāvaggo (sya-all) @pli-tv-bu-vb-sk61
pli-tv-bu-vb-sk61:1.3.1@pādukāruḷhassa → pādukārūḷhassa (bj, sya-all, pts1ed) @pli-tv-bu-vb-sk61
pli-tv-bu-vb-sk62:1.3.1@upāhanāruḷhassa → upāhanārūḷhassa (bj, sya-all, pts1ed) @pli-tv-bu-vb-sk62
pli-tv-bu-vb-sk68:1.3.1@chamāyaṁ → chamāya (bj, pts1ed) @pli-tv-bu-vb-sk68
pli-tv-bu-vb-sk68:1.4@nisīditvā → nisinnena (aṭṭha.) @pli-tv-bu-vb-sk68
pli-tv-bu-vb-sk69:1.12.1@chapakassa → chavakassa (sya-all) @pli-tv-bu-vb-sk69
pli-tv-bu-vb-sk69:1.15@ambaṁ → ambo (bj, sya-all) @pli-tv-bu-vb-sk69
pli-tv-bu-vb-sk75:2.20@Pannarasamasikkhāpadaṁ → paṇṇarasamasikkhāpadaṁ (bj) @pli-tv-bu-vb-sk75
pli-tv-bu-vb-sk75:2.21@Pādukavaggo → pādukāvaggo (bj, sya-all); bj potthake uddānaṁ @pli-tv-bu-vb-sk75
pli-tv-bu-vb-ss1:1.2.22.1@sukkavissaṭṭhi → sukkavisaṭṭhi (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:2.1.13.1@sukkavissaṭṭhi → sukkavisaṭṭhi (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:3.2.2@upādinne → upādinna (sya-all, pts1ed); upādiṇṇe (mr) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:3.7.1@Ārogyatthañca nīlañca → ārogyatthaṁ nīlaṁ (?) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:3.7.4@(Ubhatovaḍḍhakaṁ evameva vaḍḍhetabbaṁ.) → (…) sya-all potthakesu passitabbaṁ; vaḍḍhetabbaṁ → netabbaṁ (bj) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:3.7.6@Missakacakkaṁ → ubhatobaddhamissakacakkaṁ (sya-all) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:3.8.21@(…) → (…) sya-all potthakesu @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:4.20@jantāgharupakkamo → jantāgharaṁ ūru (bj, sya-all) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:4.27@kaddamusseko → kaddamudako (pts1ed); kaddamoseko (?) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:5.5.2@Bhesajjena → tassa bhesajjena (?) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:5.5.6@Mocanādhippāyassa → tassa mocanādhippāyassa (sya-all) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:5.6.4@kaṇḍuvantassa → kaṇḍūvantassa (bj) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss1:5.16.17@pupphāvaliyaṁ → pupphāvaḷiyaṁ (sya-all, pts1ed, mr) @pli-tv-bu-vb-ss1
pli-tv-bu-vb-ss2:1.1.11@avāpuraṇaṁ → apāpuraṇaṁ (sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:1.1.29@Sace → sace hi (sya-all); kuladhītaro → kuladhītayo (bj); kuladhītāyo (si, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:1.2.15.1@veṇiggāhaṁ → veṇigāhaṁ (bj, sya-all, pts1ed); hatthaggāhaṁ → hatthagāhaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:2.2.15@āviñchanā → āviñjanā (sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:3.7.8@vedanāṭṭassa → vedanaṭṭassa (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:4.5.1@ānesuṁ → nesuṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:4.9.1@āviñchi → āviñji (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:4.9.5@āviñchi → āviñji (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss2:4.11.8@niṭṭhitaṁ dutiyaṁ → niṭṭhitaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss2
pli-tv-bu-vb-ss3:1.2.14.1@yathā taṁ → yathātaṁ (sya-all); methunupasaṁhitāhi → methunūpasañhitāhi (bj, sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:3.1.9@kadā → kadā te (sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:3.1.21@dentā → dentī (bj, sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:3.1.23@dentā → dentī (bj, sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:4.2.5@kharakambalo → kharakambalako (bj, csp1ed); kakkasakambalo (sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:4.4.5@kharakambalako → kharakambalo (sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:4.5.1@itthī pāvāraṁ → dīghapāvāraṁ (sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss3:4.5.5@Āmāyya, pāvāro → dīghapāvāro (sya-all) @pli-tv-bu-vb-ss3
pli-tv-bu-vb-ss4:1.1.20@niṭṭhubhitvā → nuṭṭhuhitvā (sya-all) @pli-tv-bu-vb-ss4
pli-tv-bu-vb-ss4:1.2.8@Atha kho te bhikkhū āyasmantaṁ udāyiṁ anekapariyāyena vigarahitvā bhagavato → atha kho te bhikkhū bhagavato (si, sya-all, pts1ed) @pli-tv-bu-vb-ss4
pli-tv-bu-vb-ss4:2.19@khattiyī → khattiyā (bj, sya-all); khatti (si) @pli-tv-bu-vb-ss4
pli-tv-bu-vb-ss5:1.1.11@Channāyaṁ kumārikā tassa kumārakassā”ti → channo so kumārako imissā kumārikāyāti (sya-all) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:1.2.4@khvayyo → khvayyā (bj, sya-all); khvāyyo (mr) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:1.4.8@sukhamedho hotu → sukhamedhatu (bj, sya-all); sukhamedhito hotu (mr) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:2.1.1@aññatarissā → aññatarassā (bj) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:2.1.4@khvayyo → khveyyā (bj, sya-all) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:2.2.13.1@itthimatiṁ → itthīmatiṁ (bj, sya-all) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:4.3.11@Obhaṭacumbaṭā → ohata … (bj); obhata (sya-all, pts1ed) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:4.4.1@pahiṇati → pahiṇatiṁ (bj) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:4.4.53@(…) → (…) sya-all potthakesu @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:4.7.13@ubhatovaḍḍhakaṁ → … vaḍḍhamānaṁ (bj); … baddhakaṁ (sya-all) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:4.10.6@gottā → sagottā (?) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss5:5.1.1@āṇāpesi → āṇāpeti (sya-all, pts1ed, mr) @pli-tv-bu-vb-ss5
pli-tv-bu-vb-ss6:1.3.3@bhayā → bhayāmhi (bj) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.3.12@maṇimassa → maṇissa (bj, pts1ed, mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.3.45@Tathā pakkantova → tadā pakkanto pakkantova (bj); tadā pakkantova (pts1ed, mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.3.52@jigīse → jigiṁse (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.3.53@Videsso → desso (bj); desso ca (sya-all) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.3.57@Kimaṅgaṁ → kimaṅga (bj, pts1ed) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.5.9@videssanā → viddesanā (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.6.3@parasuṁ → pharasuṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.6.7@vatthu → vatthuṁ (bj, sya-all); anārambhaṁ → anārabbhaṁ (mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:1.6.8@Sārambhe → sārabbhe (mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:2.2.20@sammuti → sammati (bj, sya-all) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:2.3.2@undūrānaṁ → undurānaṁ (sya-all, pts1ed) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:2.3.3@saṁsaraṇanissitaṁ vā → sañcaraṇanissitaṁ vā (mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:2.3.8@undūrānaṁ → undurānaṁ (sya-all) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:2.4.8@kārāpeti vā, payoge → payoge payoge (bj, csp1ed) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:3.15.2@pariyosāpeti → pariyosāvāpeti (mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss6:3.15.4@pariyosāpeti → pariyosāvāpeti (mr) @pli-tv-bu-vb-ss6
pli-tv-bu-vb-ss7:1.7@viheṭhentī → viheṭhessanti (katthaci) @pli-tv-bu-vb-ss7
pli-tv-bu-vb-ss7:3.4.22@hotū”ti → hotūti …pe… anārambhaṁ saparikkamanaṁ (bj); hotūti …pe… (sya-all) @pli-tv-bu-vb-ss7
pli-tv-bu-vb-ss8:1.1.3@Yaṁ kiñci → yañca kiñci (si, mr) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.4.5@vinicchinissantī”ti → vinicchissantīti (pts1ed, mr) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.4.9@na byābādhissantī”ti → na byābāhissantīti (mr) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.4.10@kāyadaḷhibahulā → kāyadaḍḍhibahulā (bj); kāyadaḷhībahulā (sya-all, pts1ed) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.5.1@mettiyabhūmajakā → mettiyabhummajakā (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.7.10@mayaṁ koṭṭhake nisīdeyyāmā”ti → nisīdāpiyeyyāmāti (bj); nisīdāpiyāmāti (sya-all); nisīdāpeyyāmāti (pts1ed); Yathā → yāva (bj) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.7.14@niccabhattikāti → niccabhattikattha (bj); niccabhattikāttha (csp1ed) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.7.19@antare → santike (bj, sya-all, pts1ed, mr) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.8.17@savātaṁ → pavātaṁ (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:1.9.32.1@appeva nāma → appevanāma (bj, sya-all) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss8:3.4.2@pamuṭṭho → pammuṭṭho (bj); sammuṭṭho (pts1ed) @pli-tv-bu-vb-ss8
pli-tv-bu-vb-ss9:0.3@Saṅghādisesakaṇḍa → aññabhāgiyasikkhāpada (kaṅkhāvitaraṇī) @pli-tv-bu-vb-ss9
pli-tv-bu-vb-ss9:1.1.2@chagalakaṁ → chakalakaṁ (si, sya-all, pts1ed) @pli-tv-bu-vb-ss9
pli-tv-bu-vb-ss9:2.3.4@khattiyo diṭṭho hoti pārājikaṁ dhammaṁ ajjhāpajjanto → ettha “pārājikaṁ dhammaṁ ajjhāpajjanto” ti pāṭho ūno maññe, aṭṭhakathāyaṁ hi “khattiyo mayā diṭṭho pārājikaṁ dhammaṁ ajjhāpajjanto” ti dissati @pli-tv-bu-vb-ss9
pli-tv-bu-vb-ss9:2.4.16@tesaṁ lesānaṁ → dasannaṁ lesānaṁ (sya-all) @pli-tv-bu-vb-ss9
pli-tv-bu-vb-ss10:1.1.2@kaṭamodakatissako → kaṭamorakatissako (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss10
pli-tv-bu-vb-ss10:1.1.8@vīriyārambhassa → viriyārambhassa (sya-all, pts1ed); vīriyārabbhassa (csp1ed) @pli-tv-bu-vb-ss10
pli-tv-bu-vb-ss10:1.1.24@Lūkhapasannā → lūkhappasannā (bj, sya-all, pts1ed 4V.343/1) @pli-tv-bu-vb-ss10
pli-tv-bu-vb-ss10:1.3.17@māyasmā → mā āyasmā (bj, sya-all) @pli-tv-bu-vb-ss10
pli-tv-bu-vb-ss10:1.3.20@paṭinissajjeyya → paṭinissajeyya (bj) @pli-tv-bu-vb-ss10
pli-tv-bu-vb-ss10:2.29@bhikkhu → bhikkhu bhikkhūti (bj) @pli-tv-bu-vb-ss10
pli-tv-bu-vb-ss11:1.6@kokāliko → kokāliko ca (bj); samuddadatto → samuddadatto ca (bj) @pli-tv-bu-vb-ss11
pli-tv-bu-vb-ss11:1.24@māyasmanto → mā āyasmanto (bj, sya-all) @pli-tv-bu-vb-ss11
pli-tv-bu-vb-ss11:1.26@māyasmantānampi → mā āyasmantānampi (bj, sya-all); māyasmantānaṁ pi (pts1ed) @pli-tv-bu-vb-ss11
pli-tv-bu-vb-ss11:3.1.1@dhammakammasaññī → dhammakammasaññino (si) @pli-tv-bu-vb-ss11
pli-tv-bu-vb-ss12:1.11@ussāreyya → ussādeyya (bj, sya-all); tiṇakaṭṭhapaṇṇasaṭaṁ → tiṇakaṭṭhapaṇṇakasaṭaṁ (mr) @pli-tv-bu-vb-ss12
pli-tv-bu-vb-ss12:1.30@vacanīyamevāyasmā → vacanīyameva āyasmā (sya-all); vacanīyaṁ eva āyasmā (pts1ed) @pli-tv-bu-vb-ss12
pli-tv-bu-vb-ss12:1.32@saṁvaddhā → saṁvaḍḍhā (sya-all) @pli-tv-bu-vb-ss12
pli-tv-bu-vb-ss12:1.34@samanubhāsiyamāno → samanubhāsiyamāno (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss12
pli-tv-bu-vb-ss13:1.1.2@nāma → nāma bhikkhū (si, mr) @pli-tv-bu-vb-ss13
pli-tv-bu-vb-ss13:1.2.3@purato → purato dhāvanti (bj, sya-all, pts1ed) @pli-tv-bu-vb-ss13
pli-tv-bu-vb-ss13:1.2.5@naccakiṁ → naccantiṁ (bj, sya-all) @pli-tv-bu-vb-ss13
pli-tv-bu-vb-ss13:1.6.20@rathassapi purato dhāvissantipi → purato dhāvissanti dhāvissantipi (bj, sya-all) @pli-tv-bu-vb-ss13
pli-tv-bu-vb-ss13:1.7.3@āpattiṁ → āpatti (bj, sya-all) @pli-tv-bu-vb-ss13
pli-tv-bu-vb-ss13:1.8.1@kīṭāgirismā → kīṭāgirismiṁ (bj); kīṭāgirismi (si); kiṭāgirismā (sya-all, pts1ed) @pli-tv-bu-vb-ss13
pli-tv-bu-vb-ss13:2.8@vā → veḷunā vā (bj, sya-all) @pli-tv-bu-vb-ss13
pli-tv-bi-vb-as1:1.1@panāyyāyo → panayyāyo (bj, sya-all, pts1ed) @pli-tv-bi-vb-as1-7
pli-tv-bi-vb-np2:1.2@vassaṁvuṭṭhā → vassaṁ vutthā (bj, sya-all, pts1ed) @pli-tv-bi-vb-np2
pli-tv-bi-vb-np2:1.19@bhājāpetī”ti → bhājāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-np2
pli-tv-bi-vb-np3:1.3@saṅgharitvā → saṁharitvā (bj, pts1ed, mr) @pli-tv-bi-vb-np3
pli-tv-bi-vb-np3:1.14@acchindatī”ti → acchindīti (bj, mr) @pli-tv-bi-vb-np3
pli-tv-bi-vb-np3:1.20.1@parivattetvā → parivaṭṭetvā (sya-all); handāyye → handayye (bj, sya-all, pts1ed) @pli-tv-bi-vb-np3
pli-tv-bi-vb-np4:1.13@ādiyissāma → āharissāma (si, pts1ed, mr); vikkāyissati → vikkīyissati (?) @pli-tv-bi-vb-np4
pli-tv-bi-vb-np4:1.21@viññāpetī”ti → viññāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-np4
pli-tv-bi-vb-np4:2.3.2@taññeva → tañceva (sya-all, pts1ed) @pli-tv-bi-vb-np4
pli-tv-bi-vb-np5:1.22@cetāpetī”ti → cetāpesīti (mr) @pli-tv-bi-vb-np5
pli-tv-bi-vb-np5:2.24@taññeva → tañceva (sya-all) @pli-tv-bi-vb-np5
pli-tv-bi-vb-np10:1.4@undriyati → uddīyati (bj); udrīyati (sya-all); udriyati (pts1ed) @pli-tv-bi-vb-np10
pli-tv-bi-vb-np11:0.4@Cīvaravagga → nissaggiyakaṇḍassa vagganāmā kaṅkhāvitaraṇīaṭṭhakathāya 46–51 piṭṭhesu @pli-tv-bi-vb-np11
pli-tv-bi-vb-np11:1.15@viññāpetī”ti → viññāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-np11
pli-tv-bi-vb-np11:1.21.1@Garupāvuraṇaṁ → garupāpuraṇaṁ (bj, sya-all); uttari → uttariṁ (bj, sya-all) @pli-tv-bi-vb-np11
pli-tv-bi-vb-np12:1.15@viññāpetī”ti → viññāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-np12
pli-tv-bi-vb-np12:2.2.13.0@10 Pariṇatasikkhāpada → pli-tv-bu-vb-np18:5 [Nissaggiyā Pācittiyā 18: Rūpiyasikkhāpada] (18:37) @pli-tv-bi-vb-np12
pli-tv-bi-vb-pc1:1.19@harāpetī”ti → harāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc1
pli-tv-bi-vb-pc1:1.41.1@lasuṇaṁ → lasunaṁ (bj) @pli-tv-bi-vb-pc1
pli-tv-bi-vb-pc4:1.2@aññatarā purāṇarājorodhā bhikkhunīsu pabbajitā → aññataro purāṇarājorodho bhikkhunīsu pabbajito (sya-all) @pli-tv-bi-vb-pc4
pli-tv-bi-vb-pc4:1.15@ādiyatī”ti → ādiyīti (bj, pts1ed, csp1ed) @pli-tv-bi-vb-pc4
pli-tv-bi-vb-pc4:1.21.1@Jatumaṭṭhake → jatumaṭṭake (bj) @pli-tv-bi-vb-pc4
pli-tv-bi-vb-pc5:1.2.6@ādiyatī”ti → ādiyīti (bj, pts1ed, csp1ed) @pli-tv-bi-vb-pc5
pli-tv-bi-vb-pc7:1.14.1@viññāpetvā → viññāpāpetvā (bj, sya-all); koṭṭetvā → koṭṭitvā (pts1ed); viññatvā → viññāpetvā (bj, sya-all); viññitvā (pts1ed) @pli-tv-bi-vb-pc7
pli-tv-bi-vb-pc8:1.26.1@tirokuṭṭe → tirokuḍḍe (bj, sya-all, pts1ed) @pli-tv-bi-vb-pc8
pli-tv-bi-vb-pc9:2.3.3@khettamariyāde → chaḍḍitakhette (bj) aṭṭhakathā oloketabbā @pli-tv-bi-vb-pc9
pli-tv-bi-vb-pc11:2.2.2@dutiyo → yā kāci viññū dutiyā (sya-all) @pli-tv-bi-vb-pc11
pli-tv-bi-vb-pc14:1.11.1@rathikāya → rathiyāya (bj, sya-all, pts1ed) @pli-tv-bi-vb-pc14
pli-tv-bi-vb-pc15:1.13@pakkamatī”ti → pakkamīti (bj, mr); pakkāmīti (pts1ed) @pli-tv-bi-vb-pc15
pli-tv-bi-vb-pc18:1.9@ujjhāpetī”ti → ujjhāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc18
pli-tv-bi-vb-pc18:2.1.6@gahitena → uggahitena (pts1ed, mr) @pli-tv-bi-vb-pc18
pli-tv-bi-vb-pc21:0.4@Naggavagga → nahānavagga (pli-tv-pvr2.1:79 [Katthapaññattivāra/4. Nahānavagga]; pli-tv-pvr2.2:52 [Katāpattivāra/4. Nahānavagga]) @pli-tv-bi-vb-pc21
pli-tv-bi-vb-pc21:1.4@tumhākaṁ, ayye, daharānaṁ → daharānaṁ daharānaṁ (bj) @pli-tv-bi-vb-pc21
pli-tv-bi-vb-pc22:1.4@dhāresuṁ → dhārenti (bj) @pli-tv-bi-vb-pc22
pli-tv-bi-vb-pc22:2.1.2@nivatthā → nivatthāya (sya-all) @pli-tv-bi-vb-pc22
pli-tv-bi-vb-pc24:1.16.1@saṅghāṭicāraṁ → saṅghāṭivāraṁ (sya-all) @pli-tv-bi-vb-pc24
pli-tv-bi-vb-pc25:1.12@pārupatī”ti → pārupīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc25
pli-tv-bi-vb-pc26:1.9@paribāhirā → parihīnā (bj) @pli-tv-bi-vb-pc26
pli-tv-bi-vb-pc26:2.1.10@kathaṁ ime cīvaraṁ na → ime cīvaraṁ (bj); imaṁ cīvaraṁ (sya-all, pts1ed, mr) @pli-tv-bi-vb-pc26
pli-tv-bi-vb-pc27:1.8@pakkamiṁsu → vippakkamiṁsu (sya-all, pts1ed) @pli-tv-bi-vb-pc27
pli-tv-bi-vb-pc27:1.12@paṭibāhatī”ti → paṭibāhīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc27
pli-tv-bi-vb-pc27:2.1.8@cīvaraṁ na bhājeyyāti → cīvaraṁ bhājeyyāti (bj, sya-all, pts1ed, mr) @pli-tv-bi-vb-pc27
pli-tv-bi-vb-pc28:1.2@kumbhathūṇikānampi → kumbhathūnikānaṁpi (sya-all); kumbhathuṇikānampi (mr); sokajjhāyikānampi → sokasāyikānampi (bj) @pli-tv-bi-vb-pc28
pli-tv-bi-vb-pc28:1.3@parisati → parisatiṁ (bj) @pli-tv-bi-vb-pc28
pli-tv-bi-vb-pc28:1.15.1@agārikassa → āgārikassa (sya-all) @pli-tv-bi-vb-pc28
pli-tv-bi-vb-pc29:1.15@atikkāmetī”ti → atikkāmesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc29
pli-tv-bi-vb-pc30:1.2.9@paṭibāhatī”ti → paṭibāhīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc30
pli-tv-bi-vb-pc30:1.2.15.1@kathinuddhāraṁ → kaṭhinuddhāraṁ (bj, sya-all, pts1ed) @pli-tv-bi-vb-pc30
pli-tv-bi-vb-pc30:2.1.8@kathinaṁ na uddhareyyā”ti → kathinaṁ uddhareyyāti (bj, pts1ed, mr); kaṭhinaṁ uddhareyyāti (sya-all) @pli-tv-bi-vb-pc30
pli-tv-bi-vb-pc32:1.14.1@ekattharaṇapāvuraṇā → ekattharaṇapāpuraṇā (bj, sya-all) @pli-tv-bi-vb-pc32
pli-tv-bi-vb-pc32:2.2.4@nānāpāvuraṇe → nānāpāpuraṇasaññā (bj); nānāpāpuraṇe (sya-all); nānāpāvuraṇasaññā (pts1ed, mr) @pli-tv-bi-vb-pc32
pli-tv-bi-vb-pc32:2.2.5@ekapāvuraṇe → ekapāpuraṇasaññā (bj); ekapāpuraṇe (sya-all); ekattharaṇapāvuraṇasaññā (pts1ed); ekapāvuraṇasaññā (mr) @pli-tv-bi-vb-pc32
pli-tv-bi-vb-pc35:1.9@bahussutā → bahussutāyeva (mr) @pli-tv-bi-vb-pc35
pli-tv-bi-vb-pc35:1.17@nikkaḍḍhatī”ti → nikkaḍḍhīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc35
pli-tv-bi-vb-pc35:2.1.18@pācittiyassa → ettha @pli-tv-bi-vb-pc35
pli-tv-bi-vb-pc36:1.12@Viviccāyye → viviccayye (bj, pts1ed); viviccāhayye (sya-all) @pli-tv-bi-vb-pc36
pli-tv-bi-vb-pc36:1.13@Evañca → evañca pana (pts1ed, mr) @pli-tv-bi-vb-pc36
pli-tv-bi-vb-pc36:2.1.10@keci → yo koci (sya-all, pts1ed, mr) @pli-tv-bi-vb-pc36
pli-tv-bi-vb-pc40:1.13.1@vassaṁvuṭṭhā → vassaṁ vutthā (bj, sya-all, pts1ed) @pli-tv-bi-vb-pc40
pli-tv-bi-vb-pc42:2.1.8@āharimehi → iti kaṅkhāvitaraṇiyā sameti @pli-tv-bi-vb-pc42
pli-tv-bi-vb-pc48:1.16@pakkamatī”ti → pakkamīti (bj, mr); pakkāmīti (pts1ed) @pli-tv-bi-vb-pc48
pli-tv-bi-vb-pc49:2.1.5@Tiracchānavijjā → tiracchānavijjaṁ (bj, mr) @pli-tv-bi-vb-pc49
pli-tv-bi-vb-pc50:2.5@Tiracchānavijjā → tiracchānavijjaṁ (bj, mr) @pli-tv-bi-vb-pc50
pli-tv-bi-vb-pc51:2.7@paññattaṁ → paññattaṁ hoti (pts1ed, csp1ed) @pli-tv-bi-vb-pc51
pli-tv-bi-vb-pc52:1.3@mahattarā → mahantatarā (bj); mahatarā (pts1ed) @pli-tv-bi-vb-pc52
pli-tv-bi-vb-pc53:1.21@paribhāsatī”ti → paribhāsīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc53
pli-tv-bi-vb-pc54:1.3@bhuttāvī → bhuttāvinī (mr) @pli-tv-bi-vb-pc54
pli-tv-bi-vb-pc54:1.13@bhuttāvī → bhuttāvinī (mr) @pli-tv-bi-vb-pc54
pli-tv-bi-vb-pc55:1.6@kathañhi nāma → kathaṁ aññā (sya-all) @pli-tv-bi-vb-pc55
pli-tv-bi-vb-pc57:1.5@kattha → kacci (sya-all) @pli-tv-bi-vb-pc57
pli-tv-bi-vb-pc57:1.15.1@na pavāreyya → nappavāreyya (bj, sya-all) @pli-tv-bi-vb-pc57
pli-tv-bi-vb-pc59:1.11.1@paccāsīsitabbā → paccāsiṁsitabbā (bj, sya-all, pts1ed); Anvaddhamāsaṁ → anvaḍḍhamāsaṁ pana (sya-all) @pli-tv-bi-vb-pc59
pli-tv-bi-vb-pc60:1.10@bhedāpetī”ti → bhedāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc60
pli-tv-bi-vb-pc60:1.16.1@rudhitaṁ → ruhitaṁ (bj, sya-all); rūhitaṁ (pts1ed) @pli-tv-bi-vb-pc60
pli-tv-bi-vb-pc60:2.1.30@Dhovite → dhote (sya-all, pts1ed) @pli-tv-bi-vb-pc60
pli-tv-bi-vb-pc60:2.1.32@Litte → ālitte (sya-all) @pli-tv-bi-vb-pc60
pli-tv-bi-vb-pc60:2.2.3@yā kāci viññū dutiyikā → yā kāci viññū dutiyā (sya-all); yo koci viññū dutiyo (pts1ed, mr) @pli-tv-bi-vb-pc60
pli-tv-bi-vb-pc61:1.5@garubhārā → garugabbhā (sya-all) @pli-tv-bi-vb-pc61
pli-tv-bi-vb-pc62:2.6@dhāti → dhātī (bj, sya-all, pts1ed); hoti → hotu (mr) @pli-tv-bi-vb-pc62
pli-tv-bi-vb-pc65:1.11@Ūnadvādasavassā → ūnadvādasavassā hi (bj, sya-all); ūnadvādasavassāhi (mr) @pli-tv-bi-vb-pc65
pli-tv-bi-vb-pc65:1.13@Dvādasavassāva → dvādasavassā ca (sya-all, pts1ed, mr) @pli-tv-bi-vb-pc65
pli-tv-bi-vb-pc70:1.7@vūpakāsāpeti → … si (bj, pts1ed, mr) @pli-tv-bi-vb-pc70
pli-tv-bi-vb-pc71:1.17.1@kumāribhūtaṁ → kumārībhtaṁ (bj, sya-all) @pli-tv-bi-vb-pc71
pli-tv-bi-vb-pc76:1.13@āpajjatī”ti → āpajjīti (pts1ed, mr) @pli-tv-bi-vb-pc76
pli-tv-bi-vb-pc76:1.20.1@alaṁ tāva → alantāva (sya-all) @pli-tv-bi-vb-pc76
pli-tv-bi-vb-pc77:1.17.1@evāhaṁ taṁ → evāhantaṁ (bj, sya-all) @pli-tv-bi-vb-pc77
pli-tv-bi-vb-pc79:1.2@sokāvāsaṁ → sokavassaṁ (bj); sokāvassaṁ (sya-all) @pli-tv-bi-vb-pc79
pli-tv-bi-vb-pc79:1.4@sokāvāsaṁ → sokavassaṁ (bj); sokāvassaṁ (sya-all) @pli-tv-bi-vb-pc79
pli-tv-bi-vb-pc79:1.5@vuṭṭhāpetī”ti → vuṭṭhāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc79
pli-tv-bi-vb-pc79:1.11.1@sokāvāsaṁ → sokavassaṁ (bj); sokāvassaṁ (sya-all) @pli-tv-bi-vb-pc79
pli-tv-bi-vb-pc81:1.7@vuṭṭhāpetī”ti → vuṭṭhāpesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc81
pli-tv-bi-vb-pc81:1.13.1@pārivāsikachandadānena → pārivāsikacchandadānena (sya1ed, sya2ed) @pli-tv-bi-vb-pc81
pli-tv-bi-vb-pc82:1.3@Manussā → manussā vihāracārikaṁ āhiṇḍantā passitvā (bj) @pli-tv-bi-vb-pc82
pli-tv-bi-vb-pc83:1.4@Manussā → manussā vihāracārikaṁ āhiṇḍantā passitvā (bj) @pli-tv-bi-vb-pc83
pli-tv-bi-vb-pc86:1.13@dhāretī”ti → dhāresīti (bj, pts1ed, mr) @pli-tv-bi-vb-pc86
pli-tv-bi-vb-pc90:2.1.8@ummaddāpeti → ubbaṭṭāpeti (bj) @pli-tv-bi-vb-pc90
pli-tv-bi-vb-pc93:2.2.2@gilānāya → ābādhappaccayā (sya-all, mr); ābādhapaccayā (pts1ed) @pli-tv-bi-vb-pc91-93
pli-tv-bi-vb-pc96:1.2@asaṅkaccikā → asaṅkacchikā (sya-all, pts1ed) @pli-tv-bi-vb-pc96
pli-tv-bi-vb-pc96:1.16.1@asaṅkaccikā → asaṅkacchikā (sya-all, pts1ed) @pli-tv-bi-vb-pc96
pli-tv-bi-vb-pc96:2.2.13.0@Nandasikkhāpada → pli-tv-bu-vb-pc1 [Pācittiyā 1: Musāvādasikkhāpada] (1:50) @pli-tv-bi-vb-pc96
pli-tv-bi-vb-pc96:2.2.24@(…) → bj potthake tassuddānañca vagguddānañca @pli-tv-bi-vb-pc96
pli-tv-bi-vb-pj5:0.1@Theravāda Vinaya → pli-tv-bu-vb-pj1:45 [Pārājika 1: Paṭhamapārājikasikkhāpada/ Santhatabhāṇavāra] paṭhamapārājikasikkhāpada (1:1) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:0.2@Bhikkhunivibhaṅga → pli-tv-bu-vb-pj2:20 [Pārājika 2: Dutiyapārājikasikkhāpada] dutiyapārājikasikkhāpada (2:2) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:0.3@Pārājikakaṇḍa → pli-tv-bu-vb-pj3:22 [Pārājika 3: Tatiyapārājikasikkhāpada] tatiyapārājikasikkhāpada (3:3) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:1.11@kuṭhāriṁ → kuddālaṁ (bj); kudhāriṁ (mr); parasuṁ → pharasuṁ (bj, sya-all, pts1ed, mr) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:1.25@atthāya → yaṁpāhaṁ (sya-all, pts1ed) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:1.43@sādiyatī”ti → sādiyīti (bj, pts1ed, mr) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:1.50@santuṭṭhassa → santuṭṭhiyā (pts1ed, mr); asantuṭṭhitāya → asantuṭṭhiyā (bj, pts1ed, mr); asantuṭṭhatāya (sya-all) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj5:2.3.10@Paṭhamapārājikaṁ samattaṁ → paṭhamapārājikaṁ niṭṭhitaṁ (bj, sya-all); bhikkhunīvibhaṅge paṭhamapārājikaṁ niṭṭhitaṁ (pts1ed) @pli-tv-bi-vb-pj5
pli-tv-bi-vb-pj6:1.15@Bhikkhū → ye te bhikkhū …pe… (?) @pli-tv-bi-vb-pj6
pli-tv-bi-vb-pj6:1.17@paṭicodeti → paṭicodesi … ārocesīti (bj, pts1ed, mr); na gaṇassa ārocetī”ti → paṭicodesi … ārocesīti (bj, pts1ed, mr) @pli-tv-bi-vb-pj6
pli-tv-bi-vb-pj6:1.23.1@nevattanā → neva attanā (sya-all); avassaṭā → avasaṭā (bj, sya-all, pts1ed); ti → vajjapaṭicchādikāti (bj, sya-all, pts1ed); aññāsiṁ → saññāsiṁ (sya1ed, sya2ed); pubbevāhaṁ → pubbe vāhaṁ (sya-all) @pli-tv-bi-vb-pj6
pli-tv-bi-vb-pj7:1.11.1@appaṭikāraṁ → appatikāraṁ (bj); apaṭikāraṁ (pts1ed) @pli-tv-bi-vb-pj7
pli-tv-bi-vb-pj7:1.12@appaṭikāro → appatikāro (bj); apaṭikāro (pts1ed) @pli-tv-bi-vb-pj7
pli-tv-bi-vb-pj7:2.1.8@adassane vā appaṭikamme vā appaṭinissagge vā → adassane vā appaṭikamme vā diṭṭhiyā appaṭinissagge vā (bj); adassanena vā appaṭikammena vā appaṭinissaggena vā (pts1ed, mr); adassane vā appaṭikamme vā pāpikāya diṭṭhiyā appaṭinissagge vā (?) @pli-tv-bi-vb-pj7
pli-tv-bi-vb-pj8:1.11.1@saṅghāṭikaṇṇaggahaṇaṁ → … kaṇṇagahaṇaṁ (bj, sya-all, pts1ed); hatthaggahaṇaṁ → hatthagahaṇaṁ (bj, sya-all, pts1ed); paṭisevanatthāya → patisevanatthāya (bj) @pli-tv-bi-vb-pj8
pli-tv-bi-vb-pj8:2.1.21@okāsaṁ → idaṁ padaṁ aṭṭhakathāyaṁ na @pli-tv-bi-vb-pj8
pli-tv-bi-vb-sk1:0.5@Parimaṇḍalasikkhāpada → Dutiyaukkhittakasikkhāpada (ms) @pli-tv-bi-vb-sk1
pli-tv-bi-vb-sk75:0.5@Udakeuccārasikkhāpada → pli-tv-bu-vb-sk50:1 [Sekhiyā 50: Capucapukārakasikkhāpada] (50:195) @pli-tv-bi-vb-sk75
pli-tv-bi-vb-sk75:1.9@Bhikkhū → ye te bhikkhū …pe… (?) @pli-tv-bi-vb-sk75
pli-tv-bi-vb-ss1:1.2@udositaṁ → uddositaṁ (bj, sya-all, pts1ed) @pli-tv-bi-vb-ss1
pli-tv-bi-vb-ss1:1.22@pāpuṇāti → pāpuṇi (bj, sya-all) @pli-tv-bi-vb-ss1
pli-tv-bi-vb-ss1:1.31@api nāyyā → api nāyyo (si, mr); apinvayyā (sya-all); api nayyo (pts1ed) @pli-tv-bi-vb-ss1
pli-tv-bi-vb-ss1:1.56.1@kammakārena → kammakarena (bj, sya-all); ussayavādikā → usuyyavādikā (sya-all) @pli-tv-bi-vb-ss1
pli-tv-bi-vb-ss2:1.34@pabbājetī”ti → pabbājesīti (bj, cck, pts1ed, mr) @pli-tv-bi-vb-ss2
pli-tv-bi-vb-ss2:1.40.1@vajjhaṁ viditaṁ → vajjhaviditaṁ (sya-all) @pli-tv-bi-vb-ss2
pli-tv-bi-vb-ss3:1.2@gāmakaṁ → gāmake (sya-all) @pli-tv-bi-vb-ss3
pli-tv-bi-vb-ss3:3.1@gacchantā → gantvā (pts1ed, mr) @pli-tv-bi-vb-ss3
pli-tv-bi-vb-ss3:3.13@vippavasatī”ti → vippavasīti (bj, mr, csp1ed); vippavasati (pts1ed) @pli-tv-bi-vb-ss3
pli-tv-bi-vb-ss3:4.2@ohīyitvā → ohiyitvā (csp1ed) @pli-tv-bi-vb-ss3
pli-tv-bi-vb-ss3:4.8@ohīyatī”ti → ohiyīti (bj, csp1ed) @pli-tv-bi-vb-ss3
pli-tv-bi-vb-ss4:1.6@adassane → adassanena (pts1ed, mr) @pli-tv-bi-vb-ss4
pli-tv-bi-vb-ss4:1.21@chandaṁ osāretī”ti → osāresīti (bj, pts1ed, mr) @pli-tv-bi-vb-ss4
pli-tv-bi-vb-ss4:2.1.8@adassane vā appaṭikamme vā appaṭinissagge vā → adassanena vā appaṭikammena vā appaṭinissaggena vā (pts1ed, mr); adassane vā appaṭikamme vā pāpikāya diṭṭhiyā appaṭinissagge vā (?) @pli-tv-bi-vb-ss4
pli-tv-bi-vb-ss6:1.26.1@te → kinte (sya-all, pts1ed) | yaṁ te → yante (sya-all, pts1ed) | Iṅgha, ayye → iṅghayye (bj, sya-all) @pli-tv-bi-vb-ss6
pli-tv-bi-vb-ss10:0.2@Bhikkhunivibhaṅga → pli-tv-bu-vb-ss5:23 [Saṅghādisesā 5: Sañcarittasikkhāpada] (5:9) @pli-tv-bi-vb-ss10
pli-tv-bi-vb-ss10:0.3@Saṅghādisesakaṇḍa → pli-tv-bu-vb-ss8:18 [Saṅghādisesā 8: Duṭṭhadosasikkhāpada] (8:12) @pli-tv-bi-vb-ss10
pli-tv-bi-vb-ss10:1.6@caṇḍakāḷī → caṇḍakāḷī bhikkhunī (si, mr); caṇḍakālī bhikkhunī (pts1ed) @pli-tv-bi-vb-ss10
pli-tv-bi-vb-ss10:1.22@abhiramāyye → abhiramayye (bj, sya-all, pts1ed) @pli-tv-bi-vb-ss10
pli-tv-bi-vb-ss10:1.24@samanubhāsīyamānā → samanubhāsiyamānā (bj, sya-all, pts1ed) @pli-tv-bi-vb-ss10
pli-tv-bi-vb-ss11:1.15.1@paccākatā → pacchā katā (sya-all) @pli-tv-bi-vb-ss11
pli-tv-bi-vb-ss12:1.11.1@vajjappaṭicchādikā → vajjapaṭicchādikā (bj, sya-all, pts1ed); bhikkhunisaṅghassa → bhikkhunīsaṇghassa (bj, sya-all, pts1ed) @pli-tv-bi-vb-ss12
pli-tv-bi-vb-ss12:1.14@Viviccathāyye → viviccaṭhayye (bj); viviccathayye (sya-all, pts1ed) @pli-tv-bi-vb-ss12
pli-tv-bi-vb-ss13:1.5@Tumhaññeva → tuyhaññeva (si); tumheyeva (sya-all); vebhassiyā → vebhassā (bj, sya-all) @pli-tv-bi-vb-ss13
pli-tv-bi-vb-ss13:1.24@ayye → māyye (bj, sya-all, pts1ed) @pli-tv-bi-vb-ss13
pli-tv-bi-vb-ss13:1.26@Tumhaññeva → tumheyeva (sya-all); vebhassiyā → vebhassā (bj, sya-all) @pli-tv-bi-vb-ss13
pli-tv-bi-vb-ss13:2.15@vibhassīkatā → vibhassikatāya (bj); vibhassikatā (pts1ed) @pli-tv-bi-vb-ss13
pli-tv-bi-vb-ss13:3.13.0@Kuladūsakasikkhāpada → pli-tv-bu-vb-ss10:7 [Saṅghādisesā 10: Saṅghabhedasikkhāpada] (10:14) @pli-tv-bi-vb-ss13
pli-tv-bi-vb-ss13:3.17@sā bhikkhunī → etthantare pāṭho katthaci natthi @pli-tv-bi-vb-ss13
pli-tv-kd1:1.1.2@vimuttisukhapaṭisaṁvedī → vimuttisukhaṁ paṭisaṁvedī (mr) @pli-tv-kd1
pli-tv-kd1:1.7.5@Sūriyova → suriyova (bj, sya-all, km, pts1ed) @pli-tv-kd1
pli-tv-kd1:2.2.5@brāhmaṇakaraṇā → brāhmaṇakārakā (mr); brāhmaṇakarāṇā (?) @pli-tv-kd1
pli-tv-kd1:3.1.1@ti → … siriṁsapa … (bj, sya-all, km, pts1ed) @pli-tv-kd1
pli-tv-kd1:4.2.1@tapussa → tapassu (bj); tapassū (si) @pli-tv-kd1
pli-tv-kd1:4.5.1@onītapattapāṇiṁ viditvā bhagavato pādesu sirasā nipatitvā bhagavantaṁ → si , sya-all potthakesu natthi @pli-tv-kd1
pli-tv-kd1:5.3.9@āvuṭā → āvaṭā (bj) @pli-tv-kd1
pli-tv-kd1:5.4.3@namati → namissati (?) @pli-tv-kd1
pli-tv-kd1:5.7.4@Apāpuretaṁ → avāpuretaṁ (bj) @pli-tv-kd1
pli-tv-kd1:5.7.13@aṇaṇa → anaṇa (bj, cck, sya2ed, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:5.7.14@Desassu → desetu (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:5.8.1@Evaṁ vutte, bhagavā brahmānaṁ … Aññātāro bhavissantī”ti → etthantare pāṭho si, sya-all potthakesu natthi, mūlapaṇṇāsakepi pāsarāsisutte brahmayācanā sakiṁ yeva āgatā @pli-tv-kd1
pli-tv-kd1:5.11.1@paralokavajjabhayadassāvine → … dassāvino (bj, sya-all, km) @pli-tv-kd1
pli-tv-kd1:5.11.2@ṭhitāni → tiṭṭhanti (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:6.3.5@udako → uddako (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:6.8.17@Āhañchaṁ → āhaññiṁ (sya-all, mr); āhañhi (pts1ed) @pli-tv-kd1
pli-tv-kd1:6.9.5@tasmāhamupaka → tasmāhaṁ upakā (bj) @pli-tv-kd1
pli-tv-kd1:6.9.6@hupeyyapāvusoti → huveyyapāvuso (bj); huveyyāvuso (sya-all); hupeyya āvuso (pts1ed) @pli-tv-kd1
pli-tv-kd1:6.10.3@katikaṁ → idaṁ padaṁ bj potthake @pli-tv-kd1
pli-tv-kd1:6.11.1@tathā tathā → tathā tathā te (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:6.11.5@Apissu → api ca kho (mn26:55 [Pāsarāsisutta] pāsarāsisutte) @pli-tv-kd1
pli-tv-kd1:6.12.2@samudācaratha → samudācarittha (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:6.12.4@Yathānusiṭṭhaṁ tathā paṭipajjamānā → yathānusiṭṭhaṁ paṭipajjamānā (sya-all) @pli-tv-kd1
pli-tv-kd1:6.13.2@uttari manussadhammā → uttarimanussadhammaṁ (sya-all, pts1ed, mr); iriyāya → cariyāya (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:6.16.2@pabhāvitametan”ti → bhāsitametanti (bj, sya-all, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:6.17.3@dve → idaṁ padadvayaṁ bj, sya-all potthakesu @pli-tv-kd1
pli-tv-kd1:6.19.3@pañcupādānakkhandhā → pañcupādānakkhandhāpi (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:6.20.1@dukkhasamudayaṁ → ettha (?) @pli-tv-kd1
pli-tv-kd1:6.20.2@nandīrāgasahagatā → nandirāgasahagatā (bj, sya-all, pts1ed); ponobbhavikā → ponobhavikā (bj, mr) @pli-tv-kd1
pli-tv-kd1:6.21.1@dukkhanirodhaṁ → ettha (?) @pli-tv-kd1
pli-tv-kd1:6.27.1@abhisambuddhoti → abhisambuddho (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:6.29.3@abhinandunti → abhinandanti (pts1ed) @pli-tv-kd1
pli-tv-kd1:6.31.1@layena → tena layenāti padadvayaṁ bj, sya-all potthakesu @pli-tv-kd1
pli-tv-kd1:6.40.7@nayidaṁ → nayime (bj, mr) @pli-tv-kd1
pli-tv-kd1:6.44.1@yaṁ dūre → yaṁ dūre vā (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:6.47.2@abhinandunti → abhinanduṁ (bj, sya-all); abhinandanti (pts1ed) @pli-tv-kd1
pli-tv-kd1:7.1.4@vassike pāsāde cattāro māse → vassike pāsāde vassike cattāro māse (bj) @pli-tv-kd1
pli-tv-kd1:7.2.1@paṭikacceva → paṭigacceva (bj, pts1ed) @pli-tv-kd1
pli-tv-kd1:7.7.4@anugamāsi → anugamā (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:7.10.10@nikkujjitaṁ → nikujjitaṁ (mr) @pli-tv-kd1
pli-tv-kd1:7.12.2@paridevasokasamāpannā → paridevi sokasamāpannā (cck, sya2ed, mr) @pli-tv-kd1
pli-tv-kd1:9.2.1@Te → te cattāro janā (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:9.2.6@Ime → ime cattāro (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:11.2.6@Muttāhaṁ → muttohaṁ (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:12.3.3@ohārāpetvā → ohāretvā (bj, mr) @pli-tv-kd1
pli-tv-kd1:12.4.11@upasampadākathā → pabbajjāupasampadākathā (bj) @pli-tv-kd1
pli-tv-kd1:13.1.1@vassaṁvuṭṭho → vassaṁ vuttho (bj, cck, sya2ed, pts1ed) @pli-tv-kd1
pli-tv-kd1:13.2.4@Mahābandhanabaddhosi → mārabandhanabaddhosi (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:13.2.8@Mahābandhanamuttomhi → mārabandhanamuttomhi (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:15.3.2@padhūpāyi → padhūpāsi (sya-all, pts1ed); pakhūpāsi (mr); disvāna dummano → dukkhī dummano (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:15.5.2@pariyādinno → pariyādiṇṇo (mr) @pli-tv-kd1
pli-tv-kd1:15.6.4@aggisālamhī”ti → aggisaraṇamhīti (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:15.6.13@Abhīto → asambhīto (bj, pts1ed) @pli-tv-kd1
pli-tv-kd1:15.6.16@adhimano → na vimano (sya-all); avimano (pts1ed) @pli-tv-kd1
pli-tv-kd1:15.7.1@tassā rattiyā → atha rattiyā (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:15.7.2@Hatā nāgassa acciyo honti → ahināgassa acciyo na honti (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:15.7.3@Iddhimato pana ṭhitā → iddhimato panuṭṭhitā (bj) @pli-tv-kd1
pli-tv-kd1:15.7.14@vihara, ahaṁ te → te upaṭṭhāmi (itipi) @pli-tv-kd1
pli-tv-kd1:19.2.7@paṭivīso → paṭiviṁso (bj); paṭiviso (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:20.1.3@kho ahaṁ → ahaṁ paṁsukūlaṁ (cck, sya2ed, mr) @pli-tv-kd1
pli-tv-kd1:20.9.4@tvaṁyeva taṁ → tvaṁ yevetaṁ (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:20.11.2@gandhasampannaṁ → gandhasampannanti (sya-all); sugandhikaṁ (mr) @pli-tv-kd1
pli-tv-kd1:20.11.3@Sace ākaṅkhasi … tvaṁyeva taṁ gaṇhā”ti → etthantare pāṭho si, sya-all potthakesu natthi @pli-tv-kd1
pli-tv-kd1:20.13.1@ujjaletuṁ → jāletuṁ (bj); ujjalituṁ (mr) @pli-tv-kd1
pli-tv-kd1:20.16.2@udakena na otthaṭo → udakena otthaṭo (bj, sya-all); udakena anuotthaṭo (pts1ed) @pli-tv-kd1
pli-tv-kd1:20.16.10@Ayamahamasmi → āma ahamasmi (sya-all) @pli-tv-kd1
pli-tv-kd1:20.16.13@na pavāhissati → nappasahissati (bj); nappavāhissati (sya-all); na pavahissati (pts1ed) @pli-tv-kd1
pli-tv-kd1:21.4.10@Ādittapariyāyasuttaṁ → ādittapariyāyaṁ (bj) @pli-tv-kd1
pli-tv-kd1:22.1.1@bhagavā → bhagavāti (cck, sya2ed, mr) @pli-tv-kd1
pli-tv-kd1:22.1.3@laṭṭhivane → laṭṭhivanuyyāne (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:22.2.3@bhagavantaṁ → bhavantaṁ (cck, mr) @pli-tv-kd1
pli-tv-kd1:22.3.1@dvādasanahutehi → dvādasaniyutehi (yojanā) @pli-tv-kd1
pli-tv-kd1:22.4.1@dvādasanahutānaṁ → dvādasaniyutānaṁ (yojanā) @pli-tv-kd1
pli-tv-kd1:22.9.4@maṁ → maṁ bhante (bj, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:22.13.20@dasasataparivāro → … parivārako (mr) @pli-tv-kd1
pli-tv-kd1:22.16.3@appākiṇṇaṁ → appakiṇṇaṁ (bj, sya-all); abbhokiṇṇaṁ (mr) @pli-tv-kd1
pli-tv-kd1:23.1.1@sañcayo → sañjayo (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:23.5.9@Paccabyattha → paccabyathā (bj, sya-all); paccavyathā (pts1ed); paccabyatha (tha-ap3:151 [Sāriputtattheraapadāna]) @pli-tv-kd1
pli-tv-kd1:24.1.3@apalokema → apalokāma (si, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:24.3.3@bhagavā → bhagavā te (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:24.5.3@sañcayāni → sañjeyyāni (bj); sañjayāni (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:24.5.8@sañcaye netvāna → sañjeyyake netvā (bj); sañjaye netvāna (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:24.6.12@nayamānānaṁ → nīyamānānaṁ (cck, sya2ed, mr) @pli-tv-kd1
pli-tv-kd1:24.6.13@usūyā → usuyyā (sya-all, pts1ed); ussuyā (mr) @pli-tv-kd1
pli-tv-kd1:25.1.1@anācariyakā → idaṁ padaṁ bj, sya-all, pts1ed potthakesu @pli-tv-kd1
pli-tv-kd1:25.1.2@manussānaṁ → te manussānaṁ (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:25.6.1@asantuṭṭhitāya → asantuṭṭhiyā (bj, pts1ed); asantuṭṭhatāya (si, sya-all); vīriyārambhassa → viriyārambhassa (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:25.7.6@vācāya → na vācāya (mr) @pli-tv-kd1
pli-tv-kd1:25.9.1@sodako → saudako (bj, cck, sya2ed, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:25.14.6@Bhisibibbohanaṁ → bhisibimbohanaṁ (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:25.22.1@niyassaṁ → nissayaṁ (pts1ed); niyasaṁ (mr) @pli-tv-kd1
pli-tv-kd1:25.23.7@rajitabbaṁ → rajetabbaṁ (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:25.23.9@rajantena → rajentena (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:25.24.4@chedetabbā → chettabbā (bj); chedātabbā (pts1ed); cheditabbā (mr) @pli-tv-kd1
pli-tv-kd1:25.24.6@veyyāvacco → veyyāvaccaṁ (katthaci) @pli-tv-kd1
pli-tv-kd1:28.4.1@upasampādetuṁ → upasampadaṁ (bj, sya-all) @pli-tv-kd1
pli-tv-kd1:30.1.1@aṭṭhitā → adhiṭṭhitā (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:31.1.4@abhirameyyāmahaṁ → abhirameyyañcāhaṁ (bj); abhirameyyaṁ svāhaṁ (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:31.3.2@upasampādesi → upasampādeti (csp1ed, csp2ed) @pli-tv-kd1
pli-tv-kd1:36.2.2@Na asekkhena → na asekhena (bj, cck, sya2ed, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:36.10.2@dhammato vinodetuṁ → vinodetuṁ vā vinodāpetuṁ vā (sabbattha, Vimativinodanīṭīkā oloketabbā); anabhirataṁ → anabhiratiṁ (bj, sya-all); uppannaṁ anabhiratiṁ (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:38.1.1@Tena kho pana samayena yo so aññatitthiyapubbo → yo so pasuraparibbājako aññatitthiyapubbo (mr) @pli-tv-kd1
pli-tv-kd1:39.5.5@Somhi → sohaṁ (bahūsu, vimativinodanīṭīkā oloketabbā) @pli-tv-kd1
pli-tv-kd1:39.6.2@bhadantā → bhaddantā (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:40.3.9@anussāvakassa → anusāsakassa (bj); anusāvakassa (mr) @pli-tv-kd1
pli-tv-kd1:47.1.2@Ayyakā → ayirakā (bj); ayirā (si); ayyikā (cck, sya2ed, pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:53.2.2@avāpuraṇaṁ → apāpuraṇaṁ (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:54.1.7@Gacchassu → gacchassa (si, sya-all) @pli-tv-kd1
pli-tv-kd1:56.1.5@veramaṇī → veramaṇiṁ (mr) @pli-tv-kd1
pli-tv-kd1:58.1.3@kathaṁ → kahaṁ (mr) @pli-tv-kd1
pli-tv-kd1:66.2.2@sacā ca → sacajja (bj, sya-all); sacajja (aṭṭhakathāyaṁ pāṭhantarā); gayheyyāma → gaṇhīyeyyāma (bj); gaṇheyyāma (si, mr) @pli-tv-kd1
pli-tv-kd1:74.1.3@anussāvessatū”ti → anusāvessatūti (bj); anussāvessatīti (sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:76.1.3@terasa → tassa (pts1ed, mr) @pli-tv-kd1
pli-tv-kd1:76.5.6@sammannitabbo → sammanitabbo (mr) @pli-tv-kd1
pli-tv-kd1:76.5.7@attanā vā → attanāva (bj, sya-all, pts1ed) @pli-tv-kd1
pli-tv-kd1:77.1.1@saṅgīti ācikkhitabbā, cattāro nissayā ācikkhitabbā → cattāri akaraṇīyāni ācikkhitabbāni. (mr) @pli-tv-kd1
pli-tv-kd1:79.2.6@passasi taṁ → passāhi taṁ (bj); passasetaṁ (si) @pli-tv-kd1
pli-tv-kd1:79.4.42@saṅgāhaṇāhetuṁ → saṅgāhanāhetu (bj, sya-all); saṅgahaṇahetu (pts1ed); saṅgāhanāhetuṁ (mr) @pli-tv-kd1
pli-tv-kd1:79.4.83@rājā → bhaṭo coro (sya-all); eko coro (pts1ed) @pli-tv-kd1
pli-tv-kd1:79.4.119@lakkhaṇā → pekkhanā (sabbattha) @pli-tv-kd1
pli-tv-kd2:3.3.12@evamevaṁ → evameva (pts1ed, mr) @pli-tv-kd2
pli-tv-kd2:3.4.6@vibhajissāmi uttāniṁ karissāmi → uttānī karissāmi (bj, sya-all); uttanikarissāmi (pts1ed) @pli-tv-kd2
pli-tv-kd2:3.4.12@sabbacetasā → sabbaṁ cetasā (sya-all, pts1ed, mr) @pli-tv-kd2
pli-tv-kd2:5.5.5@na garukarissatha → na garuṁ karissatha (mr) @pli-tv-kd2
pli-tv-kd2:6.1.12@ekuposathaṁ → ekūposathaṁ (bj, pts1ed, mr) @pli-tv-kd2
pli-tv-kd2:6.2.4@sammuti → sammati (sya-all) @pli-tv-kd2
pli-tv-kd2:7.2.1@nadīpārasīmaṁ → nadīpāraṁ sīmaṁ (bj, pts1ed) @pli-tv-kd2
pli-tv-kd2:8.3.7@samūhanitvā → samuhanitvā (mr) @pli-tv-kd2
pli-tv-kd2:8.4.4@samūhaneyya → samuhaneyya (mr) @pli-tv-kd2
pli-tv-kd2:9.2.1@uposathappamukhaṁ → uposathapamukhaṁ (bj, pts1ed); uposathamukhaṁ (sya-all) @pli-tv-kd2
pli-tv-kd2:12.1.1@ahosi, cīvarānissa → tena cīvarānissa (mr) @pli-tv-kd2
pli-tv-kd2:12.2.8@avippavāsā → avippavāso (sya-all); avippavāsāya → avippavāsassa (sya-all) @pli-tv-kd2
pli-tv-kd2:12.4.8@avippavāsā → avippavāso (sya-all); avippavāsāya → avippavāsassa (sya-all) @pli-tv-kd2
pli-tv-kd2:12.5.1@samānasaṁvāsasīmā → samānasaṁvāsā sīmā (sya-all) @pli-tv-kd2
pli-tv-kd2:12.6.1@pana, bhikkhave, sīmā → samānasaṁvāsā sīmā (sya-all) @pli-tv-kd2
pli-tv-kd2:15.3.1@savarabhayaṁ → saṁcarabhayaṁ (cck); sañcarabhayaṁ (sya1ed, sya2ed) @pli-tv-kd2
pli-tv-kd2:15.6.7@attanā vā → attanā va (sya-all, pts1ed) @pli-tv-kd2
pli-tv-kd2:15.9.1@vissajjenti → vissajjanti (mr) @pli-tv-kd2
pli-tv-kd2:15.9.7@Attanā vā → attanā va (sya-all, pts1ed) @pli-tv-kd2
pli-tv-kd2:16.3.5@okāsaṁ kātun”ti → kārāpetunti (bj, sya-all, pts1ed) @pli-tv-kd2
pli-tv-kd2:16.9.5@therādhikaṁ → therādheyyaṁ (aṭṭhakathāyaṁ pāṭhantaraṁ) @pli-tv-kd2
pli-tv-kd2:16.9.6@paṭhamo → ekādasamaṁ (cck, sya2ed); ekādasamo (mr) @pli-tv-kd2
pli-tv-kd2:18.4.4@nāmaggena → nāmamattena (sya-all); gaṇamaggena vā (pts1ed); gaṇamaggena (mr) @pli-tv-kd2
pli-tv-kd2:21.1.1@āpucchiṁsu → na āpucchiṁsu (bj, cck, sya2ed, mr) @pli-tv-kd2
pli-tv-kd2:21.1.3@āpucchanti → na āpucchanti (bj, cck, sya2ed, mr) @pli-tv-kd2
pli-tv-kd2:21.1.4@Te → tehi (pts1ed, mr) @pli-tv-kd2
pli-tv-kd2:36.4.16@Sammanne → sammane (mr) @pli-tv-kd2
pli-tv-kd2:36.4.38@Sajjukaṁ vassuposatho → sajjucassuposatho (si); sajjuvassuposathe (si); sajjuvassaruposatho (mr) @pli-tv-kd2
pli-tv-kd3:1.1.3@Tedha → te idha (csp1ed) @pli-tv-kd3
pli-tv-kd3:1.2.3@saṅkasāyissanti → saṅkāsayissanti (bj, sya-all); saṅkāpayissanti (pts1ed) @pli-tv-kd3
pli-tv-kd3:9.2.6@hanantipi → ojampi haranti (bj, pts1ed); harantipi (sya-all) @pli-tv-kd3
pli-tv-kd3:13.1.11@abhirameyyāmahaṁ → abhirameyyañcāhaṁ (bj); abhirameyyāmāhaṁ (pts1ed) @pli-tv-kd3
pli-tv-kd3:14.1.5@bahuṁ cīvaraṁ → bahucīvaraṁ (si, pts1ed, mr) @pli-tv-kd3
pli-tv-kd3:14.5.2@pāṭipade → pāṭipadena (pts1ed, mr) @pli-tv-kd3
pli-tv-kd3:14.11.69@bhedaaṭṭhavidhena → bhedā aṭṭhavidhena (sya-all, pts1ed) @pli-tv-kd3
pli-tv-kd3:14.11.82@Dvīhatīhā ca puna ca → dvīhatīhaṁ vasitvāna (bj); dvīhatīhā ca puna (sya-all) @pli-tv-kd3
pli-tv-kd4:1.12.2@vuṭṭhā → vutthā (bj, cck, sya2ed, pts1ed, mr); kirame → kirime (mr); aphāsuññeva → aphāsukaññeva (bj); phāsumhā → phāsukamha (bj); phāsumha (sya-all, pts1ed) @pli-tv-kd4
pli-tv-kd4:2.2.1@yāva sabbe pavārentīti → yāva sabbe pavārenti (sya-all) @pli-tv-kd4
pli-tv-kd4:3.2.2@pavāraṇakammānī”ti → pavāraṇākammānīti (sya-all) @pli-tv-kd4
pli-tv-kd4:3.5.1@Pavāraṇahārako → pavāraṇāhārako (bj, sya-all, pts1ed) @pli-tv-kd4
pli-tv-kd4:6.1.7@ārocesuṁ → ārocesi (mr) @pli-tv-kd4
pli-tv-kd4:10.2.15@avasesehi → avasesehi tesaṁ santike (mr) @pli-tv-kd4
pli-tv-kd4:15.5.1@anovassikaṁ → anovassakaṁ (si, mr) @pli-tv-kd4
pli-tv-kd4:17.3.2@tesaṁ vikkhitvā → te saṁvikkhitvā (bj); tesaṁ vikkhipāpetvā (paṭivisodhakānaṁ mati); tesaṁ ācikkhitvā (mr) @pli-tv-kd4
pli-tv-kd4:17.4.3@āyasmanto → āyasmantā (bj, pts1ed, mr) @pli-tv-kd4
pli-tv-kd4:17.9.5@arogaṁ ākaṅkhamāno codessasī’ti → yāva arogo hoti. arogaṁ ākaṅkhamāno codessasīti (mr) @pli-tv-kd4
pli-tv-kd4:17.10.1@samanugāhitvā → samanubhāsitvā (bj); samanuggāhitvā (sya-all, pts1ed) @pli-tv-kd4
pli-tv-kd4:18.6.11@paṇāmañca → pavārentāsane dve ca (bj, sya-all); dve ca (pts1ed) @pli-tv-kd4
pli-tv-kd4:18.6.22@chandadāne pavāraṇā → chandadānapavāraṇā (pts1ed, mr) @pli-tv-kd4
pli-tv-kd5:1.7.5@dhūmāyatipi → dhūpāyatipi (bj, pts1ed); padhūpāyatipi (sya-all) @pli-tv-kd5
pli-tv-kd5:1.21.3@karaṇīyamattānaṁ → karaṇīyamattano (bj); karaṇīyaṁ attano (an6.55:1 [55. Soṇasutta]) @pli-tv-kd5
pli-tv-kd5:1.30.7@guṇaṅguṇūpāhanā → gaṇaṅgaṇūpāhanā (bj, pts1ed); guṇaṅgaṇupāhanā (sya-all) @pli-tv-kd5
pli-tv-kd5:2.1.4@sabbamañjiṭṭhikā → sabbamañjeṭṭhikā (bj, sya-all, pts1ed, mr); sabbamañjaṭṭhikāyo (si) @pli-tv-kd5
pli-tv-kd5:2.2.1@nīlakavaddhikā → … vaṭṭikā (bj, pts1ed) @pli-tv-kd5
pli-tv-kd5:2.3.1@khallakabaddhā → … vaddhā (sya-all) | … bandhā (mr); morapiñchaparisibbitā → morapiñjaparisibbitā (bj, sya-all), moraparipiccha (pts1ed) @pli-tv-kd5
pli-tv-kd5:2.4.1@luvakacammaparikkhaṭā → ulūkacammaparikkhaṭā (bj, sya-all, pts1ed yojanā) @pli-tv-kd5
pli-tv-kd5:3.2.2@phalitā”ti → phālitāti (si, sya-all, pts1ed, mr) @pli-tv-kd5
pli-tv-kd5:4.3.1@agāravā appatissā asabhāgavuttikā → sagāravā sappatissā sabhāgavuttikā (sya-all); sagāravā saggatissā sabhāgavuttikā (pts1ed, mr) @pli-tv-kd5
pli-tv-kd5:5.2.5@pādakhilo vā ābādho → pādakhīlābādho vā (sya-all); pādakhīlā vā ābādho (pts1ed) @pli-tv-kd5
pli-tv-kd5:6.3.2@janapadakathaṁ, itthikathaṁ → itthīkathaṁ purisakathaṁ (sya-all); itthikathaṁ purisakathaṁ (mr) @pli-tv-kd5
pli-tv-kd5:10.4.2@uddhalomiṁ → uddalomiṁ (bj, mr); undalomiṁ (mr) @pli-tv-kd5
pli-tv-kd5:10.9.4@kena → kenaci (mr) @pli-tv-kd5
pli-tv-kd5:11.1.5@ogumphiyanti → ogumbhiyanti (mr) @pli-tv-kd5
pli-tv-kd5:13.1.1@mahākaccāno → mahākaccāyano (bj); papatake → papāte (bj, sya-all, pts1ed); pavatte (ud5.6:1 [Soṇasutta]); kuraraghare → kururaghare (mr) @pli-tv-kd5
pli-tv-kd5:13.2.1@(…) → (evaṁ vutte āyasmā mahākaccāyano soṇaṁ upāsakaṁ kuṭikaṇṇaṁ etadavoca) (sya-all; ud5.6:1 [Soṇasutta]) @pli-tv-kd5
pli-tv-kd5:13.6.6@majjārū jantū → majjhāru jantu (bj, pts1ed); majjāru jantu (sya-all); majjhārū jantū (mr) @pli-tv-kd5
pli-tv-kd5:13.9.9@anelagalāya → aneḷagalāya (bj, pts1ed, mr) @pli-tv-kd5
pli-tv-kd5:13.12.2@gajaṅgalaṁ → kajaṅgalaṁ (bj, sya-all, pts1ed); kajaṅgalo (si) @pli-tv-kd5
pli-tv-kd5:13.12.3@sallavatī → salalavatī (bj) @pli-tv-kd5
pli-tv-kd6:1.3.1@yaṁ → yaṁ kho (bj) @pli-tv-kd6
pli-tv-kd6:1.4.2@senesitāni → senesikāni (bj, sya-all, pts1ed); senehikāni (yojanā) @pli-tv-kd6
pli-tv-kd6:1.4.3@bhattācchādakena → bhattacchādakena (bj); bhattācchandakena (pts1ed); bhattācchannakena (mr) @pli-tv-kd6
pli-tv-kd6:2.1.5@nippakkaṁ → nipakkaṁ (bj, sya-all, pts1ed, mr) @pli-tv-kd6
pli-tv-kd6:3.1.4@vacattaṁ → vacatthaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:3.2.3@nisadapotakan”ti → nisadapotanti (si, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:4.1.3@kasāvāni bhesajjāni → kasāvabhesajjāni (mr) @pli-tv-kd6
pli-tv-kd6:5.1.4@kappāsapaṇṇaṁ → kappāsipaṇṇaṁ (bj, sya-all); kappāsikapaṇṇaṁ (pts1ed) @pli-tv-kd6
pli-tv-kd6:6.1.4@goṭṭhaphalaṁ → goṭhaphalaṁ (sya-all, pts1ed); koṭṭhaphalaṁ (mr) @pli-tv-kd6
pli-tv-kd6:7.1.4@hiṅguṁ, hiṅgujatuṁ → hiṅgu hiṅgujatu (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:8.1.4@ubbhidaṁ → ubbhiraṁ (mr); bilaṁ → biḷālaṁ (bj) @pli-tv-kd6
pli-tv-kd6:9.1.1@belaṭṭhasīsassa → belaṭṭhisisassa (bj); velaṭṭhasīsassa (sya-all) @pli-tv-kd6
pli-tv-kd6:10.2.3@āmakamaṁsaṁ → āmakamaṁsañca (bj) @pli-tv-kd6
pli-tv-kd6:11.2.5@kapallan”ti → kapallakanti (bj) @pli-tv-kd6
pli-tv-kd6:12.1.1@carukesupi → thālakesupi (bj, sya-all); thālikesu pi (pts1ed) @pli-tv-kd6
pli-tv-kd6:12.1.10@añjanī → añjaniyo (bj) @pli-tv-kd6
pli-tv-kd6:12.2.4@nipatati → patati (bj) @pli-tv-kd6
pli-tv-kd6:12.2.5@Bhagavato etamatthaṁ ārocesuṁ → As per si. Not found in sya-all, pts-vp-pli1 editions @pli-tv-kd6
pli-tv-kd6:12.2.7@phalati → nipatati (pts1ed, mr) @pli-tv-kd6
pli-tv-kd6:12.2.8@Bhagavato etamatthaṁ ārocesuṁ → As per si. Not found in sya-all, pts-vp-pli1 editions @pli-tv-kd6
pli-tv-kd6:12.3.5@rūpiyamayaṁ → rūpimayaṁ (bj) @pli-tv-kd6
pli-tv-kd6:12.4.3@salākaṭhāniyan”ti → salākodhāniyanti (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:13.2.1@Natthuṁ visamaṁ āsiñcanti → natthuṁ visamaṁ āsiñcīyanti (bj); natthu Visamaṁ āsiñciyati (sya-all) @pli-tv-kd6
pli-tv-kd6:13.2.3@yamakanatthukaraṇin”ti → yamakaṁ natthukaraṇinti (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:13.2.7@kaṇṭho → kaṇṭhaṁ (pts1ed) @pli-tv-kd6
pli-tv-kd6:14.1.9@atipakkhittamajjāni → atikhittamajjāni (mr) @pli-tv-kd6
pli-tv-kd6:14.1.13@majjassa na vaṇṇo na gandho na raso → na ca vaṇno na ca gandho na ca raso (bj) @pli-tv-kd6
pli-tv-kd6:14.4.6@gāhetun”ti → gahetunti (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:14.4.7@phalitā → phālitā (si, sya-all, pts1ed, mr) @pli-tv-kd6
pli-tv-kd6:14.5.4@Vaṇabandhanacoḷena → vaṇabandhanacolakena (bj); vaṇabandhanacolena (sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:14.5.9@sāsapakuṭṭena → sāsapakuṇḍhena (bj); sāsapakuḍḍena (si, sya-all); sāsapakuṭṭhena (si, pts1ed) @pli-tv-kd6
pli-tv-kd6:14.6.15@kato, na puna → kato pana (?) @pli-tv-kd6
pli-tv-kd6:15.2.5@bhante, mayā → bhante (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:15.3.9@ito → ito ratti (si, sya-all) @pli-tv-kd6
pli-tv-kd6:15.4.1@gaṇetvā → vigaṇetvā (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:15.4.6@Ārāmikagāmako”tipi → ārāmikagāmotipi (bj, pts1ed); pilindagāmako”tipi → pilindigāmotipi (bj); pilindavacchagāmakotipi (sya-all); pilindagāmotipi (pts1ed) @pli-tv-kd6
pli-tv-kd6:15.5.2@alaṅkatā → ālaṅkitā (bj) @pli-tv-kd6
pli-tv-kd6:15.8.9@ayyasseveso → ayyassa eso (bj, pts1ed); ayyassa seveso (sya2ed) @pli-tv-kd6
pli-tv-kd6:15.9.2@uttari manussadhammaṁ → uttarimanussadhammā (bj) @pli-tv-kd6
pli-tv-kd6:15.9.4@sappiṁ, navanītaṁ, telaṁ, madhuṁ → sappi navanītaṁ telaṁ madhu (mr) @pli-tv-kd6
pli-tv-kd6:15.9.7@bāhullikā → bāhulikā (bj) @pli-tv-kd6
pli-tv-kd6:15.9.8@kolambepi → madhu (bj); koḷumbepi (mr) @pli-tv-kd6
pli-tv-kd6:15.10.4@vigarahitvā bhagavato → te bhikkhū bhagavato (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:16.1.7@Kimatthāya → kimatthiyā (pts1ed, mr) @pli-tv-kd6
pli-tv-kd6:16.1.8@Thaddhatthāya → bandhanatthāya (bj, sya-all); thaddhanatthāya (pts1ed) @pli-tv-kd6
pli-tv-kd6:16.2.7@Sace → sacepi (?) @pli-tv-kd6
pli-tv-kd6:17.1.3@tekaṭulayāguyā → tekaṭulāya yāguyā (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:17.2.6@kutāyaṁ → kuto yaṁ (bj) @pli-tv-kd6
pli-tv-kd6:17.3.4@vuṭṭhaṁ → vutthaṁ (bj, sya-all, pts1ed, mr) @pli-tv-kd6
pli-tv-kd6:17.7.9@avissaṭṭhā → avissatthā (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:17.9.7@kappiyakārake → … kārakaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:17.9.8@uggahitaṁ paṭiggahitun”ti → uggahitapaṭiggahitanti (bj); uggahitaṁ paṭiggahetunti (sya-all) @pli-tv-kd6
pli-tv-kd6:18.1.4@paṭisammodi → sammodi (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:18.3.2@pamuṭṭhā → pammuṭṭhā (bj) @pli-tv-kd6
pli-tv-kd6:18.3.3@harāpeyyan”ti → āharāpeyyanti (bj) @pli-tv-kd6
pli-tv-kd6:18.4.6@Paṭiggaṇhatha → na patigaṇhanti patigaṇhatha (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:20.1.8@samiñjitaṁ → sammiñjitaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:20.2.8@bhisañca muḷālikañca abbāhitvā → bhisamūḷālikañca abbāhetvā (bj); bhisamūlālikāyo abbāhitvā (sya-all); bhisañ ca muḷāliñ ca abbāhitvā (pts1ed); bhisamuḷālaṁ abbuhetvā (sn20.9:1 [9. Nāgasutta]) @pli-tv-kd6
pli-tv-kd6:20.3.5@ca bhuttassa → paribhuttassa (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:21.1.4@nibbattabījaṁ → nibbaṭṭabījaṁ (bj); nibbaṭabījaṁ (sya-all); nippaṭṭabījaṁ (mr) @pli-tv-kd6
pli-tv-kd6:22.1.5@maṁ → mamaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:22.2.6@atthi kira → atthi (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:23.1.4@ubhatopasannā → ubho pasannā (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:23.3.5@dajjāhi → dajjehi (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:23.3.6@veṭhetvā → paveṭhetvā (bj) @pli-tv-kd6
pli-tv-kd6:23.4.3@Esāyya → esayya (bj) @pli-tv-kd6
pli-tv-kd6:23.4.6@Gilānāmhī”ti → gilānamhīti (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:23.4.12@Kimpimāya → kimpanimāya (bj); kiṁ panimāya (sya-all); kim pana imāya (pts1ed) @pli-tv-kd6
pli-tv-kd6:23.8.7@Paribhuñjāmahaṁ → pariñjāhaṁ (bj); paribhuñjāhaṁ (sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:23.13.4@santi → santi hi (bj) @pli-tv-kd6
pli-tv-kd6:23.13.5@Supassopi → suphassopi (bj) @pli-tv-kd6
pli-tv-kd6:23.14.1@sīhamaṁsaṁ → maṁsaṁ (mr) @pli-tv-kd6
pli-tv-kd6:23.14.3@sīhamaṁsagandhena → maṁsagandhena (bj) @pli-tv-kd6
pli-tv-kd6:24.1.2@anubandhā → anubaddhā (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:24.2.2@atītāni → adhikāni (bj, sya-all); ekattako → ekako (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:24.6.3@khuddaṁ → khudaṁ (bj, sya-all, pts1ed); vineti → paṭivineti (bj); paṭivinodeti (sya-all); vinodeti (pts1ed); paṭihanati → paṭihanti (bj) @pli-tv-kd6
pli-tv-kd6:24.6.4@yāguyāti → pacchimā pañca ānisaṁsā an5.207:1 [207. Yāgusutta] @pli-tv-kd6
pli-tv-kd6:24.6.10@Khuddaṁ pipāsañca → khudaṁ pipāsaṁ (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:24.6.11@bhattaṁ → bhuttaṁ (bj) @pli-tv-kd6
pli-tv-kd6:25.1.1@bhagavatā kira → kira bhikkhūnaṁ (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:25.1.3@paribhuñjanti → bhuñjanti (bj, sya-all, pts1ed); bhojjayāguyā → bhojjāya yāguyā (bj) @pli-tv-kd6
pli-tv-kd6:25.3.4@paṭiggaṇhatha → patigaṇhittha (bj); paṭigaṇhatha (pts1ed) @pli-tv-kd6
pli-tv-kd6:25.3.6@upanāmessāmīti → upanāmessāmi (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:26.2.6@ābhato → āhaṭo (bj, sya-all, pts1ed, mr) @pli-tv-kd6
pli-tv-kd6:26.6.4@yassa so → yasseso (bj) @pli-tv-kd6
pli-tv-kd6:26.6.6@opilāpeti → opilāpesi (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:26.7.1@padhūpāyati → sandhūpāyati (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:26.7.2@divasaṁsantatto → divasasantatto (bj) @pli-tv-kd6
pli-tv-kd6:28.3.2@sabbasantharisanthataṁ → sabbasanthariṁ santhataṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:28.11.4@brahmacārayo → brahmacārino (si, sya-all); brahmacariye (pts1ed) @pli-tv-kd6
pli-tv-kd6:28.13.1@evameva kho → evameva bhagavā (bj, sya-all); evameva (pts1ed) @pli-tv-kd6
pli-tv-kd6:28.13.5@jano bandhati → pabandhati (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:29.2.1@dukkhanirodhaṁ → dukkhanirodho (sya-all); dukkhasamudayaṁ → dukkhasamudayo (sya-all) @pli-tv-kd6
pli-tv-kd6:30.1.3@yojāpetvā bhadraṁ bhadraṁ yānaṁ → yojāpetvā bhadraṁ yānaṁ (bj, sya2ed, pts1ed) @pli-tv-kd6
pli-tv-kd6:30.3.3@niyyāsuṁ → nīsiṁsu (bj); niyyiṁsu (sya-all) @pli-tv-kd6
pli-tv-kd6:30.3.4@lohitavaṇṇā lohitavatthā lohitālaṅkārā → lohitakavaṇṇā lohitakavatthā lohitakālaṅkārā (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:30.3.5@paṭivaṭṭesi → paṭivattesi (bj, sya-all, mr) @pli-tv-kd6
pli-tv-kd6:30.4.2@ambapāli, daharānaṁ daharānaṁ → amhākaṁ daharānaṁ daharānaṁ (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:30.4.7@jitamha → parājitamha (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:30.6.1@nātikā → nādikā (si, sya-all); ñātikā (pts1ed); viharitvā → dn16:102 [Mahāparinibbānasutta/11. Ambapālīgaṇikā] mahāparinibbānasutte anusandhi aññathā @pli-tv-kd6
pli-tv-kd6:31.1.1@sandhāgāre → santhāgāre (bj, sya-all, pts1ed; an8.12:1 [12. Sīhasutta]) @pli-tv-kd6
pli-tv-kd6:31.2.1@nāṭaputto → nātaputto (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:31.8.11@anabhāvaṅkatā → anabhāvakatā (bj) @pli-tv-kd6
pli-tv-kd6:31.9.8@assāsāya → assāsāya ca (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:31.10.4@Anuviccakāraṁ → anuvijjakāraṁ (pts1ed, mr); kho → sīho (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:31.10.5@bhagavato → bhagavato vacanena (bj, sya-all); bhiyyoso mattāya → bhīyosomattāya (bj) @pli-tv-kd6
pli-tv-kd6:31.13.1@rathikāya rathikaṁ → rathiyā rathiyaṁ (bj); rathiyāya rathiyaṁ (sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:31.13.2@thūlaṁ → thullaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:31.13.7@jiridanti → jīranti (bj, pts1ed); kīranti (sya-all) @pli-tv-kd6
pli-tv-kd6:33.2.2@sammannitabbā → sammannitabbo (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:33.3.1@sammuti → sammatikā (sya-all); sammutī (pts1ed); sammutiyā → sammatikāya (sya-all) @pli-tv-kd6
pli-tv-kd6:34.1.3@bahidvāre → padvāre (bj) @pli-tv-kd6
pli-tv-kd6:34.1.5@khiyyati → khīyati (bj, sya-all); sūpabhiñjanakaṁ → sūpabhiñjarakaṁ (bj); sūpagiñjarakaṁ (sya-all); sūpavyañjanakaṁ (pts1ed) @pli-tv-kd6
pli-tv-kd6:34.1.7@chamāsikaṁ → chammāsikaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:34.2.2@bhattaṁ → bījabhattaṁ (bj) @pli-tv-kd6
pli-tv-kd6:34.6.12@passissāmā”ti → passāmāti (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:34.10.1@bhagavā → bhagavāti (si, mr) @pli-tv-kd6
pli-tv-kd6:34.12.1@bhagavantaṁ → idaṁ padaṁ si, sya-all potthakesu @pli-tv-kd6
pli-tv-kd6:34.13.2@yathayime → yathāpime (bj); yathāyime (pts1ed) @pli-tv-kd6
pli-tv-kd6:34.17.5@taruṇena → dhāruṇhena (bj, sya-all); yattha → yattha mayaṁ (bj) @pli-tv-kd6
pli-tv-kd6:34.21.8@sādituṁ → sādiyituṁ (bj) @pli-tv-kd6
pli-tv-kd6:34.21.9@sāditabbaṁ → sādisitabbaṁ (bj) @pli-tv-kd6
pli-tv-kd6:35.1.3@anuppatto → anuppatto āpaṇe viharati (bj, pts1ed) @pli-tv-kd6
pli-tv-kd6:35.2.3@yamataggi → yamadaggi (mr) @pli-tv-kd6
pli-tv-kd6:35.5.3@kiñcāpi kho, bho → kiñcāpi bho (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:35.5.6@adhivāsetu bhavaṁ → me bhavaṁ (bj, sya-all) @pli-tv-kd6
pli-tv-kd6:35.6.3@madhūkapānaṁ → madhupānaṁ (bj, sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:35.8.8@Puññaṁ ākaṅkhamānānaṁ → puññamākaṅkhamānānaṁ (bj) @pli-tv-kd6
pli-tv-kd6:36.1.3@saṅgaraṁ → saṅgavaṁ (pts1ed); saṅkaraṁ (mr) @pli-tv-kd6
pli-tv-kd6:36.3.4@Mahatthiko → mahiddhiyo (bj, pts1ed); mahitthiko (si); mahiddhiko (sya-all) @pli-tv-kd6
pli-tv-kd6:37.2.4@nāḷiyāvāpakena anugharakaṁ anugharakaṁ āhiṇḍatha → nāḷiyāvāpakena anugharakaṁ āhiṇḍatha (bj); yāgupānaṁ → yāgudānaṁ (bj) @pli-tv-kd6
pli-tv-kd6:37.4.3@pabbajito → pabbajite (bj) @pli-tv-kd6
pli-tv-kd6:37.5.3@samādapessasi → samādapesi (mr) @pli-tv-kd6
pli-tv-kd6:37.5.6@pabbajitena akappiye samādapetabbaṁ → pabbajitā akappiye samādapetabbā (bj) @pli-tv-kd6
pli-tv-kd6:40.3.14@upapisanī → upapiṁsanī (bj); upapiṁsanaṁ (sya-all); upapisanaṁ (pts1ed); añjanaṁ → añjanī (bj) @pli-tv-kd6
pli-tv-kd6:40.3.16@salākaṭhāniṁ → salākodhanī (bj, sya-all); salākodhani (pts1ed) @pli-tv-kd6
pli-tv-kd6:40.3.17@Thavikaṁsabaddhakaṁ → savaṭṭakaṁ (bj); vaddhakaṁ (sya-all); bandhakaṁ (pts1ed) @pli-tv-kd6
pli-tv-kd6:40.3.19@dhūmañca → dhūma (bj) @pli-tv-kd6
pli-tv-kd6:40.3.20@Nettañcāpidhanatthavi → nettañca pidhānaṁ yamakatthaci (bj); nettañ cāpidhānaṁ thavi (pts1ed) @pli-tv-kd6
pli-tv-kd6:40.3.48@ahi sīhañca dīpikaṁ → sīhabyagghaṁ ca dīpikaṁ (bj); ahi sīha-byaggha-dīpakaṁ (sya-all, pts1ed) @pli-tv-kd6
pli-tv-kd6:40.3.61@Phārusakā → phārusakaṁ (bj); phārusaka (sya-all) @pli-tv-kd6
pli-tv-kd7:1.1.2@pāveyyakā → pāṭheyyakā (bj, sya-all, pts1ed); āraññikā → āraññakā (bj, sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:1.3.2@kathinaṁ → kaṭhinaṁ (bj, sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:1.5.2@Kathañca pana, bhikkhave → kathañca bhikkhave (bj, sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:1.5.5@na cīvaravicāraṇamattena → na gaṇṭusakaraṇamattena (mr) @pli-tv-kd7
pli-tv-kd7:1.5.8@na ovaṭṭiyakaraṇamattena → na ovaṭṭikaraṇamattena (bj); na ovaṭṭikakaraṇamattena (sya-all, pts1ed); na ovadeyyakaraṇamattena (mr) @pli-tv-kd7
pli-tv-kd7:1.5.9@na kaṇḍusakaraṇamattena → na kaṇḍasakaraṇamattena (sya-all); na gaṇḍusakaraṇamattena (mr) @pli-tv-kd7
pli-tv-kd7:1.5.13@na ovaddheyyakaraṇamattena → na ovaṭṭeyyakaraṇamattena (bj, sya-all); na ovadeyyakaraṇamattena (mr) @pli-tv-kd7
pli-tv-kd7:1.5.26@ce → ceva (bj, sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:1.7.3@sahubbhārā”ti → saubbhārāti (mr) @pli-tv-kd7
pli-tv-kd7:3.2.13@Samādāyasattakaṁ niṭṭhitaṁ → ādāyasattakaṁ niṭṭhitaṁ (pts1ed); … dutiyaṁ niṭṭhitaṁ (mr) @pli-tv-kd7
pli-tv-kd7:8.3.22@Anāsādoḷasakaṁ → anāsā dvādasakaṁ (bj) @pli-tv-kd7
pli-tv-kd7:11.1.1@apavilāyamāno → apavinayamāno (bj); apacinayamāno (si, pts1ed, mr) @pli-tv-kd7
pli-tv-kd7:11.1.2@kahaṁ → kahaṁ tvaṁ (bj) @pli-tv-kd7
pli-tv-kd7:11.1.7@amukaṁ nāma → amukañca (mr) @pli-tv-kd7
pli-tv-kd7:11.3.18@Apavilāyananavakaṁ → apavinayanavakaṁ (bj); apacinanavakaṁ (pts1ed) @pli-tv-kd7
pli-tv-kd7:13.2.4@anapekkho → anapekho (bj); anapekkhena (sya-all, pts1ed, mr) @pli-tv-kd7
pli-tv-kd7:13.2.18@Anāmantā asamācārā → anāmantāsamādānaṁ (bj) @pli-tv-kd7
pli-tv-kd7:13.2.27@daḷhīkammānuvātikā → … vātakā (bj); daḷhikammānuvātikā (sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:13.2.28@ovaddheyyaṁ → ovaṭṭeyyaṁ (bj, sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:13.2.29@nimittaṁ kathā → nimittakathā (bj, sya-all, pts1ed) @pli-tv-kd7
pli-tv-kd7:13.2.42@kappakate → kappakato (bj) @pli-tv-kd7
pli-tv-kd7:13.2.93@vippakate → vippakatā (bj, pts1ed, mr); chakke → chaṭṭhe (si); chaccā (pts1ed, mr) @pli-tv-kd7
pli-tv-kd7:13.2.109@savanasīmātikkamā → savaṇaṁ sīmātikkamo (bj); savanaṁ sīmatikkamā (sya-all) @pli-tv-kd7
pli-tv-kd7:13.2.115@pannarasavidhi → paṇṇarasā vidhi (bj); paṇṇarasā vidhī (sya-all) @pli-tv-kd7
pli-tv-kd7:13.2.120@Apavilānā navettha → apavinā nava cettha (bj); apavilāyamāneva (sya-all); apacinanā navettha (pts1ed) @pli-tv-kd7
pli-tv-kd8:1.1.2@phitā → phītā (sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.1.7@ambapālī ca → ambapālikā (pts1ed); padakkhiṇā → padakkhā (sya-all) @pli-tv-kd8
pli-tv-kd8:1.2.1@rājagahako → rājagahiko (bj) @pli-tv-kd8
pli-tv-kd8:1.2.7@padakkhiṇaṁ → padakkhaṁ (sya-all); upasobhantiṁ → upasobhitaṁ (bj); upasobhitanti (pts1ed) @pli-tv-kd8
pli-tv-kd8:1.2.13@vuṭṭhāpessāmā”ti → vuṭṭhāpeyyāmāti (bj, sya-all, pts1ed, mr) @pli-tv-kd8
pli-tv-kd8:1.3.1@kumārī → kumārikā (bj) @pli-tv-kd8
pli-tv-kd8:1.3.6@amanāpā → amanāpā hoti (bj) @pli-tv-kd8
pli-tv-kd8:1.3.8@sakkāro bhañjissati → parihāyissati (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.4.5@abhayo nāma rājakumāro → abhayo rājakumāro (bj) @pli-tv-kd8
pli-tv-kd8:1.5.6@mayāsi → mayāpi (sya-all, pts1ed, mr) @pli-tv-kd8
pli-tv-kd8:1.5.10@takkasilāyaṁ → takkasīlāyaṁ (mr) @pli-tv-kd8
pli-tv-kd8:1.6.5@na sammussati → na pamussati (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.7.7@yojanaṁ, na kiñci → āhiṇṭanto na kiñci (mr) @pli-tv-kd8
pli-tv-kd8:1.7.8@Susikkhitosi → sikkhitosi (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.11.2@pasatena → pasatena me (bj, sya-all) @pli-tv-kd8
pli-tv-kd8:1.11.4@nipātetvā → nipajjāpetvā (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.12.2@acchariyaṁ → acchariyaṁ vata bho (sya-all) @pli-tv-kd8
pli-tv-kd8:1.12.3@Bahukāni ca me mahagghāni → mahagghāni mahagghāni (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.12.4@kiñci → kañci (sya-all) @pli-tv-kd8
pli-tv-kd8:1.12.11@āgārikā → agārikā (bj, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.13.4@arogā ṭhitā”ti → arogāpitāti (bj) @pli-tv-kd8
pli-tv-kd8:1.14.4@na ciraṁ → nacirasseva (sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.14.7@maṁ disvā → deviyo disvā (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.15.4@passāmā”ti → passāmīti (sya-all) @pli-tv-kd8
pli-tv-kd8:1.15.9@bhikkhusaṅghan”ti → saṅghanti (bj); bhikkhusaṅghañcāti (sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.16.10@bahūpakāro → bahukāro (bj) @pli-tv-kd8
pli-tv-kd8:1.17.12@sace tvaṁ, gahapati, arogo bhaveyyāsi → sacāhaṁ taṁ gahapati arogāpeyyaṁ (bj, pts1ed); sacāhantaṁ gahapati arogaṁ kareyyaṁ (sya-all) @pli-tv-kd8
pli-tv-kd8:1.18.7@mañcake → mañcakena (bj); uppāṭetvā → phāletvā (bj); upphāletvā (pts1ed); nipātetvā → nipajjāpetvā (bj, sya-all, pts1ed); sibbiniṁ → sibbaniṁ (bj); mahājanassa → janassa (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.18.8@passathayye → passesyātha (bj); passatha (sya-all); passathayyo (pts1ed, mr) @pli-tv-kd8
pli-tv-kd8:1.18.21@sibbitvā → sibbetvā (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.19.8@ācariya, sakkomi → nāhaṁ sakkomi (bj, sya-all) @pli-tv-kd8
pli-tv-kd8:1.20.4@Jānāsi → jānābhi (bj); jānāhi (sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.22.3@ubbandhitvā → upanibandhitvā (bj, sya-all); tirokaraṇiyaṁ → tirokaraṇiṁ (bj, sya-all) @pli-tv-kd8
pli-tv-kd8:1.22.9@arogo ṭhito”ti → arogāpitoti (bj) @pli-tv-kd8
pli-tv-kd8:1.23.1@samayena rañño → ujjeniyaṁ rañño (sya-all) @pli-tv-kd8
pli-tv-kd8:1.24.1@dehi → idaṁ padadvayaṁ bj, sya-all potthakesu @pli-tv-kd8
pli-tv-kd8:1.25.7@sappiṁ → taṁ sappiṁ (sya-all) @pli-tv-kd8
pli-tv-kd8:1.26.6@amanussena paṭicca jāto → amanussena jāto (bj) @pli-tv-kd8
pli-tv-kd8:1.27.4@bhuñjāma → bhuñjāmi (bj, sya-all) @pli-tv-kd8
pli-tv-kd8:1.28.9@hatthinikaṁ kākassa niyyādetvā yena → yena rājagahaṁ yena (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:1.29.3@ayyo → deva (sya-all) @pli-tv-kd8
pli-tv-kd8:1.29.5@bahūnaṁ → bahunnaṁ (bj, sya-all) @pli-tv-kd8
pli-tv-kd8:1.33.17@alaṁ yūsapiṇḍapātenā”ti → alaṁ tāva yūsapiṇḍapātenāti (bj); alaṁ yūsapiṇḍakenāti (sya-all) @pli-tv-kd8
pli-tv-kd8:1.35.5@Itarītarenapāhaṁ → pahaṁ (bj); cāhaṁ (sya-all) @pli-tv-kd8
pli-tv-kd8:9.4.2@dātabbo, āgatapaṭipāṭiyā → āgatāgatapaṭipāṭiyā (mr) @pli-tv-kd8
pli-tv-kd8:10.2.1@sītudakāya → sītundikāya (bj); sītūdakāya (sya-all); sītunnakāya (pts1ed) @pli-tv-kd8
pli-tv-kd8:10.2.7@uttarāḷumpaṁ → uttarāḷuvaṁ (sya-all); uttarāḷupaṁ (yojanā) @pli-tv-kd8
pli-tv-kd8:10.3.1@āviñchanti → āviñjanti (bj); āvaṭṭanti (sya-all); āvajjanti (pts1ed) @pli-tv-kd8
pli-tv-kd8:10.3.4@rajanuḷuṅkaṁ → rajanauluṅkaṁ (pts1ed); rajanāḷuṅkaṁ (yojanā) @pli-tv-kd8
pli-tv-kd8:11.2.9@seyyathāpi nāma → seyyathāpi (?) @pli-tv-kd8
pli-tv-kd8:12.1.2@acchibaddhaṁ → accibaddhaṁ (bj, sya-all); accibandhaṁ (pts1ed); acchibandhaṁ (mr) @pli-tv-kd8
pli-tv-kd8:12.1.9@passatu me → passatha tumhe (mr) @pli-tv-kd8
pli-tv-kd8:13.1.2@ubbhaṇḍite → ubbhaṇḍīkate (sya-all) @pli-tv-kd8
pli-tv-kd8:14.2.2@acchupentaṁ → acchupantaṁ (mr) @pli-tv-kd8
pli-tv-kd8:15.4.1@gattāni sītiṁ karitvā → sītīkaritvā (cck, pts1ed); sītikaritvā (sya1ed) @pli-tv-kd8
pli-tv-kd8:15.5.2@sandahatha → sannahatha (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:15.5.5@samiñjitaṁ → sammiñjitaṁ (sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:15.6.2@pavattamānesu, na hi nāma ekabhikkhussapi → vattamānesu na hi nāma ekabhikkhussāpi (sya-all); pavattamānesu na ekabhikkhussapi (?) @pli-tv-kd8
pli-tv-kd8:15.11.3@tumhākaṁ, ayye, daharānaṁ → daharānaṁ daharānaṁ (bj) @pli-tv-kd8
pli-tv-kd8:15.14.9@Dibbaṁ sā labhate āyuṁ → dibbaṁ balaṁ sā labhate ca āyuṁ (bj, sya-all) @pli-tv-kd8
pli-tv-kd8:18.1.1@mukhapuñchanacoḷaṁ → mukhapuñchanacolaṁ (sya-all); mukhapuñchanacolakaṁ (pts1ed); mukhapuñjanacoḷaṁ (mr) @pli-tv-kd8
pli-tv-kd8:18.1.8@mukhapuñchanacoḷakan”ti → mukhapuñchanacolanti (sya-all); mukhapuñchanacolakanti (pts1ed) @pli-tv-kd8
pli-tv-kd8:22.1.4@Mātāpitaroti → mātāpitūnaṁ kho (bj); mātāpitaro hi (pts1ed); dadamāne → vadamāno (mr); vadamāne (?) @pli-tv-kd8
pli-tv-kd8:23.1.6@Idhāhaṁ → so ahaṁ (katthaci) @pli-tv-kd8
pli-tv-kd8:28.1.3@dhutatāya → dhūtattāya (sya-all); dhutattāya (pts1ed, mr) @pli-tv-kd8
pli-tv-kd8:29.1.4@sabbamañjiṭṭhakāni → sabbamañjeṭṭhakāni (bj, sya-all, pts1ed) @pli-tv-kd8
pli-tv-kd8:29.1.11@phaṇadasāni → phaladasāni (mr) @pli-tv-kd8
pli-tv-kd8:32.1.58@sītudakā → sītundī ca (bj); situṇhaṁ ca (cck); sītuṇhaṁ ca (sya1ed, sya2ed); sītuṇhi ca (pts1ed) @pli-tv-kd8
pli-tv-kd8:32.1.87@gilānakā → gilāyanā (sya-all, pts1ed, mr) @pli-tv-kd8
pli-tv-kd9:1.2.11@āvāsikaṁ → imaṁ āvāsikaṁ (sya-all); āvāsiko (pts1ed) @pli-tv-kd9
pli-tv-kd9:1.3.9@camhi → vamhi (?) @pli-tv-kd9
pli-tv-kd9:1.9.3@āyatiṁ → āyatiṁ ca (bj) @pli-tv-kd9
pli-tv-kd9:2.3.1@Adhammena → adhammena ce bhikkhave (sya-all) @pli-tv-kd9
pli-tv-kd9:4.7.28@tassa ca → tassa (sya-all) @pli-tv-kd9
pli-tv-kd9:4.8.2@ānantarikassāpi → anantarikassāpi (sya-all) @pli-tv-kd9
pli-tv-kd9:4.8.3@Imassa → imassa kho (sya-all, pts1ed) @pli-tv-kd9
pli-tv-kd9:7.20.16@Imepi → ime (bj, sya-all) @pli-tv-kd9
pli-tv-kd9:7.20.103@icchitabbake → icchitabbako (mr) @pli-tv-kd9
pli-tv-kd9:7.20.134@Parovīsativaggo ca → atirekavīsativaggo (sya-all) @pli-tv-kd9
pli-tv-kd9:7.20.177@byañjanā → ito paraṁ sya-all potthakesu diyaḍḍhagāthāhi abhabbapuggalā samattaṁ @pli-tv-kd9
pli-tv-kd9:7.20.232@tammūlakaṁ tassa → dve dve mūlā katā tassa (sya-all); dodotamūlakantassa (mr) @pli-tv-kd9
pli-tv-kd9:7.20.260@Upari nayakammānaṁ → upavinayakammānaṁ (sya-all); ukkhepaniyakammānaṁ (pts1ed); ukkhepanīyakammānaṁ (mr) @pli-tv-kd9
pli-tv-kd9:7.20.263@yācite → yācito (bj); yācati (sya-all) @pli-tv-kd9
pli-tv-kd10:1.1.3@āpattidiṭṭhi → āpattidiṭṭhī (bj) @pli-tv-kd10
pli-tv-kd10:1.8.3@āpatti → sā āpatti (sya-all) @pli-tv-kd10
pli-tv-kd10:1.8.5@āyasmanto → āyasmantā (pts1ed, mr) @pli-tv-kd10
pli-tv-kd10:1.8.7@āpatti → sā āpatti (sya-all) @pli-tv-kd10
pli-tv-kd10:1.9.5@bhikkhū → bhikkhu (bj, sya-all) @pli-tv-kd10
pli-tv-kd10:1.10.1@ete → te (sya-all) @pli-tv-kd10
pli-tv-kd10:2.1.12@vattamānāya → (?); adhammiyāyamāne → adhammiyamāne (bj, sya-all, pts1ed); adhammīyamāne (mr) @pli-tv-kd10
pli-tv-kd10:2.3.2@bārāṇasiyaṁ → vajirabuddhiṭīkā @pli-tv-kd10
pli-tv-kd10:2.4.2@vammikaṁ → vammitaṁ (bj) @pli-tv-kd10
pli-tv-kd10:2.5.8@Attamanā → avimanā (bj, sya-all, pts1ed) @pli-tv-kd10
pli-tv-kd10:2.13.1@khappaṁ → bappaṁ (bj); vappaṁ (sya-all, pts1ed) @pli-tv-kd10
pli-tv-kd10:2.17.12@addūbhāya → adūhāya (sya-all); adubbhāya (pts1ed, mr) @pli-tv-kd10
pli-tv-kd10:4.1.1@bālakaloṇakagāmo → bālakaloṇakāragāmo (bj, pts1ed; mn128:14 [Upakkilesasutta]); bālakaloṇakārakagāmo (sya-all) @pli-tv-kd10
pli-tv-kd10:4.2.1@kimilo → kimbilo (bj, sya-all, pts1ed) @pli-tv-kd10
pli-tv-kd10:4.6.1@pālileyyakaṁ → pārileyyakaṁ (bj, sya-all, pts1ed) @pli-tv-kd10
pli-tv-kd10:4.6.5@kosambakehi → kosambhikehi (sya-all) @pli-tv-kd10
pli-tv-kd10:4.6.7@ogāhā cassa otiṇṇassa → ogāhā cassa uttiṇṇassa (bj); ogāhañca me otiṇṇassa (sya-all) @pli-tv-kd10
pli-tv-kd10:4.7.6@Etaṁ → evaṁ (pts1ed, mr) @pli-tv-kd10
pli-tv-kd10:5.7.1@mahāpajāpati → mahāpajāpatī (bj, sya-all, pts1ed) @pli-tv-kd10
pli-tv-kd10:5.10.5@senāsane → senāsanaṁ (sya-all); senāsanesu (mr) @pli-tv-kd10
pli-tv-kd10:5.13.2@passi → passī (itipi) @pli-tv-kd10
pli-tv-kd10:6.3.25@Viyākaraṁ → so byākaraṁ (bj); veyyākaraṁ (sya-all); vyākaraṇa (pts1ed) @pli-tv-kd10
pli-tv-kd10:6.3.35@vattanā → vatthunā (bj, sya-all, pts1ed) @pli-tv-kd10
pli-tv-kd11:1.1.6@alamattatarā ca → alamatthatarā ca (sya-all, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:1.3.1@asantuṭṭhitāya → asantuṭṭhiyā (bj, pts1ed); asantuṭṭhatāya (sya-all); vīriyārambhassa → viriyārambhassa (bj, sya-all, pts1ed); vīriyārabbhassa (mr); Atha kho bhagavā te → paṇḍukalohitake (sya-all) @pli-tv-kd11
pli-tv-kd11:1.4.2@āpattiṁ → āpatti (bj, sya-all) @pli-tv-kd11
pli-tv-kd11:2.1.1@adhammakammañca → adhammakammañceva (sya-all) @pli-tv-kd11
pli-tv-kd11:5.1.6@bhikkhunovādakasammuti → … sammati (bj, sya-all) @pli-tv-kd11
pli-tv-kd11:5.1.20@na bhikkhūhi → na bhikkhū bhikkhūhi (sya-all) @pli-tv-kd11
pli-tv-kd11:6.2.9@okāsaṁ kāreti, codeti, sāreti, bhikkhūhi sampayojeti → bhikkhū bhikkhūhi sampayojeti (sya-all) @pli-tv-kd11
pli-tv-kd11:9.1.3@pakatā → pakatattā (sya-all) @pli-tv-kd11
pli-tv-kd11:9.1.22@niyassakammaṁ → nissayakammaṁ (pts1ed); niyasakammaṁ (mr) @pli-tv-kd11
pli-tv-kd11:9.2.2@āpattiṁ āropetabbo → āpatti āropetabbā (bj, sya-all); āpattiṁ ropetabbo (pts1ed) @pli-tv-kd11
pli-tv-kd11:13.1.1@nāma → nāma bhikkhū (mr) @pli-tv-kd11
pli-tv-kd11:13.1.3@vidhūtikaṁ → vidhutikaṁ (sya-all, pts1ed) @pli-tv-kd11
pli-tv-kd11:13.2.3@purato → purato dhāvanti (sya-all, pts1ed) @pli-tv-kd11
pli-tv-kd11:13.2.5@naccakiṁ → naccantiṁ (bj, sya-all) @pli-tv-kd11
pli-tv-kd11:13.3.1@vassaṁvuṭṭho → vassaṁ vuttho (bj, sya-all, pts1ed) @pli-tv-kd11
pli-tv-kd11:13.3.2@samiñjitena → sammiñjitena (bj, sya-all, km, pts1ed) @pli-tv-kd11
pli-tv-kd11:13.6.22@rathassapi purato → purato dhāvissanti (sya-all) @pli-tv-kd11
pli-tv-kd11:13.6.24@vakkhanti → vadissanti (mr) @pli-tv-kd11
pli-tv-kd11:13.6.28@(…) → (yepi te manussā pubbe saddhā ahesuṁ pasannā tepi etarahi assaddhā appasannā yānipi tāni saṅghassa pubbe dānapathāni tānipi etarahi upacchinnāni riñcanti pesalā bhikkhū nivasanti pāpabhikkhū) (sya-all) @pli-tv-kd11
pli-tv-kd11:18.1.9@Adhivāsesuṁ kho therā bhikkhū → adhivāsesuṁ kho te therā bhikkhū (sya-all) @pli-tv-kd11
pli-tv-kd11:18.3.8@bhante, ratane buddhavacane → bhante buddhavacane (sya-all) @pli-tv-kd11
pli-tv-kd11:18.4.3@akkosāmi, paribhāsāmi → na paribhāsāmi (bj, sya-all) @pli-tv-kd11
pli-tv-kd11:20.1.2@anāvāsāya → avāsāya (bj, pts1ed) @pli-tv-kd11
pli-tv-kd11:22.3.13@sudhammo bhikkhu cittassa gahapatino dassanūpacāraṁ avijahāpetvā savanūpacāraṁ avijahāpetvā ekaṁsaṁ uttarāsaṅgaṁ kārāpetvā ukkuṭikaṁ nisīdāpetvā añjaliṁ paggaṇhāpetvā taṁ āpattiṁ desāpetabbo”ti → sudhammaṁ bhikkhuṁ … sā āpatti desāpetabbāti (si, sya-all) @pli-tv-kd11
pli-tv-kd11:24.1.2@Tena → tenahi (si, sya-all, mr) @pli-tv-kd11
pli-tv-kd11:25.2.28@channo bhikkhu saṅghena āpattiyā → channo bhikkhu āpattiyā (bj, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:27.1.27@na bhikkhu bhikkhūhi bhedetabbo → na bhikkhū bhikkhūhi bhedetabbā (sya-all) @pli-tv-kd11
pli-tv-kd11:27.1.32@bhikkhusikkhāya sikkhitabbaṁ → bhikkhusikkhā sikkhitabbā (sya-all) @pli-tv-kd11
pli-tv-kd11:28.1.4@na garuṁ kariṁsu → na garukariṁsu (bj, sya-all, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:28.2.15@bhikkhuṁ → bhikkhū (sya-all) @pli-tv-kd11
pli-tv-kd11:31.1.44@channo bhikkhu saṅghena āpattiyā → channo bhikkhu āpattiyā (bj, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:32.1.2@gaddhabādhipubbassa → gandhabādhipubbassa (sya-all, mr) @pli-tv-kd11
pli-tv-kd11:32.2.3@abbhakkhānaṁ → abbhācikkhanaṁ (mr) @pli-tv-kd11
pli-tv-kd11:32.2.7@bahupāyāsā → bahūpāyāsā (bj, sya-all, pts1ed) @pli-tv-kd11
pli-tv-kd11:32.3.20@moghapurisa, attanā duggahitena → duggahitena diṭṭhigatena (sya-all) @pli-tv-kd11
pli-tv-kd11:32.4.34@gaddhabādhipubbo, saṅghena pāpikāya → gandhabādhipubbo saṅghena pāpikāya (sya-all); gaddhabādhipubbo pāpikāya (pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:34.1.8@vibbhamatī”ti → vibbhamīti (bj, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.32@Anuppannāpi jāyanti → anuppannāni jāyanti (bj, sya-all) @pli-tv-kd11
pli-tv-kd11:35.1.33@uppannānipi vaḍḍhare → uppannāni ca vaḍḍhare (bj); uppannāpi pavaḍḍhanti (pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.35@padassato → parisato (bj); parassato (si); parīsato (sya-all); padassako (pts1ed) @pli-tv-kd11
pli-tv-kd11:35.1.47@vaggena cāpi → vaggenāpi ca (sya-all) @pli-tv-kd11
pli-tv-kd11:35.1.49@vaggena → vaggenāpi ca (sya-all) @pli-tv-kd11
pli-tv-kd11:35.1.51@vaggena cāpi → vaggenāpi ca (sya-all) @pli-tv-kd11
pli-tv-kd11:35.1.52@Anāpatti → anāpattiyā (sya-all) @pli-tv-kd11
pli-tv-kd11:35.1.53@vaggena cāpi → vaggenāpi ca (sya-all) @pli-tv-kd11
pli-tv-kd11:35.1.94@Savacaniṁ → na savacanīyaṁ (sya-all); savacani (pts1ed) @pli-tv-kd11
pli-tv-kd11:35.1.101@pañcahaṅgehi → pavaṅgehi (bj); pañcaaṅgo (pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.140@Diṭṭhiyāppaṭinissagge → diṭṭhiappaṭinissagge (sya-all, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.142@pabbajjaṁ → pabbājaṁ (bj, pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.151@pañcakāti nāmakā → dve pañcakoti nāmako (pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.155@kammāpi sādisā → kammesu sadisaṁ (pts1ed, mr) @pli-tv-kd11
pli-tv-kd11:35.1.156@paṭisārī ca → paṭisārīnaṁ (bj); paṭisāri ca (sya-all, pts1ed); Pabbajjā → pabbajaṁ (bj); pabbājā (pts1ed, mr) @pli-tv-kd11
pli-tv-kd12:1.2.24@samādātabbaṁ → samāditabbaṁ (bj, sya-all, pts1ed, mr) @pli-tv-kd12
pli-tv-kd12:1.4.10@caṅkamante → caṅkamantaṁ (aṭṭhakathāyaṁ saṁvaṇṇetabbapāṭho) @pli-tv-kd12
pli-tv-kd12:1.4.28@akammaṁ → akammaṁ taṁ (sya-all) @pli-tv-kd12
pli-tv-kd12:3.1.3@Bhagavato → te bhikkhū bhagavato (sya-all) @pli-tv-kd12
pli-tv-kd12:3.2.4@samādiyituṁ → samādātuṁ (sya-all, km); samādituṁ (pts1ed) @pli-tv-kd12
pli-tv-kd12:3.2.5@samādiyitabbo → samāditabbo (bj, sya-all, km, pts1ed) @pli-tv-kd12
pli-tv-kd12:7.1.5@caraṇaṁ → caraṇanti (bj, pts1ed, mr); carati (sya-all) @pli-tv-kd12
pli-tv-kd12:9.1.55@caṅkamante → caṅkamantaṁ (aṭṭhakathāyaṁ saṁvaṇṇetabbapāṭho) @pli-tv-kd12
pli-tv-kd12:9.1.87@yathāvuḍḍhaṁ → punāpare (pts1ed, mr) @pli-tv-kd12
pli-tv-kd12:9.1.93@pure pacchā tatheva ca → na pure pacchā samaṇena (bj, sya-all) @pli-tv-kd12
pli-tv-kd12:9.1.105@vattaṁva pārivāsike → ñātabbaṁ parivāsikaṁ (bj); ñātabbaṁ pārivāsikā (sya-all); ratti vā pārivāsike (pts1ed, mr) @pli-tv-kd12
pli-tv-kd12:9.1.109@sambhedaṁ nayato → sambhedanayato (bj, sya-all) @pli-tv-kd12
pli-tv-kd12:9.1.112@samenti ratticchedesu → samenti ratticchedā (sya-all); saman tiratticchedesu (pts1ed); samenti ratticchede (itipi) @pli-tv-kd12
pli-tv-kd13:1.1.6@Bhagavato → te bhikkhū bhagavato (sya-all) @pli-tv-kd13
pli-tv-kd13:1.2.6@Dutiyampi, sohaṁ → dutiyampi (bj, pts1ed, mr) @pli-tv-kd13
pli-tv-kd13:1.2.8@Tatiyampi sohaṁ → tatiyampi (bj, pts1ed, mr) @pli-tv-kd13
pli-tv-kd13:4.2.8@yācitabbaṁ → yācitabbo (bj) @pli-tv-kd13
pli-tv-kd13:7.2.9@yācitabbā → yācitabbo (bj) @pli-tv-kd13
pli-tv-kd13:7.3.21@mūlāyapaṭikassanā → mūlāya (sya-all); mūlāya paṭikassanaṁ (pts1ed) @pli-tv-kd13
pli-tv-kd13:19.1.44@saṅghaṁ → so saṅghaṁ (mr) @pli-tv-kd13
pli-tv-kd13:21.1.2@dvīhappaṭicchannāyo → dvīhapaṭicchannāyo (bj, sya-all); dvīhapaṭicchannā (pts1ed); dvīhappaṭicchannā (mr evaṁ yāvadasāhappaṭicchannā) @pli-tv-kd13
pli-tv-kd13:24.1.15@itarampi māsaṁ parivāsaṁ → itarampi māsaparivāsaṁ (bj, sya-all, mr) @pli-tv-kd13
pli-tv-kd13:24.3.61@itarampi māsaṁ parivāsassa → itarampi māsaparivāsassa (bj, mr); itarassapi māsaparivāsassa (sya-all) @pli-tv-kd13
pli-tv-kd13:24.3.65@itarampi māsaṁ parivāso → itarampi māsaparivāso (bj, mr); itaropi māsaparivāso (sya-all) @pli-tv-kd13
pli-tv-kd13:27.1.24@ukkhipiyyati → ukkhipīyati (bj, mr); ukkhipiyati (sya-all, pts1ed) @pli-tv-kd13
pli-tv-kd13:27.1.26@osāriyyati → osārīyati (bj, mr); osāriyati (sya-all, pts1ed) @pli-tv-kd13
pli-tv-kd13:28.1.1@parimāṇā → parimāṇāyo (bj, sya-all) @pli-tv-kd13
pli-tv-kd13:28.1.9@aparimāṇā → aparimāṇāyo (bj, sya-all) @pli-tv-kd13
pli-tv-kd13:29.1.2@puna → so ce puna (bj, mr) @pli-tv-kd13
pli-tv-kd13:31.3.92@vibbhamitvā → so bhikkhu vibbhamitvā (mr) @pli-tv-kd13
pli-tv-kd13:34.1.5@Yathāpaṭicchanne cassa → yathāpaṭicchannañcassa (bj); yathāpaṭicchannānañcassa (si) @pli-tv-kd13
pli-tv-kd13:35.2.30@Mūlāyaavisuddhinavakaṁ → mūlāyapaṭikassana avisuddhinavakaṁ (bj); mūlavisuddhanavakaṁ (pts1ed); samūlāvisuddhinavakaṁ (mr) @pli-tv-kd13
pli-tv-kd13:36.1.1@Idha pana, bhikkhave, bhikkhu sambahulā … → Idaṁ navakaṁ porāṇapotthakesu avisuddhivaseneva āgataṁ, vuccamānatatiyanavakena ca saṁsaṭṭhaṁ. Taṁ paṭivisodhakehi asaṁsaṭṭhaṁ katvā visuṁ patiṭṭhāpitaṁ. si , sya-all potthakesu pana taṁ visuddhivaseneva āgataṁ. Taṁ panevaṁ veditabbaṁ—“Mūlāyavisuddhinavaka: Idha pana bhikkhave bhikkhu sambahulā saṅghādisesā āpattiyo āpajjati parimāṇampi aparimāṇampi …pe… vavatthitampi sambhinnampi. So saṅghaṁ tāsaṁ āpattīnaṁ samodhānaparivāsaṁ yācati, tassa saṅgho tāsaṁ āpattīnaṁ samodhānaparivāsaṁ deti, so parivasanto antarā sambahulā saṅghādisesā āpattiyo āpajjati parimāṇāyo appaṭicchannāyo …pe… parimāṇāyo paṭicchannāyo …pe… parimāṇāyo paṭicchannāyopi appaṭicchannāyopi. So saṅghaṁ antarāāpattīnaṁ mūlāyapaṭikassanaṁ yācati, taṁ saṅgho antarāāpattīnaṁ mūlāya paṭikassati dhammikena kammena akuppena ṭhānārahena, dhammena samodhānaparivāsaṁ deti, dhammena mānattaṁ deti, dhammena abbheti. So bhikkhave bhikkhu visuddho tāhi āpattīhi. (1–3) Idha pana bhikkhave bhikkhu sambahulā saṅghādisesā āpattiyo āpajjati parimāṇampi aparimāṇampi …pe… vavatthitampi sambhinnampi. So saṅghaṁ tāsaṁ āpattīnaṁ samodhānaparivāsaṁ yācati, tassa saṅgho tāsaṁ āpattīnaṁ samodhānaparivāsaṁ deti, so parivasanto antarā sambahulā saṅghādisesā āpattiyo āpajjati aparimāṇāyo appaṭicchannāyo …pe… aparimāṇāyo paṭicchannāyo …pe… aparimāṇāyo paṭicchannāyopi appaṭicchannāyopi. So saṅghaṁ antarāāpattīnaṁ mūlāyapaṭikassanaṁ yācati, taṁ saṅgho antarāāpattīnaṁ mūlāya paṭikassati dhammikena kammena akuppena ṭhānārahena, dhammena samodhānaparivāsaṁ deti, dhammena mānattaṁ deti, dhammena abbheti. So bhikkhave bhikkhu visuddho tāhi āpattīti. (4–6) Idha pana bhikkhave bhikkhu sambahulā saṅghādisesā āpattiyo āpajjatī parimāṇampi aparimāṇampi …pe… vavatthitampi sambhinnampi. So saṅghaṁ tāsaṁ āpattīnaṁ samodhānaparivāsaṁ yācati, tassa saṅgho tāsaṁ āpattīnaṁ samodhānaparivāsaṁ deti, so parivasanto antarā sambahulā saṅghādisesā āpattiyo āpajjati parimāṇāyopi aparimāṇāyopi appaṭicchannāyo …pe… parimāṇāyopi aparimāṇāyopi paṭicchannāyo …pe… parimāṇāyopi aparimāṇāyopi paṭicchannāyopi appaṭicchannāyopi. So saṅghaṁ antarāāpattīnaṁ mūlāyapaṭikassanaṁ yācati, taṁ saṅgho antarāāpattīnaṁ mūlāya paṭikassati dhammikena kammena akuppena ṭhānārahena, dhammena samodhānaparivāsaṁ deti, dhammena mānattaṁ deti, dhammena abbheti. So bhikkhave bhikkhu visuddho tāhi āpattīhi. (7–9) Mūlāyapaṭikassanavisuddhinavakaṁ niṭṭhitaṁ.” @pli-tv-kd13
pli-tv-kd13:36.2.26@āpattīhi → ayaṁ paṭhamavāro bj, sya-all potthakesu paripuṇṇo @pli-tv-kd13
pli-tv-kd13:36.2.35@purimāāpattīnaṁ → purimānaṁ āpattīnaṁ (mr); purimāpattīnaṁ (csp1ed) @pli-tv-kd13
pli-tv-kd13:36.3.13@āpattīhi → imepi cattāro vārā bj, sya-all potthakesu paripuṇṇā @pli-tv-kd13
pli-tv-kd13:36.4.64@Mūlā aṭṭhārasa visuddhato → mūlāyapaṭivisuddhako (bj); mūlaṭṭhārasa Visuddhito (sya-all); mūlā pannarasa visuddhato (pts1ed); mūlā pannarasa Visuddhato (mr) @pli-tv-kd13
pli-tv-kd13:36.4.65@vibhajjapadānaṁ → vibhajjavādīnaṁ (bj) @pli-tv-kd13
pli-tv-kd14:2.1.8@imaṁ rocehī’ti → imaṁ rocethāti (mr) @pli-tv-kd14
pli-tv-kd14:4.1.4@uttari → uttariṁ (bj, pts1ed) @pli-tv-kd14
pli-tv-kd14:4.2.12@uddisāhī”ti → uddisāti (pli-tv-bu-vb-ss8:1 [Saṅghādisesā 8: Duṭṭhadosasikkhāpada]) @pli-tv-kd14
pli-tv-kd14:4.3.4@mallaputto yācitabbo → dabbo yācitabbo (bj, sya-all, pts1ed, mr) @pli-tv-kd14
pli-tv-kd14:4.4.10@kāyadaḷhibahulā → kāyadaḍḍhibahulā (bj); kāyadaḷhībahulā (pts1ed) @pli-tv-kd14
pli-tv-kd14:4.4.25@gotamakakandarāyaṁ → gotamakandarāyaṁ (bj); gomaṭakandarāyaṁ (sya-all, km, pts1ed) @pli-tv-kd14
pli-tv-kd14:4.4.27@tapodakandarāyaṁ → kapotakandarāyaṁ (si, sya-all, mr) @pli-tv-kd14
pli-tv-kd14:4.4.34@bibbohanaṁ → bimbohanaṁ (bj, sya-all, km, pts1ed) @pli-tv-kd14
pli-tv-kd14:4.5.1@mettiyabhūmajakā → mettiyabhummajakā (bj, sya-all, km, pts1ed) @pli-tv-kd14
pli-tv-kd14:4.5.6@yathārandhaṁ → yathāraddhaṁ (bj, sya-all, pts1ed) @pli-tv-kd14
pli-tv-kd14:4.5.8@tumhākaṁ kiṁ ahosī”ti → kiṁ nāhosīti (sya-all, km) @pli-tv-kd14
pli-tv-kd14:4.7.11@nisīdāpiyāmā”ti → nisīdāpeyyāmāti (si, pts1ed, mr) @pli-tv-kd14
pli-tv-kd14:4.7.12@kaṇājakena → kāṇājakena (sya-all, km) @pli-tv-kd14
pli-tv-kd14:4.7.21@antare paribhinnā”ti → santike paribhinnāti (sya-all, km) @pli-tv-kd14
pli-tv-kd14:4.8.1@kho mettiyā → sā mettiyā (bj, sya-all, mr) @pli-tv-kd14
pli-tv-kd14:4.8.17@tato savātaṁ → tato pavātaṁ (bj, sya-all, km, pts1ed) @pli-tv-kd14
pli-tv-kd14:4.8.20@paṭissutvā → paṭissuṇitvā (sya-all, km) @pli-tv-kd14
pli-tv-kd14:4.10.5@Sohaṁ → sohaṁ bhante (pts1ed, mr) @pli-tv-kd14
pli-tv-kd14:5.2.27@Sohaṁ amūḷho → sohaṁ bhante amūḷho (bj, pts1ed, mr) @pli-tv-kd14
pli-tv-kd14:10.1.1@dasa dhammikā → dasa dhammikā salākaggāhā (mr) @pli-tv-kd14
pli-tv-kd14:13.1.4@kakkhaḷattāya vāḷattāya → kakkhaḷatāya vāḷatāya (sya-all, km); kakkhaḷattāya vālattāya (pts1ed) @pli-tv-kd14
pli-tv-kd14:13.1.8@Tatra ce bhikkhūnaṁ → tatra ce bhikkhave bhikkhūnaṁ (sya-all) @pli-tv-kd14
pli-tv-kd14:14.1.1@bhikkhūpi bhikkhūhi vivadanti → etthantare pāṭho si , sya-all, km potthakesu natthi @pli-tv-kd14
pli-tv-kd14:14.2.1@kiccādhikaraṇaṁ → kiccādhikaraṇañca (mr) @pli-tv-kd14
pli-tv-kd14:14.2.3@bhikkhave, bhikkhū → bhikkhū bhikkhuṁ (mr) @pli-tv-kd14
pli-tv-kd14:14.5.35@Katamo kāyo → katamo ca kāyo (sya-all, km) @pli-tv-kd14
pli-tv-kd14:14.9.18@kusalaṁ → idaṁ padaṁ bj, sya-all potthakesu @pli-tv-kd14
pli-tv-kd14:14.17.1@sambahulā → bahutarā (bj, sya-all, pts1ed) @pli-tv-kd14
pli-tv-kd14:14.19.1@anantāni → anaggāni (bj, pts1ed); na cekassa → na cetassa (bj, sya-all, mr) @pli-tv-kd14
pli-tv-kd14:14.19.4@dhātā → dhatā (bj, sya-all, pts1ed) @pli-tv-kd14
pli-tv-kd14:14.19.6@ṭhito → cheko (pts1ed, mr) @pli-tv-kd14
pli-tv-kd14:14.24.2@na mayaṁ → na ca mayaṁ (mr) @pli-tv-kd14
pli-tv-kd14:14.25.10@tathā suvūpasantanti → yathā suvūpasantaṁ (bj, sya-all) @pli-tv-kd14
pli-tv-kd14:14.27.11@Tassa kho, bhikkhave → tassa kho taṁ bhikkhave (bj, sya-all, pts1ed, mr) @pli-tv-kd14
pli-tv-kd14:14.29.29@Tassa kho, bhikkhave → tassa kho taṁ bhikkhave (bj, mr); tassa khvetaṁ bhikkhave (sya-all) @pli-tv-kd14
pli-tv-kd15:1.1.4@gāmamoddavā”ti → gāmapoddavāti (bj, pts1ed); gāmapūṭavā (sya-all) @pli-tv-kd15
pli-tv-kd15:1.2.11@kuṭṭe → kuḍḍe (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:1.3.1@aṭṭāne → aṭṭhāne (bj, sya-all) @pli-tv-kd15
pli-tv-kd15:2.3.1@osaṇṭhenti → osaṇhenti (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:2.6.1@giraggasamajjo → samajjā (abhidhānaganthe) @pli-tv-kd15
pli-tv-kd15:3.1.3@yatheva → yathā ca (mr) @pli-tv-kd15
pli-tv-kd15:4.1.1@bāhiralomiṁ → bāhiyalomiṁ (mr) @pli-tv-kd15
pli-tv-kd15:4.1.5@bāhiyalomi uṇṇi → bāhiralomī uṇṇī (sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:5.2.11@nibbattabījaññeva → nibbaṭṭabījaññeva (bj, sya-all); nivattabījaññeva (pts1ed); aggiparicitaṁ, satthaparicitaṁ, nakhaparicitaṁ → aggiparijitaṁ satthaparijitaṁ nakhaparijitaṁ (pli-tv-pvr7:63 [Ekuttarikanaya/ Pañcakavāra]) @pli-tv-kd15
pli-tv-kd15:6.1.30@sarīsapāni → siriṁsapāni (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:8.1.1@candanassa → candanasārassa (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:8.1.5@bandhitvā → vāhitvā (sya-all); uḍḍitvā → vāhitvā (bj); pakkhipitvā (pts1ed) @pli-tv-kd15
pli-tv-kd15:8.1.13@sañcayo belaṭṭhaputto → sañjayo bellaṭṭhiputto (bj, pts1ed); sañjayo Veḷaṭṭhaputto (sya-all) @pli-tv-kd15
pli-tv-kd15:8.1.14@nāṭaputto → nātaputto (bj, pts1ed); nigaṇṭho → niggaṇṭho (sya-all) @pli-tv-kd15
pli-tv-kd15:9.2.15@Valī → valiṁ (pts1ed); calī (mr) @pli-tv-kd15
pli-tv-kd15:9.3.7@sodakaṁ → saudakaṁ (sya-all, pts1ed, mr) @pli-tv-kd15
pli-tv-kd15:9.4.6@Paripatitvā → parivaṭṭitvā (sya-all) @pli-tv-kd15
pli-tv-kd15:9.5.27@kavāṭaṁ paṇāmetabbaṁ → kavāṭo paṇāmetabbo (bj, mr) @pli-tv-kd15
pli-tv-kd15:10.1.7@ghaṭikaṭāhe → ghaṭikaṭāhena (sya-all) @pli-tv-kd15
pli-tv-kd15:11.3.4@kathinaṁ kathinarajjuṁ → kaṭhinaṁ kaṭhinarajjuṁ (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:11.6.16@ogumphetvā → ogumbetvā (bj, sya-all) @pli-tv-kd15
pli-tv-kd15:13.1.8@dhammakaraṇan”ti → dhammakarakanti (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:14.3.12@piṭṭhasaṅghāṭaṁ → piṭṭhasaṅghāṭaṁ (pts1ed); pīṭhasaṅghāṭaṁ (mr); aggaḷavaṭṭiṁ → aggalavaṭṭiṁ (pts1ed); aggaḷavaṭikaṁ (csp1ed) @pli-tv-kd15
pli-tv-kd15:14.3.31@tiṇacchadanaṁ na sedeti → tiṇacchadanaṁ sādeti (bj); tiṇacchādanena chādeti (mr) @pli-tv-kd15
pli-tv-kd15:14.4.2@anujānāmi, bhikkhave, koṭṭhakanti … Koṭṭhakassa kavāṭaṁ na hoti → anujānāmi bhikkhave koṭṭhakanti. koṭṭhako nīcavatthuko hoti …pe… anujānāmi bhikkhave uccavatthukaṁ kātunti. cayo paripatati …pe… anujānāmi bhikkhave cinituṁ tayo caye iṭṭhakācayaṁ silācayaṁ dārucayanti. ārohantā vihaññanti …pe… anujānāmi bhikkhave tayo sopāne iṭṭhakāsopānaṁ silāsopānaṁ dārusopānanti. ārohantā paripatanti …pe… anujānāmi bhikkhave ālambanabāhanti. koṭṭhakassa kavāṭaṁ na hoti. (sya1, sya2, km) | sopāne posāṇe iṭṭha (sya3) @pli-tv-kd15
pli-tv-kd15:14.4.3@Koṭṭhako nīcavatthuko hoti, udakena otthariyyati …pe… → koṭṭhako nīcavatthuko hoti …pe… (sya1, sya2, km) @pli-tv-kd15
pli-tv-kd15:14.4.10@iṭṭhakāsopānaṁ, silāsopānaṁ, dārusopānan”ti → sopāne posāṇe iṭṭha (sya3) @pli-tv-kd15
pli-tv-kd15:15.1.4@naggena → idaṁ padaṁ pts1ed, mr potthakesu @pli-tv-kd15
pli-tv-kd15:16.2.17@vāhenti → vāhanti (pts1ed, mr) @pli-tv-kd15
pli-tv-kd15:19.2.9@na ekattharaṇā → na ekattharaṇe (sya-all) @pli-tv-kd15
pli-tv-kd15:19.2.10@na ekapāvuraṇā → na ekapāvuraṇe (sya-all) @pli-tv-kd15
pli-tv-kd15:19.2.11@na ekattharaṇapāvuraṇā → na ekattharaṇapāvuraṇe (sya-all) @pli-tv-kd15
pli-tv-kd15:20.3.4@avāsāya → anāvāsāya (sya-all) @pli-tv-kd15
pli-tv-kd15:21.1.3@susumāragire → suṁsumāragire (bj, sya-all, pts1ed); saṁsumāragire (mr) @pli-tv-kd15
pli-tv-kd15:21.1.4@kokanado → kokanudo (sya-all, mr) @pli-tv-kd15
pli-tv-kd15:21.2.26@celapaṭikaṁ → celapattikaṁ (bj, pts1ed); ceḷapaṭikaṁ (sya-all) @pli-tv-kd15
pli-tv-kd15:22.2.1@tālavaṇṭañca → tālavaṇḍañca (mr) @pli-tv-kd15
pli-tv-kd15:23.2.4@chattappaggahitā → chattapaggahitā (sya-all); chattaṁ paggahetvā (pts1ed, mr) @pli-tv-kd15
pli-tv-kd15:25.1.1@romanthako → romaṭṭhako (sya-all, mr) @pli-tv-kd15
pli-tv-kd15:25.1.4@vikālāyaṁ → vikāleyaṁ (pts1ed); kathaṁ hi nāma vikālāyaṁ (mr) @pli-tv-kd15
pli-tv-kd15:26.1.2@pakiriyiṁsu → vippakirīyiṁsu (bj); parikiriṁsu (sya-all) @pli-tv-kd15
pli-tv-kd15:27.2.8@vīsatimaṭṭhaṁ → vīsatimaṭṭaṁ (bj, pts1ed) @pli-tv-kd15
pli-tv-kd15:27.4.6@aḍḍhadukaṁ → aḍḍhurakaṁ (bj); aḍḍharukaṁ (sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:28.2.10@āyogena → āyogā (bj, sya-all) @pli-tv-kd15
pli-tv-kd15:28.2.16@vemaṁ kavaṭaṁ → vemakaṁ vaṭṭaṁ (bj); vemakaṁ vaṭaṁ (sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:29.2.16@vidhan”ti → vithanti (bj, sya-all) @pli-tv-kd15
pli-tv-kd15:29.3.18@Koṭṭo → koṇo (bj, sya-all, pts1ed) @pli-tv-kd15
pli-tv-kd15:31.2.11@caturaṅgulapacchimaṁ → caturaṅgulaṁ pacchimaṁ (sya-all, mr) @pli-tv-kd15
pli-tv-kd15:33.1.1@yameḷakekuṭā nāma → yameḷutekulā nāma (bj, pts1ed); meṭṭhakokuṭṭhā nāma (sya-all) @pli-tv-kd15
pli-tv-kd15:33.3.8@vutto → vutte (pts1ed, mr) @pli-tv-kd15
pli-tv-kd15:34.1.13@Api nu kho, bhikkhave → bhikkhave bhikkhunā (sya-all) @pli-tv-kd15
pli-tv-kd15:34.2.4@Lasuṇena me, āvuso”ti → lasunena me āvusoti (pts1ed) @pli-tv-kd15
pli-tv-kd15:35.3.5@Avalekhanapiṭharo → avalekhanapidharo (pli-tv-kd18:53 [Vattakkhandhaka/Vaccakuṭivattakathā]) @pli-tv-kd15
pli-tv-kd15:35.4.11@padarasilaṁ → padasilaṁ (pts1ed); paṭṭasilaṁ (mr) @pli-tv-kd15
pli-tv-kd15:37.1.116@namatakañca → gandhapupphaṁ (sya-all) @pli-tv-kd15
pli-tv-kd16:1.2.1@seṭṭhī → seṭṭhi (pts1ed, mr) @pli-tv-kd16
pli-tv-kd16:1.2.13@bhante, amhehi → bhante (bj, pts1ed, mr) @pli-tv-kd16
pli-tv-kd16:1.2.15@pañca leṇāni → pañca senāsanāni (sya-all); pañca lenāni (pts1ed) @pli-tv-kd16
pli-tv-kd16:1.5.2@paṭihanti → paṭihanati (mr) @pli-tv-kd16
pli-tv-kd16:1.5.7@sañjāto → sañjāte (mr saddanīti) @pli-tv-kd16
pli-tv-kd16:1.5.11@buddhena → buddhehi (sya-all) @pli-tv-kd16
pli-tv-kd16:2.1.2@anuññātā”ti sakkaccaṁ → te sakkaccaṁ (sya-all, km) @pli-tv-kd16
pli-tv-kd16:2.1.23@ugghāṭetvā pavisanti → yehi te ugghāṭetvā pavisantīti (mr); Yehi → yepi (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:2.3.7@miḍḍhin”ti → mīḍhanti (bj); miḍhinti (sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:2.4.22@Āmalakavaṭṭikaṁ → āmalakavaṇṭikaṁ (sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:2.6.3@veṭhetun”ti → vetunti (bj, pts1ed) @pli-tv-kd16
pli-tv-kd16:2.6.12@bibbohanaṁ → bimbohanaṁ (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:2.6.15@addhakāyikāni → aḍḍhakāyikāni (sya-all, pts1ed, mr) @pli-tv-kd16
pli-tv-kd16:2.7.11@onandhitun”ti → onaddhituṁ (sya-all) @pli-tv-kd16
pli-tv-kd16:2.7.15@onaddhamañcaṁ → onandhamañcaṁ (mr) @pli-tv-kd16
pli-tv-kd16:2.7.16@nipatanti → nipphaṭanti (bj, pts1ed); nippāṭenti (sya-all); nipaṭanti (mr) @pli-tv-kd16
pli-tv-kd16:3.4.3@kulaṅkapādakan”ti → kuḷuṅkapādakanti (bj) @pli-tv-kd16
pli-tv-kd16:3.4.5@uddasudhan”ti → uddhāsudhanti (sya-all) @pli-tv-kd16
pli-tv-kd16:3.5.11@pakuṭṭaṁ → pakuḍḍaṁ (bj); pakuṭaṁ (pts1ed) @pli-tv-kd16
pli-tv-kd16:3.10.4@vāṭe → vaṭe (sya-all) @pli-tv-kd16
pli-tv-kd16:3.10.5@veḷuvāṭaṁ, kaṇḍakavāṭaṁ → veḷuvaṭaṁ kaṇḍakavaṭaṁ (sya-all), veḷuvāṭaṁ kaṇṭakīvāṭaṁ (pts1ed) @pli-tv-kd16
pli-tv-kd16:4.1.4@kammakāre → kammakare (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:4.3.1@sivakadvāraṁ → sīvadvāraṁ (bj); sītavanadvāraṁ (sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:4.3.5@sivako → sīvako (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:4.3.11@soḷasiṁ → soḷasinti (bj, mr) @pli-tv-kd16
pli-tv-kd16:4.4.18@cetasā”ti → cetasoti (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:4.5.1@anupubbiṁ kathaṁ → ānupubbikathaṁ (bj); anupubbikathaṁ (cck, sya1ed, pts1ed); anupubbīkathaṁ (sya2ed) @pli-tv-kd16
pli-tv-kd16:4.9.1@kumārassa → rājakumārassa (bj, sya-all, km); ti → ketuṁ (vajīrabuddhiṭīkāyaṁ) @pli-tv-kd16
pli-tv-kd16:4.10.15@pādāsi → adāsi (sya-all) @pli-tv-kd16
pli-tv-kd16:6.3.2.1@himavantapadese → himavantapasse (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:6.3.10@antarā satthīnaṁ → antarāsatthikaṁ (bj) @pli-tv-kd16
pli-tv-kd16:8.2@koseyyaṁ → koseyyaṁ kambalaṁ (bj, sya-all) @pli-tv-kd16
pli-tv-kd16:8.7@gihivikataṁ → gihivikaṭaṁ (bj, mr); avasesaṁ gihivikaṭaṁ (sya-all) @pli-tv-kd16
pli-tv-kd16:10.1.21@vippakatabhojano → vippakatabhojane anantariko (sya-all); Vippakatabhojane (pts1ed) @pli-tv-kd16
pli-tv-kd16:10.2.10@palibuddhenti → palibuddhanti (sya-all, pts1ed); palibundhanti (mr) @pli-tv-kd16
pli-tv-kd16:11.1.3@Addasaṁsu → addasāsuṁ (pts1ed, mr); bhikkhū vihāraṁ → aññataraṁ vihāraṁ (mr) @pli-tv-kd16
pli-tv-kd16:13.1.5@Tedha → te ca (sya-all, mr) @pli-tv-kd16
pli-tv-kd16:13.2.8@bhindiṁsu, pīṭhe → ekapīṭhe (sya-all); mañce → ekamañce (sya-all) @pli-tv-kd16
pli-tv-kd16:14.1.10@bhūmattharaṇaṁ → bhummattharaṇaṁ (bj, sya-all, pts1ed) @pli-tv-kd16
pli-tv-kd16:15.1.14@vissajjessantī”ti → vissajjissantīti (mr) @pli-tv-kd16
pli-tv-kd16:15.2.1@na vissajjetabbāni → na vissajjitabbāni (mr) @pli-tv-kd16
pli-tv-kd16:15.2.17@kuṭhārī → kudhārī (mr); parasu → pharasu (bj, sya-all, pts1ed, mr) @pli-tv-kd16
pli-tv-kd16:15.2.21@muñjaṁ, pabbajaṁ → muñjaṁ babbajaṁ (bj); muñjababbajaṁ (pts1ed) @pli-tv-kd16
pli-tv-kd16:16.2.13@avebhaṅgiyāni → avebhaṅgikāni (mr) @pli-tv-kd16
pli-tv-kd16:17.1.4@āḷavakā → āḷavikā (sya-all, mr) @pli-tv-kd16
pli-tv-kd16:18.1.12@nātiharanti → nābhiharanti (sya-all, mr) @pli-tv-kd16
pli-tv-kd16:21.1.27@paṭṭikāya vā → paṭikāya vā (sya-all) @pli-tv-kd16
pli-tv-kd16:21.3.1@uppanno → ussanno (sya-all) @pli-tv-kd16
pli-tv-kd16:21.3.16@ekā → ekekā (bj, pts1ed) @pli-tv-kd16
pli-tv-kd17:1.1.7@paricārayamāno → paricāriyamāno (sya-all, pts1ed, mr); vassike pāsāde cattāro māse → vassike pāsāde vassike cattāro māse (bj) @pli-tv-kd17
pli-tv-kd17:1.2.7@Niddhāpetvā → niḍḍahetabbaṁ niḍḍahetvā (bj); niddāpetabbaṁ niddāpetvā (sya-all); niḍḍāpetabbaṁ niḍḍāpetvā (pts1ed) @pli-tv-kd17
pli-tv-kd17:1.2.13@opunāpetabbaṁ → ophunāpetabbaṁ (sya-all, mr); ophuṇāpetabbaṁ (yojanā) @pli-tv-kd17
pli-tv-kd17:1.2.28@ti → imassa anantaraṁ kesuci potthakesu evampi pāṭho dissati @pli-tv-kd17
pli-tv-kd17:1.3.15@kyāhaṁ → tyāhaṁ (bj, sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:1.4.9@Kimaṅgaṁ → kimaṅga (bj, pts1ed) @pli-tv-kd17
pli-tv-kd17:1.4.20@na nivatto → yaṁ nivatto (bj); yaṁ pana nivatto (sya-all) @pli-tv-kd17
pli-tv-kd17:1.4.29@nimmānāyissatī”ti → nimmānīyissatīti (bj); nimmādayissatīti (si, sya-all); nimmāniyissati (pts1ed) @pli-tv-kd17
pli-tv-kd17:2.1.12@ucchaṅge → uccaṅke (sya-all) @pli-tv-kd17
pli-tv-kd17:2.2.3@māgadhakāni → māgadhikāni (sya-all) @pli-tv-kd17
pli-tv-kd17:2.2.7@pariyādinnacittassa → pariyādiṇṇacittassa (mr) @pli-tv-kd17
pli-tv-kd17:2.3.11@paccāsīsati → paccāsiṁsati (bj, sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:3.4.8@bandhitvā divā divassa → divā divasassa (mr) @pli-tv-kd17
pli-tv-kd17:3.4.11@baddhaṁ → bandhaṁ (mr) @pli-tv-kd17
pli-tv-kd17:3.8.3@addasāsuṁ → addasaṁsu (sya-all, pts1ed, mr) @pli-tv-kd17
pli-tv-kd17:3.10.3@ca → tedha (bj, pts1ed) @pli-tv-kd17
pli-tv-kd17:3.12.3@abhirūpo vata, bho → abhirūpo vata bho gotamo (sya-all, km) @pli-tv-kd17
pli-tv-kd17:3.12.7@phuṭṭho → phuṭo (mr); bhagavato → bhagavatā (bj) @pli-tv-kd17
pli-tv-kd17:3.12.17@paṭikuṭiyova → paṭikuṭito paṭisakki (bj, sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:3.13.20@kulānuddayāya → kulānudayatāya (sya-all) @pli-tv-kd17
pli-tv-kd17:3.14.1@kaṭamodakatissako → kaṭamorakatisso (bj); kaṭamorakatissako (sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:3.14.17@Lūkhappasannā → lūkhapasannā (pli-tv-bu-vb-ss10:1 [Saṅghādisesā 10: Saṅghabhedasikkhāpada]) @pli-tv-kd17
pli-tv-kd17:3.16.15@kappaṭṭhikaṁ → kappaṭṭhitikaṁ (sya-all) @pli-tv-kd17
pli-tv-kd17:3.17.14@Sādhuṁ pāpena dukkaraṁ → sādhu pāpena dukkaraṁ (ud5.8:1 [Saṅghabhedasutta]) @pli-tv-kd17
pli-tv-kd17:4.1.25@bhikkhūnaṁ saññattiyā”ti → bhikkhusaññattiyāti (bj, sya-all, pts1ed); bhikkhū saññattiyā (mr) @pli-tv-kd17
pli-tv-kd17:4.5.11@mamānukrubbaṁ → mamānukubbaṁ (bj, sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:4.5.12@vikrubbato → vikubbato (bj, sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:4.5.13@ghasānassa → ghasamānassa (pts1ed, mr) @pli-tv-kd17
pli-tv-kd17:4.6.9@byathati → byādhati (bj, sya-all); vyādhati (pts1ed) @pli-tv-kd17
pli-tv-kd17:4.6.13@akkhāti → akkhātā (mr) @pli-tv-kd17
pli-tv-kd17:4.8.18@padūsituṁ → padussituṁ (mr) @pli-tv-kd17
pli-tv-kd17:4.8.23@Samaggataṁ → sammāgataṁ (bj, pts1ed); samagataṁ (sya-all) @pli-tv-kd17
pli-tv-kd17:4.8.25@krubbetha → kubbetha (bj, sya-all, pts1ed) @pli-tv-kd17
pli-tv-kd17:5.2.21@āveniṁ → āveṇi (bj, pts1ed); āveṇikaṁ (sya-all) @pli-tv-kd17
pli-tv-kd17:5.5.3@Siyā → siyā nu kho (sya-all, km) @pli-tv-kd17
pli-tv-kd17:5.5.20@tasmiṁ dhammadiṭṭhi bhede dhammadiṭṭhi … → etthantare pāṭho sya-all potthakesu natthi, vimativinodanīṭīkāya sameti @pli-tv-kd17
pli-tv-kd17:5.5.48@tasmiṁ dhammadiṭṭhi, bhede dhammadiṭṭhi … → etthantare pāṭho sya-all potthakesu natthi @pli-tv-kd17
pli-tv-kd18:1.1.4@uparipiṭṭhito → uparipiṭṭhato (?) @pli-tv-kd18
pli-tv-kd18:1.2.1@vivaritvā sīse cīvaraṁ → vivaritvā cīvaraṁ (pts1ed, mr) @pli-tv-kd18
pli-tv-kd18:1.2.14@Na teneva udakaṁ āsiñcitabbaṁ → yena hatthena udakaṁ āsiñcitabbaṁ (sya-all), na teneva hatthena udakaṁ āsiñcitabbaṁ (pts1ed) @pli-tv-kd18
pli-tv-kd18:1.2.17@dhovitvā → pīḷetvā (sya-all) @pli-tv-kd18
pli-tv-kd18:1.2.21@sekkhasammatāni → sekhasammatāni (pts1ed, mr) @pli-tv-kd18
pli-tv-kd18:1.3.2@puñjīkataṁ → puñjakitaṁ (pts1ed, mr) @pli-tv-kd18
pli-tv-kd18:1.3.15@uhaññīti → ūhaññīti (bj, sya-all, pts1ed) @pli-tv-kd18
pli-tv-kd18:1.4.1@yathāṭhāne → yathābhāgaṁ (sya-all, pts1ed, mr) @pli-tv-kd18
pli-tv-kd18:2.1.1@na pānīyena pucchanti → na paribhojanīyena pucchanti (sya-all, km); na pāniyena pucchanti (pts1ed) @pli-tv-kd18
pli-tv-kd18:2.2.1@pānīyena pucchitabbo → paribhojanīyena pucchitabbo (sya-all); pāniyena pucchitabbo (pts1ed) @pli-tv-kd18
pli-tv-kd18:2.2.4@dhovitvā → dhovitvā pīḷetvā (sya-all) @pli-tv-kd18
pli-tv-kd18:3.2.1@āpucchā pakkamitabbaṁ → āpucchitabbaṁ (sya-all) @pli-tv-kd18
pli-tv-kd18:4.4.4@osiñci → osiñciyyī (mr); osiñciṁsu → osiñciyyiṁsu (mr) @pli-tv-kd18
pli-tv-kd18:5.2.25@ṭhapeti → ṭhāpeti (mr); dātukāmassāti → dātukāmā viyāti (bj, pts1ed); dātukāmiyāti (sya-all) @pli-tv-kd18
pli-tv-kd18:5.2.27@ulloketabbaṁ → oloketabbaṁ (sya-all) @pli-tv-kd18
pli-tv-kd18:6.1.12@(…) → (atthi bhante nakkhattapadānīti, na jānāma āvusoti, atthi bhante disābhāganti, na jānāma āvusoti.) bj vimatiṭīkāya pana @pli-tv-kd18
pli-tv-kd18:7.1.2@aṅgaṇe → paṅgaṇe (bj, sya-all, pts1ed) @pli-tv-kd18
pli-tv-kd18:8.1.2@Bhikkhū → therā ca bhikkhū (sya-all, km) @pli-tv-kd18
pli-tv-kd18:9.1.2@āmasissatī”ti → ācamissatīti (mr) @pli-tv-kd18
pli-tv-kd18:10.2.1@ubbhajitvāpi → ubbhujjitvāpi (bj); ubbhujitvāpi (sya-all, pts1ed) @pli-tv-kd18
pli-tv-kd18:10.3.1@bahi ṭhitena → bahi ṭhitena (bj, mr); bahiṭṭhitena (sya1ed, sya2ed) @pli-tv-kd18
pli-tv-kd18:10.3.21@uhatā → ūhatā (bj, sya-all, pts1ed) @pli-tv-kd18
pli-tv-kd18:10.3.22@avalekhanapidharo → avalekhanapiṭharo (bj, sya-all; pli-tv-kd15:193 [Khuddakavatthu]) @pli-tv-kd18
pli-tv-kd18:11.3.1@sodako → saudako (sya-all, pts1ed, mr) @pli-tv-kd18
pli-tv-kd18:11.17.7@rajitabbaṁ → rajetabbaṁ (sya-all) @pli-tv-kd18
pli-tv-kd18:11.17.9@rajantena → rajentena (sya-all) @pli-tv-kd18
pli-tv-kd18:11.18.4@chedetabbā → chettabbā (bj); chedātabbā (pts1ed); cheditabbā (mr) @pli-tv-kd18
pli-tv-kd18:11.18.6@veyyāvacco → veyyāvaccaṁ (mr) @pli-tv-kd18
pli-tv-kd18:12.6.4@temetabbā, jantāgharapīṭhaṁ ādāya → ādāya saddhivihārikassa piṭṭhito piṭṭhito (mr) @pli-tv-kd18
pli-tv-kd18:12.11.186@temetabbā, jantāgharapīṭhaṁ ādāya → ādāya antevāsikassa piṭṭhito piṭṭhito (mr) @pli-tv-kd18
pli-tv-kd18:12.11.265@āgantukehime → … ve (mr) @pli-tv-kd18
pli-tv-kd19:1.2.5@kasambujātaṁ → kasambukajātaṁ (sya-all, pts1ed, mr) @pli-tv-kd19
pli-tv-kd19:1.3.8@ayaṁ → ayampi (sya-all) @pli-tv-kd19
pli-tv-kd19:1.3.15@ca → yā kāci (sya-all) @pli-tv-kd19
pli-tv-kd19:1.3.21@bahuratano → pahūtaratano (mr) @pli-tv-kd19
pli-tv-kd19:1.3.24@Tatrime bhūtā—timi, timiṅgalo → timirapiṅgalo (bj); timitimiṅgalo mahātimiṅgalo (sya-all, km) @pli-tv-kd19
pli-tv-kd19:1.4.16@pabbajitvā → pabbajitā (bj) @pli-tv-kd19
pli-tv-kd19:1.4.37@Channamativassati → suchannamativassati (mr) @pli-tv-kd19
pli-tv-kd19:2.1.5@Na ca, bhikkhave → na ca bhikkhave bhikkhunā (sya-all, km) @pli-tv-kd19
pli-tv-kd19:3.2.1@pātimokkhaṭṭhapanaṁ → idaṁ padaṁ bj, sya-all potthakesu @pli-tv-kd19
pli-tv-kd19:3.4.5@nāpi → na pi (sya-all); nāpi ca (mr) @pli-tv-kd19
pli-tv-kd19:3.4.12@antarāyānaṁ aññatarena → aññatarena antarāyena (sya-all, km) @pli-tv-kd19
pli-tv-kd19:3.5.16@sikkhaṁ paccakkhātakathā → sikkhāpaccakkhātakathā (bj); sikkhaṁ paccakkhātakakathā (an10.32:1 [32. Pātimokkhaṭṭhapanāsutta]) @pli-tv-kd19
pli-tv-kd19:3.8.10@diṭṭhasutaparisaṅkito → diṭṭhasutaparisaṅkito hoti (sya-all, km) @pli-tv-kd19
pli-tv-kd19:4.1.3@katamaṅgasamannāgataṁ → kataṅgasamannāgataṁ (pts1ed, mr) @pli-tv-kd19
pli-tv-kd19:5.1.22@na sampāyati → na sampādessati (cck); na sampādeti (sya1ed, sya2ed); na sampādayati (pts1ed, mr) @pli-tv-kd19
pli-tv-kd19:5.7.3@anukampitā → anukampatā (pts1ed, mr) @pli-tv-kd19
pli-tv-kd19:5.7.25@vācesi → ṭhāpesi (sya-all, mr) @pli-tv-kd19
pli-tv-kd19:5.7.62@Soyeva tassa akkhāti → añño cāro cayenaṁ; suddhā ca tassa akkhāti (bj); añño cārocayāti taṁ; suddhe va tassa akkhāti (sya-all); vipassañño cārocati; taṁ suddheva tassa akkhāti (pts1ed, mr) @pli-tv-kd19
pli-tv-kd19:5.7.79@tathā vācā → tathevāpi (sya-all) @pli-tv-kd19
pli-tv-kd20:1.1.2@mahāpajāpati → mahāpajāpatī (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:1.3.11@Atha kho āyasmā ānando → atha kho āyasmato ānandassa etadahosi (an8.51:1 [51. Gotamīsutta]) @pli-tv-kd20
pli-tv-kd20:1.3.15@sakadāgāmiphalaṁ → sakidāgāmiphalaṁ (sya-all) @pli-tv-kd20
pli-tv-kd20:1.4.4@garukatvā → garuṅkatvā (mr) @pli-tv-kd20
pli-tv-kd20:1.5.22@atimuttakamālaṁ → adhimattakamālaṁ (sya-all) @pli-tv-kd20
pli-tv-kd20:1.6.7@bahutthikāni → bahuitthikāni (bj, sya-all) @pli-tv-kd20
pli-tv-kd20:1.6.9@setaṭṭikā → setaṭṭhikā (bj, sya-all) @pli-tv-kd20
pli-tv-kd20:1.6.11@mañjiṭṭhikā → mañjeṭṭhikā (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:2.2.15@tadeva sā → tadevassā (sya-all, mr) @pli-tv-kd20
pli-tv-kd20:9.3.2@ovādaṭṭhapitāya → ovādaṭhapitāya (pts1ed); ovādaṁ ṭhapitāya (mr) @pli-tv-kd20
pli-tv-kd20:9.3.11@Tena kho pana samayena → tena kho pana samayena bhikkhū (sya-all, km) @pli-tv-kd20
pli-tv-kd20:9.4.18@bhikkhave, dve tisso bhikkhuniyo → dvīhi tīhi bhikkhunīhi (sya-all); dve tisso bhikkhunīhi (pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:10.1.7@ekapariyākataṁ → ekapariyāyakataṁ (sya-all) @pli-tv-kd20
pli-tv-kd20:10.1.9@vilīvena → vilivena (sya-all, pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:10.4.1@avaṅgaṁ → apāṅgaṁ (?) @pli-tv-kd20
pli-tv-kd20:10.4.3@naccaṁ → sanaccaṁ (bj, sya-all, pts1ed); samajjaṁ (mr); harītakapakkikaṁ → haritakapattikaṁ (sya-all); harītakapaṇṇikaṁ (pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:12.1.2@datvā pātesi → pavaṭṭesi (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:15.1.17@paṭiggāhāpetvā → paṭiggahāpetvā (sya-all, pts1ed, mr); bhikkhunīhi → bhikkhunīhi bhikkhūhi (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:15.2.17@sannidhiṁ bhikkhūhi → bhikkhūhi bhikkhunīhi (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:16.1.1@bhikkhunīnaṁ → bhikkhunīnaṁ senāsanaṁ (sya-all, km) @pli-tv-kd20
pli-tv-kd20:17.1.2@sikharaṇī → sikhariṇī (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:17.2.16@saṅkaccikaṁ → saṅkacchikaṁ (sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd20:17.4.8@attanāva → attanā vā (pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:17.4.14@parāya → parāya vā (pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:17.5.5@vitthāyi → vitthāsi (sya-all, pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:18.1.9@sabbattha yathāvuḍḍhaṁ → aññattha yathāvuḍḍhaṁ (sya-all) @pli-tv-kd20
pli-tv-kd20:19.1.15@bhikkhave, pacchābhattaṁ → bhikkhave bhikkhuniyā pacchābhattaṁ (sya-all, km) @pli-tv-kd20
pli-tv-kd20:19.1.16@vikāle → vikālaṁ (mr) @pli-tv-kd20
pli-tv-kd20:19.1.18@ajjatanā bhikkhunisaṅghaṁ → ajjatanā (si, pts1ed), ajjatanāya (mr) @pli-tv-kd20
pli-tv-kd20:19.3.4@Vadatu → vadatu maṁ (mr) @pli-tv-kd20
pli-tv-kd20:21.1.4@gaṅgāmahiyāyā”ti → gaṅgāmahīyāti (bj); gaṅgāmahikāyāti (sya-all) @pli-tv-kd20
pli-tv-kd20:25.2.4@paṭipajjanti → paṭipajjati (sya-all) @pli-tv-kd20
pli-tv-kd20:27.1.3@bhikkhave, sāditun”ti → sādiyitunti (sya-all, mr) @pli-tv-kd20
pli-tv-kd20:27.2.1@sādiyantī → sādiyanti (sya-all); sādiyantā (pts1ed, mr) @pli-tv-kd20
pli-tv-kd20:27.4.100@sālokena naccena ca → sāloke sanaccena ca (bj); sālokena sanaccanaṁ (sya-all); sālokena sanaccena ca (pts1ed) @pli-tv-kd20
pli-tv-kd20:27.4.125@bhoṭṭhaṁ → heṭṭhā (bj); heṭṭhaṁ (sya-all, pts1ed); bhutti (mr) @pli-tv-kd20
pli-tv-kd20:27.4.199@Yāyanti → tā yanti (bj, sya-all, pts1ed) @pli-tv-kd20
pli-tv-kd21:1.1.31@dippati → dibbati (mr) @pli-tv-kd21
pli-tv-kd21:1.5.3@khaṇḍaphullapaṭisaṅkharaṇaṁ → khaṇḍaphullappaṭisaṅkharaṇaṁ (csp1ed, csp2ed) @pli-tv-kd21
pli-tv-kd21:1.6.2@sannipāto → sannipātoti (mr) @pli-tv-kd21
pli-tv-kd21:1.7.36@ubhatovibhaṅge → ubhatovinaye (si, sya-all, pts1ed) @pli-tv-kd21
pli-tv-kd21:1.10.12@māyimāsaṁ → māyimā (bj, sya-all, pts1ed) @pli-tv-kd21
pli-tv-kd21:1.12.13@udenassa → utenassa (mr) @pli-tv-kd21
pli-tv-kd21:1.14.18@Ye → ye pana (mr) @pli-tv-kd21
pli-tv-kd22:1.1.5@kaṁsapātiṁ → kaṁsacāṭiṁ (sya-all) @pli-tv-kd22
pli-tv-kd22:1.1.15@paṭivīsaṁ → paṭiviṁsaṁ (bj); paṭivisaṁ (sya-all, pts1ed); bhikkhaggena → bhikkhuggena (sya-all) @pli-tv-kd22
pli-tv-kd22:1.3.23@Rāgadosaparikliṭṭhā → rāgadosaparikkliṭṭhā (bj); rāgadosaparikkiliṭṭhā (pts1ed); rāgadosaparikkiṭṭhā (an4.50:1 [50. Upakkilesasutta]) @pli-tv-kd22
pli-tv-kd22:1.3.25@Avijjānivuṭā → avijjānīvutā (sya-all); avijjānivutā (pts1ed) @pli-tv-kd22
pli-tv-kd22:1.7.11.1@pāveyyakānañca → pāṭheyyakānañca (sya-all, pts1ed) @pli-tv-kd22
pli-tv-kd22:1.9.24@kaṇṇakujjaṁ → kannakujjaṁ (bj) @pli-tv-kd22
pli-tv-kd22:1.9.39@sahajātiṁ → sahaṁjātiṁ (mr) @pli-tv-kd22
pli-tv-kd22:1.10.4@antevāsikaṁ → antevāsiṁ (sya-all) @pli-tv-kd22
pli-tv-kd22:1.10.30@āgate bhikkhū anumānessāmā”ti → anujānessāmāti (pts1ed); anumatiṁ ānessāmāti (mr) @pli-tv-kd22
pli-tv-kd22:2.2.3@pāveyyakā → pāṭheyyakā (sya-all, pts1ed) @pli-tv-kd22
pli-tv-kd22:2.2.7@samiñjeyya → sammiñjeyya (sya-all, pts1ed) @pli-tv-kd22
pli-tv-kd22:2.3.5@āyasmato → āyasmato ca (sya-all) @pli-tv-kd22
pli-tv-kd22:2.3.30@āvuso → āvuso uttara (sya-all, km) @pli-tv-kd22
pli-tv-kd22:2.4.4@mūlādāyakā → mūladāyakā (bj) @pli-tv-kd22
pli-tv-kd22:2.5.5@eso → heso (sya-all) @pli-tv-kd22
pli-tv-kd22:2.9.13@rahosi upanāmayaṁ → dūratopi udāmassa (sya-all); dūraho pi udāmassa (pts1ed); dūratopi udapādi (mr) @pli-tv-kd22
pli-tv-kd22:2.9.14@Garu → dāruṇaṁ (sya-all); dārukaṁ (pts1ed) @pli-tv-kd22
pli-tv-kd22:2.9.17@Cūḷavaggo → cullavaggo (bj, sya-all); cullavaggaṁ (pts1ed) @pli-tv-kd22
pli-tv-pvr1.1:2.2@anupaññatti → anuppaññatti (sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:3.46@Sekkhā → sekhā (bj, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:4.3@Moggaliputtena → moggalīputtena (sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:4.4@jambusirivhaye → jambusarivhaye (sārattha) @pli-tv-pvr1.1
pli-tv-pvr1.1:5.1@iṭṭiyo → iṭṭhiyo (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:5.2@sambalo tathā → uttiyo ceva sambalo (bj, sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:9.1@Punadeva → punareva (sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:11.2@rohaṇe → rohaṇo (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:13.3@mahāsivo → mahāsīvo (bj, sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:18.1@Cūḷadevo → phussadevo (bj); cūḷādevo (sya-all); cūladevo (pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:18.3@Sivatthero → sīvatthero (bj, sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:20.6@adinnaṁ → adinnāni (bj, sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:51.4@Mettiyabhūmajake → … bhummajake (bj, sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:53.1@Bhedānuvattakānaṁ → bhedakānu … (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:59.2@tasseva → tatheva (sya-all, pts1ed, mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:82.0.2@4.1 Kathinavagga → cīvaravagga (pli-tv-bu-vb-np1:2 [Nissaggiyā Pācittiyā 1: Kathinasikkhāpada]) @pli-tv-pvr1.1
pli-tv-pvr1.1:82.1@atirekacīvaraṁ → atirekacīvaraṁ dasāhātikkantaṁ (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:88.1@tatuttari → tatuttariṁ (bj); taduttariṁ (sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:91.7@ajjaṇho → ajjanho (bj); ajjuṇho (si, sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:95.6@odātaṁ ante → odātānaṁ ante (bj, sya-all); odātānaṁ ante ante (si) @pli-tv-pvr1.1
pli-tv-pvr1.1:116.1@Dasekarattimāso ca → From here to the end of the last verse, sya-all has “atirekañca pattañca, ūnena bandhanena ca; bhesajjaṁ sāṭakañceva, kupitena achindanaṁ. duve tantavāyā ceva, accekacīvarena ca; chārattaṁ vippavāsena, attano pariṇāmanāti.” @pli-tv-pvr1.1
pli-tv-pvr1.1:116.3@Aññātaṁ tañca → aññātakañca (bj, pts1ed, mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:120.6@bhaṇḍantā → bhaṇḍentā (bj, pts1ed, mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:131.6@aññenaññaṁ → aññena aññaṁ (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:142.6@cūḷapanthako → cullapanthakaṁ (bj); cūlapanthako (pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:154.7@catasso → tisso (sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:161.6@āhari → āhāresi (bj, pts1ed); āharesi (sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:168.1@purebhattaṁ pacchābhattaṁ → purebhattaṁ vā pacchābhattaṁ vā (bj, sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:176.1@hasadhamme → hassadhamme (bj, sya-all); hāsadhamme (pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:176.2@Sāvatthiyaṁ → sāvatthiyā (sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:182.1@appaccuddhāraṇaṁ → apaccuddhāraṇaṁ (bj); appaccuddhārakaṁ (sya-all, pts1ed) @pli-tv-pvr1.1
pli-tv-pvr1.1:192.6@pāpikāya diṭṭhiyā → pāpikaṁ diṭṭhiṁ (bj, sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:193.1@Jānaṁ tathāvādinā bhikkhunā → ariṭṭhena bhikkhunā (mr); akaṭānudhammena → akatānudhammena (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:196.1@byattaṁ → viyattaṁ (bj); aññaṁ → nāññaṁ (bj, pts1ed); naññaṁ (sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:202.1@upadahantassa → uppādentassa (sya-all) @pli-tv-pvr1.1
pli-tv-pvr1.1:203.1@upassutiṁ → upassuti (?) @pli-tv-pvr1.1
pli-tv-pvr1.1:204.1@khīyanadhammaṁ → khīyadhammaṁ (pts1ed); khiyyadhammaṁ (mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:205.6@pakkāmi → pakkami (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:209.0@5.9 Rājavagga → ratanavagga (pli-tv-bu-vb-pc83:1 [Pācittiyā 83: Antepurasikkhāpada]) @pli-tv-pvr1.1
pli-tv-pvr1.1:221.1@Musā omasapesuññaṁ → from Musā omasapesuññaṁ at 221.1 to vassikā sugatena cāti at 229.6, sya-all has “antepurañca uggaṇhe, anāpucchā pavesane; sūcigharañca mañcañca, tūlonaddhaṁ nisīdanaṁ; kaṇḍuvassikasāṭikaṁ, pamāṇaṁ cīvaraṁ dhārayīti.” @pli-tv-pvr1.1
pli-tv-pvr1.1:221.3@Aññatra viññunā bhūtā → desanārocanā ceva (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:222.1@Bhūtaṁ aññāya ujjhāyi → bhūtaññavādaujjhāyi (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:225.1@Acelakaṁ uyyokhajja → aceḷakā uyyokhajja (bj); acelakānupakhajja (pts1ed, mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:227.3@Theyyaitthiavadesaṁ → ariṭṭhakaṁ (vibhaṅge) @pli-tv-pvr1.1
pli-tv-pvr1.1:266.1@pallatthikāya → pallattikāya (mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:272.0@7.4 Piṇḍapātavagga → sakkaccavagga (pli-tv-bu-vb-sk31:1 [Sekhiyā 31: Sakkaccasikkhāpada]) @pli-tv-pvr1.1
pli-tv-pvr1.1:283.1@kabaḷe → kabale (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:293.1@Kabaḷavaggo → kabalavaggo (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:312.4@kāyato ca → etthantare pāṭho sya-all potthakesu @pli-tv-pvr1.1
pli-tv-pvr1.1:320.1@Pādukavaggo → pādukāvaggo (bj) @pli-tv-pvr1.1
pli-tv-pvr1.1:323.4@samatittikaṁ → samatitthikaṁ (pts1ed, mr) @pli-tv-pvr1.1
pli-tv-pvr1.1:324.4@viññattujjhānasaññinā → … saññitā (bj) @pli-tv-pvr1.1
pli-tv-pvr1.2:1.5@vaṭṭakate → vivaṭakate (sya-all); vattakate (pts1ed) @pli-tv-pvr1.2
pli-tv-pvr1.2:6.1@(…) → (upakkamitvā asuciṁ mocento kati āpattiyo āpajjati) (bj, sya-all) @pli-tv-pvr1.2
pli-tv-pvr1.2:15.1@samanubhāsanāya → samanubhāsiyamāno (bj, sya-all) @pli-tv-pvr1.2
pli-tv-pvr1.2:16.1@samanubhāsanāya → samanubhāsiyamānā (bj, sya-all) @pli-tv-pvr1.2
pli-tv-pvr1.2:17.1@samanubhāsanāya → samanubhāsiyamāno (bj, sya-all) @pli-tv-pvr1.2
pli-tv-pvr1.2:72.1@tatuttari → tatuttariṁ (bj); taduttariṁ (sya-all, pts1ed) @pli-tv-pvr1.2
pli-tv-pvr1.2:90.2@Bhuñjissāmī”ti → khādissāmi bhuñjissāmīti (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:97.1@Acelakassa → aceḷakassa (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:102.1@purebhattaṁ pacchābhattaṁ → purebhattaṁ vā pacchābhattaṁ vā santaṁ bhikkhuṁ anāpucchā (bj, sya-all); purebhattaṁ pacchābhattaṁ santaṁ bhikkhuṁ anāpucchā (pts1ed) @pli-tv-pvr1.2
pli-tv-pvr1.2:102.2@ummāraṁ → upacāraṁ (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:107.1@Acelakavaggo → aceḷakavaggo (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:109.3@hasite → hāsite (bj, sya-all, pts1ed) @pli-tv-pvr1.2
pli-tv-pvr1.2:117.3@apanidhite → apaniddhe (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:126.1@samanubhāsanāya → samanubhāsisamāno (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:127.1@akaṭānudhammena → akatānudhammena (bj) @pli-tv-pvr1.2
pli-tv-pvr1.2:133.3@pahate → paharite (bj); pahaṭe (cck, sya1ed, pts1ed) @pli-tv-pvr1.2
pli-tv-pvr1.5:1.1@samuṭṭhanti → samuṭṭhahanti (bj, sya-all) @pli-tv-pvr1.5
pli-tv-pvr1.8:1.3@khāyite → khayite (bj, pts1ed); Akkhāyite → akkhayite (bj, pts1ed) @pli-tv-pvr1.8
pli-tv-pvr1.8:1.5@vaṭṭakate → vattakate (bj, pts1ed); vivaṭakate (sya-all) @pli-tv-pvr1.8
pli-tv-pvr1.9:6.1@adinnaṁ → adinnāni (bj) @pli-tv-pvr1.9
pli-tv-pvr1.10:1.6@jatumaṭṭhake → jatumaṭṭake (bj) @pli-tv-pvr1.10
pli-tv-pvr1.10:11.3@ekaṁ piṇḍaṁ → ekapiṇḍe (sya-all) @pli-tv-pvr1.10
pli-tv-pvr1.16:4.1@Bhikkhuvibhaṅgamahāvāro niṭṭhito → niṭṭhito ca mahāvibhaṅgo (bj) @pli-tv-pvr1.16
pli-tv-pvr2.1:2.44@dummaṅkūnaṁ → dummaṅkunīnaṁ (bj) @pli-tv-pvr2.1
pli-tv-pvr2.1:2.48@Arahantiyo → arahantā (pts1ed, mr) @pli-tv-pvr2.1
pli-tv-pvr2.1:4.2@sambalo tathā → uttiyo ceva sambalo (bj, sya-all) @pli-tv-pvr2.1
pli-tv-pvr2.1:35.1@na paṭinissajjantiyā → nappaṭinissajjantiyā (bj, sya-all) @pli-tv-pvr2.1
pli-tv-pvr2.1:38.2@viharitthā”ti → viharathāti (bj) @pli-tv-pvr2.1
pli-tv-pvr2.1:41.1@gāmantaṁ → gāmantaraṁ (bj) @pli-tv-pvr2.1
pli-tv-pvr2.1:41.3@kismiñci → kismici (bj) @pli-tv-pvr2.1
pli-tv-pvr2.1:64.1@tirokuṭṭe → tirokuḍḍe vā tiropākāre vā (bj); tirokuḍḍe (sya-all, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:64.6@Aññatarā bhikkhunī uccāraṁ → uccāraṁpi passāvaṁpi kheḷaṁpi saṅkāraṁpi vighāsaṁpi (sya-all); uccārampi passāvampi saṅkārampi vighāsampi (pts1ed, mr) @pli-tv-pvr2.1
pli-tv-pvr2.1:71.1@Rathikāya vā → rathiyā vā (bj, pts1ed); rathiyāya vā (sya-all, mr) @pli-tv-pvr2.1
pli-tv-pvr2.1:79.0@4.3 Nahānavagga → naggavagga (pli-tv-bi-vb-pcsp2ed1:1 [Pācittiyā 21: Naggasikkhāpada]) @pli-tv-pvr2.1
pli-tv-pvr2.1:99.1@Vassaṁvuṭṭhāya → vassaṁ vutthāya (bj, sya-all, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:105.1@paṭissuṇitvā → paṭissutvā (bj); paṭisunitvā (pts1ed); Bhikkhuniyā → bhikkhunīhi (bj, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:118.6@bhikkhusaṅghaṁ → bhikkhunīsaṅghe (bj, mr) @pli-tv-pvr2.1
pli-tv-pvr2.1:121.1@rudhitaṁ → ruhitaṁ (bj, sya-all); rūhitaṁ (pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:142.1@sokāvāsaṁ → sokavassaṁ (bj); sokāvassaṁ (sya-all) @pli-tv-pvr2.1
pli-tv-pvr2.1:160.1@Asaṅkaccikāya → asaṅkacchikāya (sya-all, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:168.3@pavāraṇovādaṁ → vāso pavāraṇovādā (bj); vase pavāraṇovādā (sya-all) @pli-tv-pvr2.1
pli-tv-pvr2.1:169.1@Gabbhī → gabbhinī (bj, sya-all, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:174.2@cittagārakā → cittāgārakā (bj, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.1:174.3@Ārāmaṁ → ārāma (bj) @pli-tv-pvr2.1
pli-tv-pvr2.1:185.6@sayaṁ buddhena desitāti → sambuddhena pakāsitāti (bj); sayambuddhena desitāti (sya-all, pts1ed) @pli-tv-pvr2.1
pli-tv-pvr2.2:106.1@Gabbhinivaggo → gabbhinīvaggo (bj, sya-all, pts1ed) @pli-tv-pvr2.2
pli-tv-pvr2.2:120.1@Kumāribhūtavaggo → kumārībhūtavaggo (bj, sya-all) @pli-tv-pvr2.2
pli-tv-pvr2.2:134.2@Khuddakaṁ niṭṭhitaṁ → navavaggakhuddakā niṭṭhitā (bj); navavaggā khuddakā niṭṭhitā (sya-all) @pli-tv-pvr2.2
pli-tv-pvr2.2:135.2@paṭiggaṇhāti → paṭigaṇhāti (bj, pts1ed) @pli-tv-pvr2.2
pli-tv-pvr2.10:2.3@pārājikaṁ dhammaṁ → dhammaṁ ajjhāpannaṁ (sya-all) @pli-tv-pvr2.10
pli-tv-pvr2.16:5.3@(…) → imassānantaraṁ bj potthake evampi @pli-tv-pvr2.16
pli-tv-pvr2.16:6.1@Bhikkhunivibhaṅge → bhikkhunīvibhaṅge (bj, sya-all, pts1ed) @pli-tv-pvr2.16
pli-tv-pvr3:7.4@niyato → nayato (bj) @pli-tv-pvr3
pli-tv-pvr3:10.3@Sañcarittānubhāsanañca → sañcarittānubhāsañca (bj, sya-all) @pli-tv-pvr3
pli-tv-pvr3:14.1@raho dve ca → raho ceva (bj) @pli-tv-pvr3
pli-tv-pvr3:22.1@Kukkuccaṁ dhammikaṁ cīvaraṁ datvā → kukkuccaṁ dhammikaṁ cīvaraṁ (bj); kukkuccaṁ dhammikaṁ datvā (sya-all); kukkuccaṁ dhammakaṁ datvā (pts1ed) @pli-tv-pvr3
pli-tv-pvr3:22.4@Duggahī → duggahīna (bj) @pli-tv-pvr3
pli-tv-pvr3:30.3@Dvāradānasibbāni → dvāradānasibbinī (bj, sya-all, pts1ed) @pli-tv-pvr3
pli-tv-pvr3:34.1@ca cittā → na cittato (bj, sya-all) @pli-tv-pvr3
pli-tv-pvr3:34.2@na vācikā → na vācato (bj, sya-all) @pli-tv-pvr3
pli-tv-pvr3:34.4@tīhi dvārehi → tīhi ṭhānehi (sya-all) @pli-tv-pvr3
pli-tv-pvr3:39.1@Anvaddhaṁ → anvaddhamāsaṁ (bj); anvaḍḍhamāsaṁ (sya-all); saha jīviniṁ → sahajīvi (bj); sahajīvinī (sya-all); sahajīvini (pts1ed) @pli-tv-pvr3
pli-tv-pvr3:40.1@Samanubhāsanāsamuṭṭhānaṁ → samanubhāsana … (bj, sya-all) @pli-tv-pvr3
pli-tv-pvr3:44.3@ca cittā → na cittato (sya-all) @pli-tv-pvr3
pli-tv-pvr3:47.1@Uyyuttaṁ senaṁ → uyyuttaṁ vase (sya-all) @pli-tv-pvr3
pli-tv-pvr3:47.3@desanikā → desanīyā (bj) @pli-tv-pvr3
pli-tv-pvr3:53.4@anokāso → anokāse (bj, sya-all, pts1ed) @pli-tv-pvr3
pli-tv-pvr3:54.2@kāyacittato → kāyacittakā (mr) @pli-tv-pvr3
pli-tv-pvr3:58.6@sahā samā → samā nayā (sya-all) @pli-tv-pvr3
pli-tv-pvr3:63.3@Evameva → tatheva (bj, sya-all) @pli-tv-pvr3
pli-tv-pvr3:66.1@Dhammadesanāsamuṭṭhānaṁ → dhammadesana … (bj, sya-all, pts1ed) @pli-tv-pvr3
pli-tv-pvr3:67.2@na vācā → na vācāya (bj, sya-all, pts1ed) @pli-tv-pvr3
pli-tv-pvr3:70.1@Corī → coriṁ (bj) @pli-tv-pvr3
pli-tv-pvr3:70.6@bhāsitaṁ → ṭhapitaṁ (sya-all) @pli-tv-pvr3
pli-tv-pvr4:68.3@paṭinissajjati, ñattiyā dukkaṭaṁ → dvīhi kammavācāhi dukkaṭā (sya-all, mr) @pli-tv-pvr4
pli-tv-pvr4:83.1@Antarapeyyālaṁ → antarapeyyālo (bj); anantarapeyyālaṁ (si, sya-all, pts1ed) @pli-tv-pvr4
pli-tv-pvr5:7.10@Cha hetū → tayo kusalahetū (bj, sya-all); kati hetūti nava hetū (pts1ed) @pli-tv-pvr5
pli-tv-pvr5:92.2@vinibbhujitvā vinibbhujitvā → vinibbhujjitvā vinibbhujjitvā (mr) @pli-tv-pvr5
pli-tv-pvr5:93.5@ca labbhā → na ca labbhā (bj, sya-all, mr) @pli-tv-pvr5
pli-tv-pvr5:126.1@Sammanti na sammantivāro → sammati na sammati vāro (bj) @pli-tv-pvr5
pli-tv-pvr5:152.7@medhakaṁ → medhagaṁ (mr) @pli-tv-pvr5
pli-tv-pvr6:7.4@natthi tattha āpatti → na katamā āpatti (pts1ed); na katamā āpattiyo (mr) @pli-tv-pvr6
pli-tv-pvr6:25.1@Upasampadūposatho → upasampaduposathaṁ (sya-all) @pli-tv-pvr6
pli-tv-pvr6:25.2@Vassūpanāyikapavāraṇā → vassūpanā pavāraṇā (sya-all); vassupanāyikapavāraṇā (pts1ed) @pli-tv-pvr6
pli-tv-pvr6:26.1@Kosambakkhandhakaṁ → kosambikkhandhakaṁ (sya-all, pts1ed) @pli-tv-pvr6
pli-tv-pvr6:26.4@Saṅghabhedaṁ samācāro → saṅghabhedasamācarā (sya-all) @pli-tv-pvr6
pli-tv-pvr7:4.2@ca → ceva (bj) @pli-tv-pvr7
pli-tv-pvr7:5.4@Sabbasādhāraṇā ca ekato → padesasādhāraṇā ca ekato (bj); sādhāraṇā ca ekato (sya-all); sabbā sādhāraṇā ca ekato (pts1ed) @pli-tv-pvr7
pli-tv-pvr7:7.16@Atthāpatti desento āpajjati, atthāpatti na desento āpajjati → etthantare pāṭho km potthake natthi @pli-tv-pvr7
pli-tv-pvr7:10.56@jātimañca kārimañca → jātimayañca khārimayañca (sya-all) @pli-tv-pvr7
pli-tv-pvr7:10.60@sindhavaṁ, ubbhidaṁ → sindhavañca ubbhidañca (sya-all); sindhavaṁ ubbhiraṁ (itipi) @pli-tv-pvr7
pli-tv-pvr7:18.2@pācitti → pācittiyā (bj); pācitti (sya-all); pācitti (pts1ed) @pli-tv-pvr7
pli-tv-pvr7:18.3@dubbhāsitā ceva → bhāsitañceva (sya-all) @pli-tv-pvr7
pli-tv-pvr7:25.25@vivaṭako → vivaṭṭako (mr) @pli-tv-pvr7
pli-tv-pvr7:25.27@asantuṭṭhitā → asantuṭṭhatā (sya-all) @pli-tv-pvr7
pli-tv-pvr7:30.7@saṅghe na voharitabbaṁ → saṅgho na voharitabbo (cck); saṅgho na voharitabbo (sya1ed, sya2ed) @pli-tv-pvr7
pli-tv-pvr7:30.29@sākacchitabbo → sākacchātabbo (pts1ed, mr) @pli-tv-pvr7
pli-tv-pvr7:33.2@parisuddhabrahmacariyaṁ → parisuddhaṁ brahmacariyaṁ (bj); suddhaṁ brahmacariyaṁ (sya-all); evaṁdiṭṭhi → evaṁdiṭṭhī (bj) @pli-tv-pvr7
pli-tv-pvr7:40.4@anissagge → anissaggī (si) @pli-tv-pvr7
pli-tv-pvr7:49.9@paṇṇattiyo → paññattiyo (bj) @pli-tv-pvr7
pli-tv-pvr7:49.15@Cattāro mānattā → cattāri mānattāni (bj) @pli-tv-pvr7
pli-tv-pvr7:49.34@parisasobhanā → parisasobhaṇā (sya-all, pts1ed, mr) @pli-tv-pvr7
pli-tv-pvr7:56.3@Ajānakāye → ajānakāle (bj) @pli-tv-pvr7
pli-tv-pvr7:57.1@Paṭilābhena → paṭilābhā (bj, sya-all) @pli-tv-pvr7
pli-tv-pvr7:57.4@paṭiggahi → paṭiggahā (bj, sya-all) @pli-tv-pvr7
pli-tv-pvr7:58.2@vipattiyo → kamma … (bj, sya-all, pts1ed) @pli-tv-pvr7
pli-tv-pvr7:63.32@gatapaṭiyāgataṁ → bhatapaṭiyābhataṁ (mr) @pli-tv-pvr7
pli-tv-pvr7:63.35@lokasmiṁ → lokassa (bj, sya-all, pts1ed) @pli-tv-pvr7
pli-tv-pvr7:63.56@duppaṭivinodayā → duppaṭivinodiyā (sya-all, pts1ed) @pli-tv-pvr7
pli-tv-pvr7:63.57@gamiyacittaṁ → gamikacittaṁ (an5.160:1 [160. Duppaṭivinodayasutta]) @pli-tv-pvr7
pli-tv-pvr7:63.59@pāsādikasaṁvattanikakammaṁ → … saṁvattanikaṁ kammaṁ (bj); … saṁvattaniyaṁ kammaṁ (cck, sya1ed) @pli-tv-pvr7
pli-tv-pvr7:64.2@na uggahetvā → anuggahetvā (bj) @pli-tv-pvr7
pli-tv-pvr7:65.1@āraññikā → āraññakā (bj, pts1ed); araññakā (sya-all) @pli-tv-pvr7
pli-tv-pvr7:65.2@idamatthitaññeva → idamaṭṭhitaññeva (si, sya-all, pts1ed) @pli-tv-pvr7
pli-tv-pvr7:67.2@anuviccapi → anuvicca (bj); anuvijja pi (pts1ed) @pli-tv-pvr7
pli-tv-pvr7:67.9@kulūpake → kulūpage (bj); kulupake (sya-all) @pli-tv-pvr7
pli-tv-pvr7:67.10@anāmantacāre → anāmantacāro (bj); anāmantācāre (sya-all) @pli-tv-pvr7
pli-tv-pvr7:67.11@kulūpakassa → kulūpagassa (bj); kulupakassa (sya1ed, sya2ed) @pli-tv-pvr7
pli-tv-pvr7:68.1@bījajātāni → bījāni (bj) @pli-tv-pvr7
pli-tv-pvr7:68.2@bījabījaññeva → bījabījameva (mr); phaḷubījaṁ → phalubījaṁ (bj) @pli-tv-pvr7
pli-tv-pvr7:68.4@nibbattabījaññeva → nibbaṭṭabījaññeva (bj); nibbaṭabījaññeva (sya-all); nivattabījaññeva (pts1ed); nippaṭṭabījaññeva (mr); aggiparijitaṁ, satthaparijitaṁ, nakhaparijitaṁ → aggiparicitaṁ satthaparicitaṁ nakhaparicitaṁ (pli-tv-kd15:23 [Khuddakavatthu]) @pli-tv-pvr7
pli-tv-pvr7:73.2@ca vuccati → coro pavuccati (bj) @pli-tv-pvr7
pli-tv-pvr7:77.4@sapadāno nisajjiko → sapadānanisajjikā (bj); sapādāno nesajjiko (pts1ed) @pli-tv-pvr7
pli-tv-pvr7:86.2@anabhirataṁ → anabhiratiṁ (si, sya-all, mr); dhammato vinodetuṁ → vinodetuṁ vā vinodāpetuṁ vā (sya-all) @pli-tv-pvr7
pli-tv-pvr7:96.20@daṭṭhabbā → paṭikātabbā (sabbattha) aṭṭhakathā ca campeyyakkhandhake adhammakammādikathā ca oloketabbā @pli-tv-pvr7
pli-tv-pvr7:98.2@sātthaṁ sabyañjanaṁ → satthā savyañjanā (bj); dhātā → dhatā (bj, sya-all) @pli-tv-pvr7
pli-tv-pvr7:100.2@atikkantamānusakena → atikkantamānussakena (mr) @pli-tv-pvr7
pli-tv-pvr7:106.2@upaṭṭhitassati → upaṭṭhitasati (bj, pts1ed) @pli-tv-pvr7
pli-tv-pvr7:112.1@Caturo → cattāro (bj, sya-all, pts1ed) @pli-tv-pvr7
pli-tv-pvr7:113.28@sammannitabbo → sammanitabbo (mr) @pli-tv-pvr7
pli-tv-pvr7:120.19@saññattiyo → paññattiyo (si) @pli-tv-pvr7
pli-tv-pvr7:129.2@nidānaṁ → uddānaṁ (mr) @pli-tv-pvr7
pli-tv-pvr7:135.9@cīvaradhāraṇā → cīvaradhāraṇāni (sya-all) @pli-tv-pvr7
pli-tv-pvr7:138.1@Āghātaṁ vinayaṁ → āghātavinayā (bj, sya-all) @pli-tv-pvr7
pli-tv-pvr7:139.3@Bhāsādhikaraṇañceva → bhāsādhikaraṇā ceva (bj) @pli-tv-pvr7
pli-tv-pvr7:144.11@vidhā → vīṭhā (bj); vīthā (sya-all) @pli-tv-pvr7
pli-tv-pvr7:147.1@Nāsetabbā → nāsetabbo (si) @pli-tv-pvr7
pli-tv-pvr8:0.3@1 Ādimajjhantapucchana → pucchā (bj) @pli-tv-pvr8
pli-tv-pvr8:2.0@2 Ādimajjhantavissajjanā → vissajjanā (bj) @pli-tv-pvr8
pli-tv-pvr10:1.2@paggaṇhitvāna → paggahetvāna (bj) @pli-tv-pvr10
pli-tv-pvr10:1.3@Āsīsamānarūpova → āsiṁsamānarūpova (bj, sya-all, pts1ed) @pli-tv-pvr10
pli-tv-pvr10:3.1@ummaṅgo → ummaggo (bj) @pli-tv-pvr10
pli-tv-pvr10:5.2@Iṅgha me tvaṁ byākara naṁ → iṅgha me tvaṁ byākara (bj, sya-all); ingha me taṁ byākaraṇaṁ (pts1ed); iṅgha me taṁ byākara (mr) @pli-tv-pvr10
pli-tv-pvr10:5.3@Taṁ vacanapathaṁ → tava vacanapathaṁ (sya-all) @pli-tv-pvr10
pli-tv-pvr10:11.2@yathātathaṁ → yathākathaṁ (bj, sya-all) @pli-tv-pvr10
pli-tv-pvr10:12.2@dantaponena → dantapoṇena (sya-all, pts1ed, mr) @pli-tv-pvr10
pli-tv-pvr10:17.2@catuvīsati → catutiṁsati (bj) @pli-tv-pvr10
pli-tv-pvr10:22.1@āraññiko → āraññako (bj, sya-all, pts1ed) @pli-tv-pvr10
pli-tv-pvr10:22.2@aṭṭhete → cha ete (sabbattha) @pli-tv-pvr10
pli-tv-pvr10:27.1@Yaṁ taṁ → yantvaṁ (sya-all); yaṁ tvaṁ (pts1ed); yaṁ yaṁ (mr) @pli-tv-pvr10
pli-tv-pvr10:28.1@Sādhāraṇaṁ asādhāraṇaṁ → sādhāraṇāsādhāraṇaṁ (bj) @pli-tv-pvr10
pli-tv-pvr10:28.2@Vibhattiyo ca → vipattiyo (bj); vipattiyo ca (sya-all, pts1ed) @pli-tv-pvr10
pli-tv-pvr10:37.1@Sodasa → soḷasa (bj, sya-all, pts1ed) @pli-tv-pvr10
pli-tv-pvr10:49.2@dve → dvīhi (bj, sya-all) @pli-tv-pvr10
pli-tv-pvr10:50.1@Dvevīsati → dvāvīsati (bj) @pli-tv-pvr10
pli-tv-pvr10:51.3@yathātathaṁ → yathākathaṁ (bj, sya-all) @pli-tv-pvr10
pli-tv-pvr10:70.1@bhuñjantā → bhuñjantaṁ (bj, pts1ed); buñjanto (sya-all) @pli-tv-pvr10
pli-tv-pvr10:70.2@bhikkhuniṁ → bhikkhunī (bj, sya-all, pts1ed) @pli-tv-pvr10
pli-tv-pvr10:71.2@anāḷiyaṁ → anāḷhiyaṁ (bj, sya-all, pts1ed) @pli-tv-pvr10
pli-tv-pvr11:19.2@sattāpattikkhandhā → satta āpattikkhandhā (bj, sya-all) @pli-tv-pvr11
pli-tv-pvr11:26.7@pārājikaṁ dhammaṁ → pārājikaṁ dhammaṁ ajjhāpannaṁ (sya-all) @pli-tv-pvr11
pli-tv-pvr11:65.2@upajjhāyakiccaṁ → upajjhāyakiccaṁ sakiccaṁ (mr) @pli-tv-pvr11
pli-tv-pvr11:71.2@saṁsaṭṭhā nidānena ca → saṁsaṭṭhā nidānappabhavā (bj) @pli-tv-pvr11
pli-tv-pvr12:6.2@padhāresi → padhārehi (bj) @pli-tv-pvr12
pli-tv-pvr12:7.6@Vattānusandhitena → vuttānusandhitena (si, sya-all, pts1ed, mr) @pli-tv-pvr12
pli-tv-pvr12:8.3@Etañca → evañca (pts1ed, mr) @pli-tv-pvr12
pli-tv-pvr12:13.3@mettācitto → mettacitto (bj, sya-all, pts1ed) @pli-tv-pvr12
pli-tv-pvr12:19.1@Pubbāparampi jānāti → pubbāparaṁ vijānāti (bj) @pli-tv-pvr12
pli-tv-pvr13:28.4@sāsanaṁ patiṭṭhāpayanti → sāsanassa patiṭṭhāyanti (bj) @pli-tv-pvr13
pli-tv-pvr14:3.1@jimhaṁ → jivhaṁ (si); parisakappikena → parisakappiyena (bj, sya-all, pts1ed); parisaṅkappikena (si) @pli-tv-pvr14
pli-tv-pvr14:4.1@na bāhāvikkhepakaṁ → na vācāvikkhepakaṁ (sya-all); mando hāsetabbo → mando pahāsetabbo (bj); vepo pahāsetabbo (sya-all); pariggahetvā → uggahetvā (sya-all, pts1ed); na chandāgatiṁ gantabbaṁ → na chandāgati gantabbā (bj, sya-all, pts1ed) @pli-tv-pvr14
pli-tv-pvr14:10.5@Sa ve → sace (mr) @pli-tv-pvr14
pli-tv-pvr14:16.6@ekuddeso → ekuddesaṁ (bj, sya-all, pts1ed) @pli-tv-pvr14
pli-tv-pvr15:2.2@aṭṭhapārājikānaṁ → aṭṭhannaṁ pārājikānaṁ (pts1ed, mr). @pli-tv-pvr15
pli-tv-pvr15:8.8@vaṇṇāvaṇṇo → vaṇṇo avaṇṇo (sya-all); vacanamanuppadānaṁ → vaṇṇamanuppādanaṁ (sya-all); dhanamanuppadānaṁ (pts1ed, mr). @pli-tv-pvr15
pli-tv-pvr15:13.4@āghāto paṭighāto → āghātito paṭighātito (bj, pts1ed) @pli-tv-pvr15
pli-tv-pvr15:28.2@appaññāto → apaññāto (bj) @pli-tv-pvr15
pli-tv-pvr15:29.2@bhāraṁ → bhāsaṁ (sya-all). @pli-tv-pvr15
pli-tv-pvr15:38.6@vasse vā → vassāne vā (bj) @pli-tv-pvr15
pli-tv-pvr16:1.1@kathinaṁ → kaṭhinaṁ (bj, sya-all, pts1ed) @pli-tv-pvr16
pli-tv-pvr16:4.8@ovaṭṭiyakaraṇamattena → ovattikaraṇa … (bj); ovaṭṭikaraṇa … (sya-all) @pli-tv-pvr16
pli-tv-pvr16:4.9@na kaṇḍusakaraṇamattena → na kaṇḍūsakaraṇamattena (sya-all); na gaṇḍusakaraṇamattena (mr) @pli-tv-pvr16
pli-tv-pvr16:4.13@na ovaddheyyakaraṇamattena → na ovaṭṭeyyakaraṇamattena (bj, sya-all); na ovadeyyakaraṇamattena (mr) @pli-tv-pvr16
pli-tv-pvr16:5.8@uṭṭhahati → udriyati (bj, sya-all, pts1ed) @pli-tv-pvr16
pli-tv-pvr16:23.1@Katinaṁ → katinnaṁ (bj); katīnaṁ (sya-all, pts1ed) @pli-tv-pvr16
pli-tv-pvr16:34.2@uṭṭhahati → udrīyati (bj); udriyati (sya-all, pts1ed). @pli-tv-pvr16
pli-tv-pvr16:51.5@bahisīme → bahisīmagatassa (bj, sya-all, pts1ed) @pli-tv-pvr16
pli-tv-pvr16:52.1@Sahubbhāro → saubbhāro (mr) @pli-tv-pvr16
pli-tv-pvr16:55.1@kathinuddhārā → kaṭhinuddhārā (bj, sya-all, pts1ed) @pli-tv-pvr16
pli-tv-pvr16:56.1@Kathinabhedo → kaṭhinabhedo (bj, pts1ed); kaṭhinabhedaṁ (sya-all) @pli-tv-pvr16
pli-tv-pvr16:58.4@atthārapuggalā → aṭṭhārapuggalā (si, pts1ed); aṭṭhapuggalabhedā (sya-all) @pli-tv-pvr16
pli-tv-pvr16:59.1@Tiṇṇaṁ → bhedā tiṇṇaṁ (bj, pts1ed); bhedato tiṇṇaṁ (mr) @pli-tv-pvr16
pli-tv-pvr16:59.4@cāti → ito paraṁ (?) @pli-tv-pvr16
pli-tv-pvr17:6.3@vinodetuṁ → imasmiṁ ṭhāne sabbattha (?) @pli-tv-pvr17
pli-tv-pvr17:93.3@(…) → (na saññāyati) (bj); na sampāyati → na sampādeti (bj, sya-all); na sampādayati (mr) @pli-tv-pvr17
pli-tv-pvr17:102.1@pañcaṅgasamannāgataṁ → pañcahaṅgehi samannāgataṁ (bj, sya-all) @pli-tv-pvr17
pli-tv-pvr17:102.2@Katame pañca → katamehi pañcahi (sya-all) @pli-tv-pvr17
pli-tv-pvr17:125.2@Kāruññaṁ → kāruññena (bj); kāruññe (sya-all, pts1ed) @pli-tv-pvr17
pli-tv-pvr17:141.4@veramaṇī → veraṁani (pts1ed); veramaṇi (mr) @pli-tv-pvr17
pli-tv-pvr17:197.19@āvenibhāvaṁ → āveṇibhāvaṁ (bj, sya-all, pts1ed); āveniṁ → āveṇi (bj, sya-all, pts1ed) @pli-tv-pvr17
pli-tv-pvr17:212.5@Khantiṁ ruciñca saññañca → khanti ruci ca saññā ca (bj, sya-all, pts1ed) @pli-tv-pvr17
pli-tv-pvr18:32.1@Acittakusalā ceva → acittakusalañceva (bj); acittakusalo c’eva (pts1ed) @pli-tv-pvr18
pli-tv-pvr19:15.3@Katinaṁ → katinnaṁ (bj) | katīnañca (s1-3) | katīnaṁ ca (pts1) @pli-tv-pvr19
pli-tv-pvr19:69.4@sabbeva adhammikā → sabbe adhammikā (bj, s1-3) @pli-tv-pvr19
pli-tv-pvr19:70.4@sabbeva adhammikā → sabbevādhammikā (bj) | sabbe adhammikā (s1-3) @pli-tv-pvr19
pli-tv-pvr19:79.4@vinayāni → visayāni (bj, s1-3, pts1) @pli-tv-pvr19
pli-tv-pvr20:2.1@Avissajjiyaṁ → avissajjikaṁ (si) | avissajjitaṁ (s1-3); avebhaṅgiyaṁ → avebhaṅgikaṁ (si) @pli-tv-pvr20
pli-tv-pvr20:35.2@ca saṅghe → no ca saṅghassa (bj, s1) | no ce saṅghassa (si) | no saṅghassa (pts1, mr) @pli-tv-pvr20
pli-tv-pvr20:47.2@na kāyikaṁ na vācasikaṁ → kāyikaṁ subhāsitaṁ (bj) | na kāyikaṁ sunāsitaṁ (s1-3) @pli-tv-pvr20
pli-tv-pvr20:51.4@viññūhi vibhāvitāti → viññūvibhāvitāti (bj, s1-3, pts1) @pli-tv-pvr20
pli-tv-pvr21:43.4@adhikaraṇe vūpasamite → adhikaraṇavūpasamena (bj); adhikaraṇe vūpasamepi (mr) @pli-tv-pvr21
pli-tv-pvr21:70.3@sattaṭṭhānaṁ → satta ṭhānaṁ (bj) @pli-tv-pvr21
pli-tv-pvr21:73.4@Pabbājanīya paṭisāraṇī → pabbājapaṭisāraṇī (bj, sya-all) @pli-tv-pvr21
pli-tv-pvr21:81.1@Bubbācariyamaggañca … parivārena sobhatīti → etthantare gāthā si potthakesu (sya-all, pts1ed); ca → va (sya-all, pts1ed) @pli-tv-pvr21
pli-tv-pvr21:81.4@sutadhāriṁ → sutadharo (sya-all, pts1ed) @pli-tv-pvr21
pli-tv-pvr21:84.2@jambudīpaṁva → jambūdīpaṁva (sya-all) @pli-tv-pvr21
pli-tv-pvr21:85.2@anupaññatti → anuppaññatti (sya-all) @pli-tv-pvr21
pli-tv-pvr21:86.4@kesari → kesarī (sya-all, pts1ed) @pli-tv-pvr21
